﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.Math;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class Asn1Integer : Asn1Object
    {
        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.INTEGER);

        private BigInteger minimumValue = null; // null == unbounded.
        private BigInteger maximumValue = null; // null == unbounded.
        private BigInteger value;

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        public override Asn1Tag getDefaultTag()
        {
            return Asn1Tag.INTEGER;
        }

        /**
         * Sets the allowed range of values. A null for either parameter means that the value is unbounded
         * in that direction.
         */
        protected void setValueRange( BigInteger minimum,  BigInteger maximum)
        {
            minimumValue = minimum;
            maximumValue = maximum;
        }
         
        private void validateValue()
        {
            //Preconditions.CheckNotNull(value, "No value set.");
            Preconditions.CheckState(
                minimumValue == null || value.CompareTo(minimumValue) >= 0,
                "Too small value %s");
            Preconditions.CheckState(
                maximumValue == null || value.CompareTo(maximumValue) <= 0,
                "Too large value %s");
        }


        public void setInteger(BigInteger value)
        {
            this.value = value;
        }

        public void setInteger(BigInteger value, bool validate)
        {
            this.value = value;
            if (validate)
            {
                validateValue();
            }
        }

        public void setLong(long value)
        {
            setInteger(BigInteger.ValueOf(value));
        }

        public void setLong(long value, bool validateValue)
        {
            setInteger(BigInteger.ValueOf(value), validateValue);
        }

        public BigInteger getInteger()
        {
            return value;
        }

        /**
         * Convenience function to return {@link BigInteger#longValue()} of the value. Only the low-order
         * 64 bits are returned, so it can lose information about the overall magnitude of the value as
         * well as return a result with the opposite sign.
         *
         * @return the lowest 64 bits of the value, as a long
         */
        public long getLong()
        {
            return (long)value;
        }

        private BigInteger decodeNormalizedIntegerWithRangeAligned(
            BitStreamReader reader, BigInteger range)
        {
            if (range.CompareTo(BigInteger.ValueOf(PerAlignedUtils.SIXTYFOUR_K)) < 0)
            {
                int normalizedIntValue =
                    PerAlignedUtils.decodeNormalizedSmallConstrainedWholeNumber(reader, (int)range);
                return BigInteger.ValueOf(normalizedIntValue);
            }
            else
            {
                return PerAlignedUtils.decodeBigNonNegativeWholeNumber(
                    PerAlignedUtils.decodeConstrainedLengthOfBytes(
                        reader, 1,
                        PerAlignedUtils.encodeBigNonNegativeWholeNumber(range).Count()));
            }
        }

        private BigInteger decodeNormalizedIntegerWithRangeUnaligned(
            BitStreamReader reader, BigInteger range)
        {
            long normalizedIntValue =
                PerUnalignedUtils.decodeNormalizedConstrainedWholeNumber(
                    reader, range.LongValue());
            return BigInteger.ValueOf(normalizedIntValue);
        }

        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            if (maximumValue != null && minimumValue != null)
            {
                // Decodes a constrained whole numbers according to X.691-0207, 10.5.
                BigInteger range = maximumValue.Subtract(minimumValue);
                BigInteger normalizedValue = aligned
                    ? decodeNormalizedIntegerWithRangeAligned(reader, range)
                    : decodeNormalizedIntegerWithRangeUnaligned(reader, range);
                value = minimumValue.Add(normalizedValue);
            }
            else if (minimumValue != null)
            {
                // Decodes a semi-constrained whole numbers according to X.691-0207, 10.7.
                byte[] intBytes = aligned
                    ? PerAlignedUtils.decodeSemiConstrainedLengthOfBytes(reader)
                    : PerUnalignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                value = new BigInteger(convertPositiveToSigned(intBytes)).Add(minimumValue);
            }
            else
            {
                // Decodes an unconstrained whole number according to X.691-0207, 10.8.
                value = new BigInteger(aligned
                    ? PerAlignedUtils.decodeUnconstrainedLengthOfBytes(reader)
                    : PerUnalignedUtils.decodeSemiConstrainedLengthOfBytes(reader));
            }
        }

        private byte[] convertPositiveToSigned(byte[] rawData)
        {
            if ((rawData[0] & 0x80) != 0)
            {
                byte[] data = new byte[rawData.Count() + 1];
                System.Array.Copy(rawData, 0, data, 1, rawData.Count());
                return data;
            }
            else
            {
                return rawData;
            }
        }


        public override void decodeBerValue(ByteBuffer buf)
        {
            value = new BigInteger(getRemaining(buf));
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            if (value.Equals(BigInteger.Zero))
            {
                buf.Put((sbyte)0);
            }
            else
            {
                buf.Put(value.ToByteArray());
            }
        }

        public override int getBerValueLength()
        {
            if (value.Equals(BigInteger.Zero))
            {
                // BER requires 0 be encoded with one or more zero octets
                return 1;
            }
            else
            {
                return (value.BitLength() >> 3) + 1;
            }
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl<SequenceComponent>(true);
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl<SequenceComponent>(false);
        }

        private IEnumerable<BitStream> encodePerImpl<T>(bool aligned) where T : SequenceComponent
        {
            validateValue();
            if (maximumValue != null && minimumValue != null)
            {
                // Encodes a constrained whole numbers according to X.691-0207, 10.5.
                BigInteger normalizedValue = value.Subtract(minimumValue);
                BigInteger range = maximumValue.Subtract(minimumValue);
                return aligned
                    ? encodeNormalizedIntegerWithRangeAligned(normalizedValue, range)
                    : encodeNormalizedIntegerWithRangeUnaligned(normalizedValue, range);
            }
            else if (minimumValue != null)
            {
                // Encodes a semi-constrained whole numbers according to X.691-0207, 10.7.
                return aligned
                    ? PerAlignedUtils.encodeSemiConstrainedLengthOfBytes(
                        PerAlignedUtils.encodeBigNonNegativeWholeNumber(value.Subtract(minimumValue)))
                    : PerUnalignedUtils.encodeSemiConstrainedLengthOfBytes(
                        PerUnalignedUtils.encodeBigNonNegativeWholeNumber(value.Subtract(minimumValue)));
            }
            else
            {
                // Encodes an unconstrained whole number according to X.691-0207, 10.8.
                return aligned
                    ? PerAlignedUtils.encodeUnconstrainedLengthOfBytes(value.ToByteArray())
                    : PerUnalignedUtils.encodeSemiConstrainedLengthOfBytes(value.ToByteArray());
            }
        }


        private IEnumerable<BitStream> encodeNormalizedIntegerWithRangeAligned(
            BigInteger normalizedValue, BigInteger range)
        {
            if (range.CompareTo(BigInteger.ValueOf(PerAlignedUtils.SIXTYFOUR_K)) < 0)
            {
                BitStream result = PerAlignedUtils.encodeNormalizedSmallConstrainedWholeNumber(
                    normalizedValue.IntValue(), range.IntValue());
                var builder = ImmutableList.CreateBuilder<BitStream>(); 
                builder.Add(result); 
                return builder.ToImmutable();
                //return ImmutableList.of(result);
            }
            else
            {
                return PerAlignedUtils.encodeConstrainedLengthOfBytes(
                    PerAlignedUtils.encodeBigNonNegativeWholeNumber(normalizedValue),
                    1,
                    PerAlignedUtils.encodeBigNonNegativeWholeNumber(range).Length);
            }
        }

        private IEnumerable<BitStream> encodeNormalizedIntegerWithRangeUnaligned(
            BigInteger normalizedValue, BigInteger range)
        {
            BitStream result = PerUnalignedUtils.encodeNormalizedConstrainedWholeNumber(
                normalizedValue.LongValue(), range.LongValue());
            var builder = ImmutableList.CreateBuilder<BitStream>();
            builder.Add(result);
            return builder.ToImmutable();
            //return ImmutableList.of(result);
        }


    }
}