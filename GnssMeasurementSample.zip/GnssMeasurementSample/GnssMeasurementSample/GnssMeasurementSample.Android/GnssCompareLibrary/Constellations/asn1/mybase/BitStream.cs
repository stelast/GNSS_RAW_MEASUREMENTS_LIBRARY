﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class BitStream
    {
        static readonly int DEFAULT_BUFFER_CHUNK = 50;
        private static readonly int BITS_IN_BYTE = 8;

        /**
         * The number of bytes that is initially allocated and by which the buffer gets expanded when
         * necessary.
         */
        private readonly int bufferSize;

        private byte[] buffer;
        /**
         * The position in the buffer of the unfinished byte in progress.
         */
        private int position = 0;
        /**
         *   The number of high bits accumulated in the unfinished byte.
         */
        private int setBits = 0;

        /**
         * Creates a new {@link BitStream} object using {@link #DEFAULT_BUFFER_CHUNK}
         * as buffer size.
         */
        public BitStream() : this(DEFAULT_BUFFER_CHUNK)
        {
        }

        /**
         * Creates a new {@link BitStream} object using bufferSize parameter.
         *
         * <p>Applications encoding larger messages should provide a suitable bufferSize value
         * for better performance.
         */
        public BitStream(int bufferSize)
        {
            this.bufferSize = bufferSize;
            this.buffer = new byte[bufferSize];
        }

        public byte[] getPaddedBytes()
        {
            return Arrays.CopyOf(buffer, position + (setBits == 0 ? 0 : 1));
        }

        public void appendByte(byte data)
        {
            buffer[position] = (byte)(buffer[position] | (data & 0xFF) >> setBits);
            incrementPosition();
            buffer[position] = (byte)(buffer[position] | (data << (BITS_IN_BYTE - setBits)) & 0xFF);
        }

        private void incrementPosition()
        {
            position++;
            if (position >= buffer.Count())
            {
                buffer = Arrays.CopyOf(buffer, buffer.Count() + bufferSize);
            }
        }

        public void appendBit(bool one)
        {
            if (one)
            {
                buffer[position] = (byte)(buffer[position] | 1 << (BITS_IN_BYTE - 1 - setBits));
            }
            setBits++;
            if (setBits == BITS_IN_BYTE)
            {
                incrementPosition();
                setBits = 0;
            }
        }

        public int getBitCount()
        {
            return BITS_IN_BYTE * position + setBits;
        }

        /**
         * Appends the lowest {@code howManyBits} from the {@code data} in order from
         * most significant to least significant.
         */
        public void appendLowBits(int howManyBits, byte data)
        {
            Preconditions.CheckArgument(howManyBits < BITS_IN_BYTE);
            int lowMask = (1 << howManyBits) - 1;
            int highMask = ~lowMask;
            int maskedData = data;
            while (highMask < -1)
            {
                maskedData &= ~highMask;
                highMask >>= 1;
                appendBit((maskedData & highMask) != 0);
            }
        }

        private bool beginByteAligned;

        public bool beginsByteAligned()
        {
            return beginByteAligned;
        }

        public void setBeginByteAligned()
        {
            beginByteAligned = true;
        }

        public void spoolToByteBoundary()
        {
            if (setBits != 0)
            {
                setBits = 0;
                incrementPosition();
            }
        }
    }
}