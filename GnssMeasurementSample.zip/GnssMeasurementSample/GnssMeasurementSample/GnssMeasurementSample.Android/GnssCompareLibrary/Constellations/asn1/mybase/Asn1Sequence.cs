﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Java.Nio;
using Java.Util;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public abstract class Asn1Sequence : Asn1Object
    {
        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.SEQUENCE); 

        protected abstract bool isExtensible();

        public abstract bool containsExtensionValues(); 

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        /**
         * Returns the child component that can start with the specified tag.
         * @throws NoSuchElementException if no child component can start with the tag
         */
        private SequenceComponent getComponent<T>(IEnumerable<T> components,
            Asn1Tag tag) where T: SequenceComponent
        {
            foreach (SequenceComponent component in components)
            {
                if (component.getPossibleFirstTags().Contains(tag))
                {
                    return component;
                }
            }
            throw new NoSuchElementException("SEQUENCE=" + this + ", tag=" + tag);
        }

        public override void decodeBerValue(ByteBuffer buf)
        { 
            var components = getComponents();
            //Iterable <? extends SequenceComponent > components = getComponents();

            while (buf.HasRemaining)
            {
                int bufStartPos = buf.Position();
                int bufEndPos = buf.Limit();
                Asn1Tag tag = Asn1Tag.readTag(buf);
                SequenceComponent component = getComponent(components, tag);
                if (component.isExplicitlySet())
                {
                    throw new IllegalArgumentException("Encountered duplicate field");
                }
                component.setToNewInstance();
                int valueLength = Asn1Tag.readLength(buf);
                buf.Limit(buf.Position() + valueLength);
                if (component.getTag() != null)
                {
                    if (component.isImplicitTagging())
                    {
                        component.getComponentValue().decodeBerValue(buf);
                    }
                    else
                    {
                        component.getComponentValue().decodeBer(buf);
                    }
                }
                else
                {
                    buf.Position(bufStartPos); // rewind to before tag
                    component.getComponentValue().decodeBer(buf);
                }
                buf.Limit(bufEndPos); // set the limit back to the real end position
            }

            checkMandatoryFieldsPresent(components);
        }

        /**
         * Throws {@link IllegalArgumentException} if all mandatory fields not set on this sequence.
         */
        private void checkMandatoryFieldsPresent<T>(IEnumerable<T> components)
            where T: SequenceComponent
        {
            foreach (SequenceComponent component in components)
            {
                if (!component.isOptional() && !component.isExplicitlySet())
                {
                    throw new IllegalArgumentException("Mandatory field not present");
                }
            }
        }

        private int calculateBitFieldSize<T>(
            IEnumerable<T> components) where T : SequenceComponent
        {
            int bitFieldSize = 0;
            foreach (SequenceComponent component in components)
            {
                if (component.isOptional() || component.hasDefaultValue())
                {
                    bitFieldSize++;
                }
            }
            return bitFieldSize;
        }

        protected abstract IEnumerable<SequenceComponent> getComponents();

        protected abstract IEnumerable<SequenceComponent> getExtensionComponents();

        private IEnumerable<BitStream> encodePerImpl(bool aligned)
        {
            ImmutableList<BitStream>.Builder listBuilder = ImmutableList.CreateBuilder<BitStream>();
            BitStream prefix = new BitStream();

            if (isExtensible())
            {
                prefix.appendBit(containsExtensionValues());
            }

            IEnumerable <SequenceComponent> components = getComponents();
            int bitFieldSize = calculateBitFieldSize(components);
            if (bitFieldSize >= PerAlignedUtils.SIXTYFOUR_K)
            {
                throw new UnsupportedOperationException("unimplemented");
            }
            foreach (SequenceComponent component in components)
            {
                if (component.isOptional() || component.hasDefaultValue())
                {
                    prefix.appendBit(component.isExplicitlySet());
                }
                else if (!component.isExplicitlySet())
                {
                    throw new IllegalStateException("Mandatory component "
                                                    + "Asn1Sequence"
                                                    + " not set.");
                }
            }
            listBuilder.Add(prefix);

            foreach (SequenceComponent component in components)
            {
                if (component.isExplicitlySet())
                {
                    Asn1Object value = component.getComponentValue();
                    IEnumerable<BitStream> encodedValue = null;
                    if (aligned)
                    {
                        encodedValue = value.encodePerAligned();
                    }
                    else
                    {
                        encodedValue = value.encodePerUnaligned();
                    }
                    using (var secuence = encodedValue.GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            listBuilder.Add(secuence.Current);
                        }
                    }
                    //listBuilder.AddAll(encodedValue);
                }
            }

            if (isExtensible() && containsExtensionValues())
            {
                IEnumerable <SequenceComponent> extensionComponents = getExtensionComponents();
                BitStream extensions = new BitStream();
                int extensionBitFieldSize = 0;
                /*
                 * Adding a bit marker per extension addition as ITU spec, however some
                 * H323 implementations seem to only add markers up to the last set
                 * extension.
                 */
                foreach (SequenceComponent component in extensionComponents)
                {
                    if (!component.isOptional() && !component.isExplicitlySet())
                    {
                        throw new IllegalStateException("Mandatory extension component "
                                                        + "Asn1Sequence"
                                                        + " not set.");
                    }
                    extensions.appendBit(component.isExplicitlySet());
                    extensionBitFieldSize++;
                }
                if (extensionBitFieldSize <= 64)
                {
                    //encode length to x.691-0207 10.9.3.4 (i.e. length -1)
                    BitStream lengthDeterminant = new BitStream();
                    lengthDeterminant.appendBit(false);
                    lengthDeterminant.appendLowBits(6, (byte)(extensionBitFieldSize - 1));
                    listBuilder.Add(lengthDeterminant);
                }
                else
                {
                    BitStream marker = new BitStream();
                    marker.appendBit(true);
                    listBuilder.Add(marker);
                    BitStream lengthDeterminant = null;
                    if (aligned)
                    {
                        lengthDeterminant =
                            PerAlignedUtils.encodeSemiConstrainedLength(extensionBitFieldSize);
                        lengthDeterminant.setBeginByteAligned();
                    }
                    else
                    {
                        lengthDeterminant =
                            PerUnalignedUtils.encodeSemiConstrainedLength(extensionBitFieldSize);
                    }
                    listBuilder.Add(lengthDeterminant);
                }
                listBuilder.Add(extensions);
                foreach (SequenceComponent component in extensionComponents)
                {
                    if (component.isExplicitlySet())
                    {
                        IEnumerable<BitStream> extensionValues = null;
                        if (aligned)
                        {
                            extensionValues = PerAlignedUtils.encodeOpenTypeField(component.getComponentValue());
                        }
                        else
                        {
                            extensionValues = PerUnalignedUtils.encodeOpenTypeField(component.getComponentValue());
                        }
                        using(var secuence = extensionValues.GetEnumerator())
                        {
                            while (secuence.MoveNext())
                            {
                                // Do something with sequenceEnum.Current.
                                listBuilder.Add(secuence.Current);
                            }
                        } 
                        //listBuilder.addAll(extensionValues);
                    }
                }
            }
            return listBuilder.ToImmutable();
        }


        public override IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl(false);
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl(true);
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl< SequenceComponent>(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl< SequenceComponent>(reader, true);
        }
        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        private void decodePerImpl<T>(BitStreamReader reader, bool aligned) where T: SequenceComponent
        {
            bool hasExtensionValuesToDecode = false;
            if (isExtensible())
            {
                hasExtensionValuesToDecode = reader.readBit();
            }

            IEnumerable<SequenceComponent> components = getComponents();
            int bitFieldSize = calculateBitFieldSize(components);
            if (bitFieldSize >= PerAlignedUtils.SIXTYFOUR_K)
            {
                throw new UnsupportedOperationException("unimplemented");
            }
            foreach (SequenceComponent component in components)
            {
                if (component.isOptional() || component.hasDefaultValue())
                {
                    if (reader.readBit())
                    {
                        component.setToNewInstance();
                    }
                }
                else
                {
                    component.setToNewInstance();
                }
            }

            foreach (SequenceComponent component in components)
            {
                if (component.isExplicitlySet())
                {
                    if (aligned)
                    {
                        component.getComponentValue().decodePerAligned(reader);
                    }
                    else
                    {
                        component.getComponentValue().decodePerUnaligned(reader);
                    }
                }
            }

            if (hasExtensionValuesToDecode)
            {
                IEnumerable<SequenceComponent> extensionComponents = getExtensionComponents();
                int extensionBitFieldSize;
                if (reader.readBit())
                {
                    if (aligned)
                    {
                        reader.spoolToByteBoundary();
                        extensionBitFieldSize =
                            PerAlignedUtils.decodeSemiConstrainedLength(reader);
                    }
                    else
                    {
                        extensionBitFieldSize =
                            PerUnalignedUtils.decodeSemiConstrainedLength(reader);
                    }
                }
                else
                {
                    extensionBitFieldSize = 1 + reader.readLowBits(6);
                }
                foreach (SequenceComponent component in extensionComponents)
                {
                    if (extensionBitFieldSize > 0)
                    {
                        --extensionBitFieldSize;
                        if (reader.readBit())
                        {
                            component.setToNewInstance();
                        }
                    }
                }
                int unknownExtensionCount = 0;
                for (; extensionBitFieldSize > 0; --extensionBitFieldSize)
                {
                    if (reader.readBit())
                    {
                        ++unknownExtensionCount;
                    }
                }
                foreach (SequenceComponent component in extensionComponents)
                {
                    if (component.isExplicitlySet())
                    {
                        if (aligned)
                        {
                            byte[] encodedComponent =
                                PerAlignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                            component.getComponentValue().decodePerAligned(new BitStreamReader(encodedComponent));
                        }
                        else
                        {
                            byte[] encodedComponent =
                                PerUnalignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                            component.getComponentValue().decodePerUnaligned(new BitStreamReader(encodedComponent));
                        }
                    }
                }
                for (; unknownExtensionCount > 0; --unknownExtensionCount)
                {
                    if (aligned)
                    {
                        byte[] unknownEncodedExtension =
                            PerAlignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                    }
                    else
                    {
                        byte[] unknownEncodedExtension =
                            PerUnalignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                    }
                }
            }
        }
    }
}