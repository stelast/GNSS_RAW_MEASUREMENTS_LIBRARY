﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class Asn1TagClass
    {
        public enum AsnTagClassEnum
        {
            UNIVERSAL,
            APPLICATION,
            CONTEXT,
            PRIVATE
        }

        private readonly AsnTagClassEnum value;

        private Asn1TagClass(AsnTagClassEnum value)
        {
            this.value = value;
        }

        public static Asn1TagClass fromValue(int tagClass)
        {
            switch (tagClass)
            {
                case 0: return new Asn1TagClass(AsnTagClassEnum.UNIVERSAL);
                case 1: return new Asn1TagClass(AsnTagClassEnum.APPLICATION);
                case 2: return new Asn1TagClass(AsnTagClassEnum.CONTEXT);
                case 3: return new Asn1TagClass(AsnTagClassEnum.PRIVATE);
                default:
                    throw new SystemException("Invalid tag class: " + tagClass);
            }
        }

        public AsnTagClassEnum getValue()
        {
            return value;
        }
    }
}