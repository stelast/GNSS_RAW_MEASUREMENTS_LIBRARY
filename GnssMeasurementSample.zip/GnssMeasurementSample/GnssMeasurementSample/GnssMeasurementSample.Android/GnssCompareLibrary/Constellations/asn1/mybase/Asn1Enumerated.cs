﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.Math;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public abstract class Asn1Enumerated : Asn1Object
    {
        //private static readonly List<Asn1Tag> possibleFirstTags =
        //    ImmutableList.of(Asn1Tag.ENUMERATED);

        public Value value;

        /** Represents a single value within the enumeration. */
        public interface Value
        {
            int getAssignedValue();
            bool isExtensionValue();
            int ordinal(); // Standard enum method.
        }

        //public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        //{
        //    return possibleFirstTags;
        //}

        public Value getValue()
        {
            return value;
        }

        public void setValue(Value value)
        {
            this.value = value;
        }
         
        protected Value getDefaultValue()
        {
            return null;
        }

        protected abstract bool isExtensible();

        /**
         * Returns the ordinal:th value in size order.
         */
        protected abstract Value lookupValue(int ordinal);

        /**
         * Returns the ordinal:th extension value in size order.
         */
        protected abstract Value lookupExtensionValue(int ordinal);

        /**
         * Returns the number of distinct values (not counting extensions).
         */
        protected abstract int getValueCount();



        public override void decodeBerValue(ByteBuffer buf)
        {
            if (!buf.HasRemaining)
            {
                value = getDefaultValue();
                return;
            }
            Asn1Integer ai = new Asn1Integer();
            ai.decodeBerValue(buf);
            value = lookupValue(ai.getInteger().IntValue());
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            asAsn1Integer().encodeBerValue(buf);
        }

        public override int getBerValueLength()
        {
            return asAsn1Integer().getBerValueLength();
        }
        private Asn1Integer asAsn1Integer()
        {
            //Preconditions.CheckNotNull(value, "No value set.");
            Asn1Integer ai = new Asn1Integer();
            ai.setInteger(BigInteger.ValueOf(value.getAssignedValue()));
            return ai;
        }

        public override Asn1Tag getDefaultTag()
        {
            return Asn1Tag.ENUMERATED;
        }

        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            if (!reader.hasBit())
            {
                value = getDefaultValue();
                return;
            }
            if (isExtensible() && reader.readBit())
            {
                if (aligned)
                {
                    value = lookupExtensionValue(PerAlignedUtils.decodeNormallySmallWholeNumber(reader));
                }
                else
                {
                    value = lookupExtensionValue(PerUnalignedUtils.decodeNormallySmallWholeNumber(reader));
                }
            }
            else
            {
                if (aligned)
                {
                    value = lookupValue(
                        PerAlignedUtils.decodeSmallConstrainedWholeNumber(
                            reader, 0, getValueCount() - 1));
                }
                else
                {
                    value = lookupValue(
                        PerUnalignedUtils.decodeConstrainedWholeNumber(
                            reader, 0, getValueCount() - 1));
                }
            }
        }
        public override IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl<SequenceComponent>(true);
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl<SequenceComponent>(false);
        }

        private IEnumerable<BitStream> encodePerImpl<T>(bool aligned) where T : SequenceComponent
        {
            ImmutableList<BitStream>.Builder builder = ImmutableList.CreateBuilder<BitStream>();
            if (isExtensible())
            {
                BitStream extensionMarker = new BitStream();
                extensionMarker.appendBit(value.isExtensionValue());
                builder.Add(extensionMarker);
            }
            if (value.isExtensionValue())
            {
                if (aligned)
                {
                    using (var secuence = PerAlignedUtils.encodeNormallySmallWholeNumber(value.ordinal()).GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            builder.Add(secuence.Current);
                        }
                    }
                    //builder.addAll(
                      //  PerAlignedUtils.encodeNormallySmallWholeNumber(value.ordinal()));
                }
                else
                {
                    using (var secuence = PerUnalignedUtils.encodeNormallySmallWholeNumber(value.ordinal()).GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            builder.Add(secuence.Current);
                        }
                    }
                    //builder.addAll(
                       // PerUnalignedUtils.encodeNormallySmallWholeNumber(value.ordinal()));
                }
            }
            else
            {
                // Note that it is NOT guaranteed in the asn1 spec that the root values
                // are sorted in order. However, asn12j sorts them for us.
                if (aligned)
                {
                    builder.Add(
                        PerAlignedUtils.encodeSmallConstrainedWholeNumber(
                            value.ordinal(), 0, getValueCount() - 1));
                }
                else
                {
                    builder.Add(
                        PerUnalignedUtils.encodeConstrainedWholeNumber(
                            value.ordinal(), 0, getValueCount() - 1));
                }
            }
            return builder.ToImmutable();
            //return builder.build();
        }
    }
}