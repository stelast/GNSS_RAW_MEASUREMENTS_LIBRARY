﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class SessionID : Asn1Sequence 
    {
        public SessionID() : base()
        {
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return false;
        }

        /**
         * Creates a new SessionID from encoded stream.
         */
        public static SessionID fromPerUnaligned(byte[] encodedBytes)
        {
            SessionID result = new SessionID();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SessionID from encoded stream.
         */
        public static SessionID fromPerAligned(byte[] encodedBytes)
        {
            SessionID result = new SessionID();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        private SetSessionID setSessionID_;
        public SetSessionID getSetSessionID()
        {
            return setSessionID_;
        }
        /**
         * @throws ClassCastException if value is not a SetSessionID
         */
        public void setSetSessionID(Asn1Object value)
        {
            this.setSessionID_ = (SetSessionID)value;
        }
        public SetSessionID setSetSessionIDToNewInstance()
        {
            setSessionID_ = new SetSessionID();
            return setSessionID_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            SessionID objeto;
            public M1(SessionID objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSetSessionID();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SetSessionID.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSetSessionID() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return true;
            }

            public void setToNewInstance()
            {
                this.objeto.setSetSessionIDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "setSessionID : " + this.objeto.getSetSessionID().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            SessionID objeto;
            public M2(SessionID objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSlpSessionID();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SlpSessionID.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSlpSessionID() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return true;
            }

            public void setToNewInstance()
            {
                this.objeto.setSlpSessionIDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "slpSessionID : " + this.objeto.getSlpSessionID().toIndentedString(indent);
            }
        }
         

        private SlpSessionID slpSessionID_;
        public SlpSessionID getSlpSessionID()
        {
            return slpSessionID_;
        }
        /**
         * @throws ClassCastException if value is not a SlpSessionID
         */
        public void setSlpSessionID(Asn1Object value)
        {
            this.slpSessionID_ = (SlpSessionID)value;
        }
        public SlpSessionID setSlpSessionIDToNewInstance()
        {
            slpSessionID_ = new SlpSessionID();
            return slpSessionID_;
        }


    }
}