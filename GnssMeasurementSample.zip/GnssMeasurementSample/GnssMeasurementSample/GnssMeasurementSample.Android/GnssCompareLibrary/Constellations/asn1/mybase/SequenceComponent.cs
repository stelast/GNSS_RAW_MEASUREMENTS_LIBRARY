﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public interface SequenceComponent
    { 
        bool isExplicitlySet();

        bool hasDefaultValue();

        bool isOptional();

        Asn1Object getComponentValue();

        void setToNewInstance();

        /**
         * Returns tags that may be the initial tag in the BER encoding of this type.
         */
        ImmutableList<Asn1Tag> getPossibleFirstTags();

        Asn1Tag getTag();

        bool isImplicitTagging();

        string toIndentedString(string indent);
    }
}