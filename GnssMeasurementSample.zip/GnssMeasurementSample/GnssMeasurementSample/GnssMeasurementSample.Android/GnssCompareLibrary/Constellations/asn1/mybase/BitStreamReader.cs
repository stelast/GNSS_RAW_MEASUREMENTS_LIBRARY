﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class BitStreamReader
    {
        private static readonly int BITS_IN_BYTE = 8;

        private readonly ByteReader byteReader;
        private int bitsRead = 0;

        /** Used to iteratively read bytes. ByteIterator is already used, with a different signature. */
        protected interface ByteReader
        {
            bool isDone();

            /**
             * Returns the current byte.
             *
             * @throws IndexOutOfBoundsException if there is no more data.
             */
            byte value();

            void next();
        }

        /** Implements a byte reader using a single byte array. */
        public class SingleBufferByteReader : ByteReader
        {
            private readonly byte[] buffer;
            private int position = 0;

            public SingleBufferByteReader(byte[] bytes)
            {
                buffer = bytes;
            }

            public bool isDone()
            {
                return position >= buffer.Count();
            }

            public byte value()
            {
                return buffer[position];
            }

            public void next()
            {
                ++position;
            }
        }

        protected BitStreamReader(ByteReader byteReader)
        {
            this.byteReader = byteReader;
        }

        public BitStreamReader(byte[] bytes)
        {
            this.byteReader = new SingleBufferByteReader(bytes);
        }

        /**
         * Returns true if the next bit in the stream is set.
         * @throws IndexOutOfBoundsException if there is no more data.
         */
        public bool readBit()
        {
            bitsRead++;
            if (bitsRead > BITS_IN_BYTE)
            {
                byteReader.next();
                bitsRead = 1;
            }
            return ((byteReader.value() >> (BITS_IN_BYTE - bitsRead)) & 1) == 1;
        }

        /**
         * Returns true if there is another readable bit in the stream.
         */
        public bool hasBit()
        {
            if (byteReader.isDone())
            {
                return false;
            }
            if (bitsRead < BITS_IN_BYTE)
            {
                return true;
            }
            byteReader.next();
            bitsRead = 0;
            return !byteReader.isDone();
        }

        public void spoolToByteBoundary()
        {
            if (bitsRead == 0)
            {
                return;
            }
            bitsRead = 0;
            byteReader.next();
        }

        /**
         * Returns next byte's worth of data (8 bits) from the stream.
         * @throws IndexOutOfBoundsException if there is no more data.
         */
        public byte readByte()
        {
            int mask = (1 << (8 - bitsRead)) - 1;
            byte result = (byte)((byteReader.value() & mask) << bitsRead);
            byteReader.next();
            if (bitsRead > 0)
            {
                var th = (int)((uint)(byteReader.value() & 0xFF) >> (8 - bitsRead));
                result = (byte)(result | th);
            }
            return result;
        }

        /**
         * Returns next {@code howMany} bits as the low bits in the returned byte.
         * @throws IndexOutOfBoundsException if there is no more data.
         */
        public int readLowBits(int howMany)
        {
            int result = 0;
            for (int i = 0; i < howMany; i++)
            {
                result <<= 1;
                result |= (readBit() ? 1 : 0);
            }
            return result;
        }
    }
}