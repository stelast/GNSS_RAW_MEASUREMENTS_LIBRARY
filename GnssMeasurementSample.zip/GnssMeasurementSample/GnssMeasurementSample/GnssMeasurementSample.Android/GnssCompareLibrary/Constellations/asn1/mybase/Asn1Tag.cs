﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Java.Math;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase.Asn1TagClass;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class Asn1Tag
    {
        public static readonly Asn1Tag boolean = new Asn1Tag(Asn1TagClass.fromValue(0), 1);
        public static readonly Asn1Tag INTEGER = new Asn1Tag(Asn1TagClass.fromValue(0), 2);
        public static readonly Asn1Tag BIT_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 3);
        public static readonly Asn1Tag OCTET_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 4);
        public static readonly Asn1Tag NULL = new Asn1Tag(Asn1TagClass.fromValue(0), 5);
        public static readonly Asn1Tag OBJECT_IDENTIFIER = new Asn1Tag(Asn1TagClass.fromValue(0), 6);
        public static readonly Asn1Tag OBJECT_DESCRIPTOR = new Asn1Tag(Asn1TagClass.fromValue(0), 7);
        public static readonly Asn1Tag REAL = new Asn1Tag(Asn1TagClass.fromValue(0), 9);
        public static readonly Asn1Tag ENUMERATED = new Asn1Tag(Asn1TagClass.fromValue(0), 10);
        public static readonly Asn1Tag UTF8STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 12);
        public static readonly Asn1Tag SEQUENCE = new Asn1Tag(Asn1TagClass.fromValue(0), 16);
        public static readonly Asn1Tag SET = new Asn1Tag(Asn1TagClass.fromValue(0), 17);
        public static readonly Asn1Tag NUMERIC_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 18);
        public static readonly Asn1Tag PRINTABLE_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 19);
        public static readonly Asn1Tag TELETEX_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 20);
        public static readonly Asn1Tag VIDEOTEX_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 21);
        public static readonly Asn1Tag IA5_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 22);
        public static readonly Asn1Tag UTC_TIME = new Asn1Tag(Asn1TagClass.fromValue(0), 23);
        public static readonly Asn1Tag GENERALIZED_TIME = new Asn1Tag(Asn1TagClass.fromValue(0), 24);
        public static readonly Asn1Tag GRAPHIC_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 25);
        public static readonly Asn1Tag VISIBLE_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 26);
        public static readonly Asn1Tag GENERAL_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 27);
        public static readonly Asn1Tag UNIVERSAL_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 28);
        public static readonly Asn1Tag BMP_STRING = new Asn1Tag(Asn1TagClass.fromValue(0), 30);
        public static readonly int CONSTRUCTED_BIT = 0x20;
        public static readonly BigInteger MAX_INTEGER_VALUE = BigInteger.ValueOf(Integer.MaxValue);

          private readonly Asn1TagClass tagClass;
          private readonly int tagNumber;

        public Asn1Tag(Asn1TagClass tagClass, int tagNumber)
        {
            this.tagClass = tagClass;
            this.tagNumber = tagNumber;
        }

        virtual public int getTaggedLength(int valueLength)
        {
            if (tagNumber > 30)
            {
                throw new SystemException("Tags with value > 30 not supported");
            }
            return 1 + getLengthLength(valueLength) + valueLength;
        }

        /**
         * Returns the number of octets needed for the length field for a value
         * of the specified size. The returned number will be the smallest possible
         * number of octets needed for the length field.
         *
         * @param valueLength number of octets used to BER encode the value
         */
        
        static int getLengthLength(int valueLength)
        {
            if (valueLength < 0)
            {
                throw new SystemException("valueLength=" + valueLength);
            }
            if (valueLength < (1 << 7))
            {
                // short form
                return 1;
            }
            else if (valueLength < (1 << 8))
            {
                return 2;
            }
            else if (valueLength < (1 << 16))
            {
                return 3;
            }
            else if (valueLength < (1 << 24))
            {
                return 4;
            }
            else
            {
                return 5;
            }
        }

        virtual public void writeTagAndLength(ByteBuffer buf, bool constructed, int valueLength)
        {
            this.writeTag(buf, constructed);
            writeLength(buf, valueLength);
        }

        private void writeTag(ByteBuffer buf, bool constructed)
        {
            if (tagNumber > 30)
            {
                throw new SystemException("Tags with value > 30 not supported");
            }
            if (constructed)
            {
                buf.Put((sbyte)(getValue() | CONSTRUCTED_BIT));
            }
            else
            {
                buf.Put((sbyte)getValue());
            }
        }

        public static Asn1Tag readTag(ByteBuffer buf)
        {
            return Asn1Tag.fromValue(buf.Get() & 0xFF);
        }

        /**
         * Returns the tag at the head of the buffer without advancing the position.
         */
        public static Asn1Tag peekTag(ByteBuffer buf)
        {
            return Asn1Tag.fromValue(buf.Get(buf.Position()) & 0xFF);
        }

        /**
         * Returns the value of the tag octet - including class and tag ID but excluding
         * the 'C' (composed) bit.
         */
        virtual public int getValue()
        {
            return ((int)tagClass.getValue() << 6) + tagNumber;
        }


        public static void writeLength(ByteBuffer buf, int valueLength)
        {
            if (valueLength < 0)
            {
                throw new SystemException("valueLength=" + valueLength);
            }
            if (valueLength < (1 << 7))
            {
                buf.Put((sbyte)valueLength);
            }
            else
            {
                // Long form: the low 7 bits of the first octet encodes the number of following
                // octets that holds the actual length. The top bit is 1 to indicate long form.
                byte[] lengthBytes = BigInteger.ValueOf(valueLength).ToByteArray();
                if (lengthBytes[0] == (byte)0x00)
                {
                    // the length bytes are unsigned so throw away the leading zero octet.
                    // For example, 128 becomes { 0x00, 0x80 } and we drop the first 0x00.
                    int len = lengthBytes.Count() - 1;
                    byte[] newLengthBytes = new byte[len];
                    System.Array.Copy(lengthBytes, 1, newLengthBytes, 0, len);
                    lengthBytes = newLengthBytes;
                }
                buf.Put((sbyte)(lengthBytes.Count() | (1 << 7)));
                buf.Put(lengthBytes);
            }
        }

        public static int readLength(ByteBuffer buf)
        {
            int n = buf.Get() & 0xFF;
            if (n < (1 << 7))
            {
                // short form of the length field - single octet with high order bit 0
                return n;
            }
            else
            {
                // long form - first octet contains number of subsequent octets used to encode the length
                n = n & 0x7F;
                if (n > 5)
                {
                    throw new SystemException("Length length too big: " + n + " octets");
                }
                byte[] val = new byte[n];
                for (int i = 0; i < n; i++)
                {
                    val[i] = (byte)buf.Get();
                }
                val = prependZeroByteIfHighBitSet(val);
                BigInteger bi = new BigInteger(val);
                if (bi.CompareTo(MAX_INTEGER_VALUE) > 0)
                {
                    throw new SystemException("Lengths bigger than 2^^31-1 unsupported: " + bi);
                }
                return bi.IntValue();
            }
        }

        private static byte[] prependZeroByteIfHighBitSet(byte[] ba)
        {
            if ((ba[0] & 0x80) != 0)
            {
                byte[] newba = new byte[ba.Count() + 1];
                System.Array.Copy(ba, 0, newba, 1, ba.Count());
                newba[0] = 0;
                ba = newba;
            }
            return ba;
        }

        /**
         * Returns the tag with the specified value (including tag and length, excluding "constructed"
         * bit).
         */
        private static Asn1Tag fromValue(int value)
        {
            Asn1Tag result = new Asn1Tag(Asn1TagClass.fromValue(value >> 6), value & 0x1F);
            if (result.tagNumber > 30)
            {
                throw new SystemException("Tags with value > 30 not supported (" + result.tagNumber
                    + ")");
            }
            return result;
        }

        /**
         * Returns the tag corresponding to the given class and number.
         *
         * <p>By convention, null is returned for impossible tag class < 0. Used in code generation.
         */
         public static Asn1Tag fromClassAndNumber(int tagClass, int tagNumber)
        {
            if (tagClass < 0)
            {
                return null;
            }
            return new Asn1Tag(Asn1TagClass.fromValue(tagClass), tagNumber);
        }

        
        public bool equals(object o)
        {
            if (!(o is Asn1Tag)) {
                return false;
            }
            Asn1Tag tag = (Asn1Tag)o;
            return tagClass == tag.tagClass && tagNumber == tag.tagNumber;
        }

        
        public int hashCode()
        {
            int result = 17;
            result = 31 * result + tagClass.GetHashCode();
            result = 31 * result + tagNumber;
            return result;
        }

        
        public string toString()
        {
            return "Asn1Tag[" + tagClass + ", " + tagNumber + "]";
        }
    }
}