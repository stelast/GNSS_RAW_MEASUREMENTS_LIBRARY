﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Java.Math;
using Java.Util;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class PerUnalignedUtils
    {
        /**
           * Encodes whole numbers up to 64K range according to X.691-0207, 10.5.
           */
        public static BitStream encodeConstrainedWholeNumber(
            int value, int minimumValue, int maximumValue)
        {
            int normalizedValue = value - minimumValue;
            // Note: range here means one less than in ASN.1 X.691-0207, 10.5.
            int range = maximumValue - minimumValue;
            return encodeNormalizedConstrainedWholeNumber(normalizedValue, range);
        }

        /**
         * Encodes the difference between the actual value and the minimum allowed
         * value, the {@code normalizedValue}, for whole numbers up to 64K range
         * according to X.691-0207, 10.5.
         *
         * <p>Note: range here means one less than in ASN.1 X.691-0207, 10.5., i.e.
         * here it is the difference between the maximum allowed value and the minimum
         * allowed value.
         */
        public static BitStream encodeNormalizedConstrainedWholeNumber(
            long normalizedValue, long range)
        {
            BitStream result = new BitStream();
            int bits = leastBitsToEncodeLong(range);
            for (int i = bits - 1; i >= 0; --i)
            {
                result.appendBit((normalizedValue >> i & 1) != 0);
            }
            return result;
        }

        public static int decodeConstrainedWholeNumber(
            BitStreamReader reader, int minimumValue, int maximumValue)
        {
            // Note: range here means one less than in ASN.1 X.691-0207, 10.5.
            long range = (long)maximumValue - (long)minimumValue;
            long normalizedResult =
                decodeNormalizedConstrainedWholeNumber(reader, range);
            return (int)normalizedResult + minimumValue;
        }

        /**
         * Decodes the difference between the actual value and the minimum allowed
         * value for whole numbers up to 64K range according to X.691-0207, 10.5.
         *
         * <p>Note: range here means one less than in ASN.1 X.691-0207, 10.5., i.e.
         * here it is the difference between the maximum allowed value and the minimum
         * allowed value.
         */
        public static long decodeNormalizedConstrainedWholeNumber(
            BitStreamReader reader, long range)
        {
            long result = 0;
            int bits = leastBitsToEncodeLong(range);
            for (int i = 0; i < bits; ++i)
            {
                result <<= 1;
                result |= reader.readBit() ? 1 : 0;
            }
            return result;
        }

        private static int leastBitsToEncodeLong(long value)
        {
            for (int bits = 1; bits < 64; bits++)
            {
                if (value < (1L << bits))
                {
                    return bits;
                }
            }
            return 64;
        }

        public static IEnumerable<BitStream> encodeNormallySmallWholeNumber(int value)
        {
            if (value < 64)
            {
                BitStream result = new BitStream();
                result.appendBit(false);
                result.appendLowBits(6, (byte)value);

                var builder3 = ImmutableList.CreateBuilder<BitStream>();
                builder3.Add(result);
                return builder3.ToImmutable();
                //return ImmutableList.of(result);
            }
            throw new UnsupportedOperationException("normally small numbers >= 64 "
                                                    + "unimplemented");
        }

        public static int decodeNormallySmallWholeNumber(BitStreamReader reader)
        {
            if (reader.readBit())
            {
                throw new SystemException("normally small numbers >= 64 "
                                                        + "unimplemented");
            }
            return reader.readLowBits(6) & 0xFF;
        }

        /**
         * Encodes length determinant for a constrained length byte[] according to
         * X.691-0207, 10.9.3.3 and up.
         */
        public static IEnumerable<BitStream> encodeConstrainedLengthOfBytes(
            byte[] bytes, int minimumLength, int maximumLength)
        {
            if (maximumLength >= PerAlignedUtils.SIXTYFOUR_K)
            {
                return encodeSemiConstrainedLengthOfBytes(bytes);
            }

            BitStream lengthDeterminant = encodeConstrainedWholeNumber(
                bytes.Length, minimumLength, maximumLength);
            if (bytes.Length == 0)
            {
                var builder3 = ImmutableList.CreateBuilder<BitStream>();
                builder3.Add(lengthDeterminant);
                return builder3.ToImmutable();
                //return ImmutableList.of(lengthDeterminant);
            }
            BitStream value = new BitStream();
            foreach (byte aByte in bytes)
            {
                value.appendByte(aByte);
            }
            var builder = ImmutableList.CreateBuilder<BitStream>();
            builder.Add(lengthDeterminant);
            builder.Add(value);
            return builder.ToImmutable();
            //return ImmutableList.of(lengthDeterminant, value);
        }

        /**
         * Decodes a constrained length byte[] with length determinant according to
         * X.691-0207, 10.9.3.3 and up.
         */
        public static byte[] decodeConstrainedLengthOfBytes(
            BitStreamReader reader, int minimumLength, int maximumLength)
        {
            if (maximumLength >= PerAlignedUtils.SIXTYFOUR_K)
            {
                return decodeSemiConstrainedLengthOfBytes(reader);
            }
            int length = decodeConstrainedWholeNumber(
                reader, minimumLength, maximumLength);
            if (length == 0)
            {
                return new byte[0];
            }
            byte[] result = new byte[length];
            for (int i = 0; i < length; i++)
            {
                result[i] = reader.readByte();
            }
            return result;
        }

        /**
         * Encodes length determinant for a semi-constrained length byte[] according
         * to X.691-0207, 10.9.3.5.
         */
        public static IEnumerable<BitStream> encodeSemiConstrainedLengthOfBytes(
            byte[] bytes)
        {
            int n = bytes.Length;
            if (n < PerAlignedUtils.SIXTEEN_K)
            {
                BitStream result = encodeSemiConstrainedLength(n);
                foreach (byte b in bytes)
                {
                    result.appendByte(b);
                }
                var builder = ImmutableList.CreateBuilder<BitStream>();
                builder.Add(result);
                return builder.ToImmutable();
                //return ImmutableList.of(result);
            }
            throw new UnsupportedOperationException("Arrays > 16K unimplemented.");
        }

        /**
         * Decodes length determinant for a semi-constrained length byte[] according
         * to X.691-0207, 10.9.3.5.
         */
        public static byte[] decodeSemiConstrainedLengthOfBytes(
            BitStreamReader reader)
        {
            int length = decodeSemiConstrainedLength(reader);
            byte[] result = new byte[length];
            for (int i = 0; i < length; i++)
            {
                result[i] = reader.readByte();
            }
            return result;
        }

        /**
         * Encodes non-negative numbers according to X.691-0207, 10.3.
         */
        public static byte[] encodeBigNonNegativeWholeNumber(BigInteger bigInteger)
        {
            byte[] twosComplement = bigInteger.ToByteArray();
            return twosComplement[0] == 0
                   ? Arrays.CopyOfRange(twosComplement, 1, twosComplement.Count())
                   : twosComplement;
        }

        /**
          * Decodes non-negative numbers according to X.691-0207, 10.3.
          */
        public static BigInteger decodeBigNonNegativeWholeNumber(byte[] encoded)
        {
            return new BigInteger(1, encoded);
        }

        /**
         * Encodes length determinant according to X.691-0207, 10.9.3.6.
         */
        public static BitStream encodeSemiConstrainedLength(int value)
        {
            if (value <= 127)
            {
                BitStream result = new BitStream();
                result.appendBit(false);
                result.appendLowBits(7, (byte)value);
                return result;
            }
            else if (value < PerAlignedUtils.SIXTEEN_K)
            {
                BitStream result = new BitStream();
                result.appendBit(true);
                result.appendBit(false);
                var th = (int)((uint)value >> 8);
                result.appendLowBits(6, (byte)(th));
                result.appendByte((byte)(value & 0xFF));
                return result;
            }

            throw new SystemException("Length values > " +
                                                     PerAlignedUtils.SIXTEEN_K + "unimplemented");
        }

        /**
         * Decodes length determinant according to X.691-0207, 10.9.3.6.
         */
        public static int decodeSemiConstrainedLength(BitStreamReader reader)
        {
            if (!reader.readBit())
            {
                return reader.readLowBits(7);
            }
            else if (!reader.readBit())
            {
                return (reader.readLowBits(6) << 8) + (reader.readByte() & 0xFF);
            }
            else
            {
                throw new SystemException("Length values > " +
                                                         PerAlignedUtils.SIXTEEN_K + "unimplemented");
            }
        }

        /*
         * Encodes an Asn1Object into a  Open type field (X.691-0207, 10.2), used
         * mostly for encoding Sequence and SetOf extension additions. A decode method
         * hasn't been added as the extension additions should decoded
         * by their relevent Asn1Object decoders.
         */
        public static IEnumerable<BitStream> encodeOpenTypeField(Asn1Object objecto)
        {
            PacketBuilder packetBuilder = new PacketBuilder();
            packetBuilder.appendAll(objecto.encodePerUnaligned());
            return encodeSemiConstrainedLengthOfBytes(packetBuilder.getPaddedBytes());
        }

        public static Asn1Object decodeOpenTypeField(
                                    BitStreamReader reader, Asn1Object asn1Object)
        {
            byte[] encodedBytes = decodeSemiConstrainedLengthOfBytes(reader);
            asn1Object.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return asn1Object;
        }

    }
}