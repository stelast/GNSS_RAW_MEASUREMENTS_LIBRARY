﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.IO;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public abstract class BaseEncoding
    {
    //    private static readonly BaseEncoding BASE64 = new BaseEncoding.Base64Encoding("base64()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", '=');
    //    private static readonly BaseEncoding BASE64_URL = new BaseEncoding.Base64Encoding("base64Url()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", '=');
    //    private static readonly BaseEncoding BASE32 = new BaseEncoding.StandardBaseEncoding("base32()", "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", '=');
    //    private static readonly BaseEncoding BASE32_HEX = new BaseEncoding.StandardBaseEncoding("base32Hex()", "0123456789ABCDEFGHIJKLMNOPQRSTUV", '=');
    //    private static readonly BaseEncoding BASE16 = new BaseEncoding.Base16Encoding("base16()", "0123456789ABCDEF");

    //    BaseEncoding()
    //    {
    //    }

    //    public string encode(byte[] bytes)
    //    {
    //        return this.encode(bytes, 0, bytes.Length);
    //    }

         
    //public abstract InputStream decodingStream(Reader var1);
         
    //public ByteSource decodingSource(CharSource encodedSource)
    //    {
    //        Preconditions.CheckNotNull(encodedSource);
    //        return new ByteSource()
    //        {
    //        public InputStream openStream() {
    //            return BaseEncoding.this.decodingStream(encodedSource.openStream());
    //        }
    //    };
    //}

    //abstract int maxEncodedSize(int var1);

    //abstract void encodeTo(Appendable var1, byte[] var2, int var3, int var4) throws IOException;

    //abstract int maxDecodedSize(int var1);

    //abstract int decodeTo(byte[] var1, CharSequence var2) throws BaseEncoding.DecodingException;

    //abstract CharMatcher padding();

    
    //public abstract BaseEncoding omitPadding();

    
    //public abstract BaseEncoding withPadChar(char var1);

    
    //public abstract BaseEncoding withSeparator(String var1, int var2);

    
    //public abstract BaseEncoding upperCase();

    
    //public abstract BaseEncoding lowerCase();

    //public static BaseEncoding base64()
    //{
    //    return BASE64;
    //}

    //public static BaseEncoding base64Url()
    //{
    //    return BASE64_URL;
    //}

    //public static BaseEncoding base32()
    //{
    //    return BASE32;
    //}

    //public static BaseEncoding base32Hex()
    //{
    //    return BASE32_HEX;
    //}

    //public static BaseEncoding base16()
    //{
    //    return BASE16;
    //}

    //public string encode(byte[] bytes, int off, int len)
    //    {
    //        Preconditions.CheckPositionIndexes(off, off + len, bytes.Length);
    //        StringBuilder result = new StringBuilder(this.maxEncodedSize(len));

    //        try
    //        {
    //            this.encodeTo(result, bytes, off, len);
    //        }
    //        catch (IOException var6)
    //        {
    //            throw new AssertionError();
    //        }

    //        return result.tostring();
    //    }

    //    public abstract OutputStream encodingStream(Writer var1);

    //    public readonly ByteSink encodingSink(readonly CharSink encodedSink)
    //    {
    //        Preconditions.checkNotNull(encodedSink);
    //        return new ByteSink()
    //    {
    //        public OutputStream openStream()
    //        {
    //            return BaseEncoding.this.encodingStream(encodedSink.openStream());
    //        }
    //    };
    //}

    //private static byte[] extract(byte[] result, int length)
    //{
    //    if (length == result.Length)
    //    {
    //        return result;
    //    }
    //    else
    //    {
    //        byte[] trunc = new byte[length];
    //        System.Array.Copy(result, 0, trunc, 0, length);
    //        return trunc;
    //    }
    //}

    //public readonly byte[] decode(CharSequence chars)
    //{
    //    try
    //    {
    //        return this.decodeChecked(chars);
    //    }
    //    catch (BaseEncoding.DecodingException var3)
    //    {
    //        throw new IllegalArgumentException(var3);
    //    }
    //}

    //    readonly byte[] decodeChecked(CharSequence chars) throws BaseEncoding.DecodingException
    //    {
    //        CharSequence chars = this.padding().trimTrailingFrom(chars);
    //        byte[]
    //        tmp = new byte[this.maxDecodedSize(chars.length())];
    //        int len = this.decodeTo(tmp, chars);
    //        return extract(tmp, len);
    //    }
    }
}