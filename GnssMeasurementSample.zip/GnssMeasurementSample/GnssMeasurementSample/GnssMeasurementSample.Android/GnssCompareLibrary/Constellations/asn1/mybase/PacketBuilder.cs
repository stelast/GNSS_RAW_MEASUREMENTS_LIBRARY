﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class PacketBuilder
    {
        private readonly BitStream bitStream;

  public PacketBuilder() : this(0)
        { 
        }

        public PacketBuilder( int bufferSize)
        {
            this.bitStream = (bufferSize == 0) ? new BitStream() : new BitStream(bufferSize);
        }

        public void append(BitStream appendix)
        {
            if (appendix.beginsByteAligned())
            {
                bitStream.spoolToByteBoundary();
            }
            int bitsToAppend = appendix.getBitCount();
            byte[] bytes = appendix.getPaddedBytes();
            for (int i = 0; bitsToAppend >= 8; i++, bitsToAppend -= 8)
            {
                bitStream.appendByte(bytes[i]);
            }
            if (bitsToAppend != 0)
            {
                byte highBits = bytes[bytes.Length - 1];
                byte lowBits = (byte)((highBits & 0xFF)
                                       >> (8 - bitsToAppend));
                bitStream.appendLowBits(bitsToAppend, lowBits);
            }
        }

        public byte[] getPaddedBytes()
        {
            return bitStream.getPaddedBytes();
        }

        public int getBitCount()
        {
            return bitStream.getBitCount();
        }

        public void appendAll(IEnumerable<BitStream> bitStreams)
        {
            foreach (BitStream bitStream in bitStreams)
            {
                append(bitStream);
            }
        }
    }
}