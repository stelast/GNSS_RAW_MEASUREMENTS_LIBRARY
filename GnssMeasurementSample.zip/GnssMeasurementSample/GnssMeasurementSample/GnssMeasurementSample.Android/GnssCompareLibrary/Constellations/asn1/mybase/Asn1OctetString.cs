﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Android.Support.V4.Util;
using Java.Nio;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class Asn1OctetString : Asn1Object
    {
        //private static readonly BaseEncoding HEX = BaseEncoding.base16();
        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.OCTET_STRING);
        private static readonly byte[] EMPTY_ARRAY = new byte[0];

        private int minimumSize = int.MinValue;
        private Nullable<int> maximumSize = null; // Null is unbounded.
        private byte[] value = EMPTY_ARRAY;
         
        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        protected void setMinSize(int min)
        {
            minimumSize = min;
        }

        protected void setMaxSize(int max)
        {
            maximumSize = max;
        }

        public byte[] getValue()
        {
            return value;
        }

        public void setValue(byte[] value)
        {
            Preconditions.CheckNotNull(value);
            this.value = value;
        }  
         
        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            if (maximumSize == null)
            {
                if (aligned)
                {
                    value = PerAlignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                }
                else
                {
                    value = PerUnalignedUtils.decodeSemiConstrainedLengthOfBytes(reader);
                }
                return;
            }
            else if (minimumSize == maximumSize)
            {
                value = new byte[maximumSize.Value];
                if (maximumSize == 0)
                {
                    return;
                }
                if (maximumSize < PerAlignedUtils.SIXTYFOUR_K)
                {
                    if (aligned && maximumSize > 2)
                    {
                        reader.spoolToByteBoundary();
                    }
                    for (int i = 0; i < maximumSize; i++)
                    {
                        value[i] = reader.readByte();
                    }
                    return;
                }
            }
            if (aligned)
            {
                value = PerAlignedUtils.decodeConstrainedLengthOfBytes(
                    reader, minimumSize, maximumSize.Value);
            }
            else
            {
                value = PerUnalignedUtils.decodeConstrainedLengthOfBytes(
                    reader, minimumSize, maximumSize.Value);
            }
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        //public String toIndentedString(String indent)
        //{
        //    return getTypeName() + " = [ " + HEX.encode(value) + " ];\n";
        //}

        protected String getTypeName()
        {
            return "";
        }

        public override Asn1Tag getDefaultTag()
        {
            return Asn1Tag.OCTET_STRING;
        }

        public override int getBerValueLength()
        {
            return value.Length;
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            buf.Put(value);
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            value = getRemaining(buf);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl(true);
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl(false);
        }

        private IEnumerable<BitStream> encodePerImpl(bool aligned)
        {
            Preconditions.CheckState(
                maximumSize == null || value.Length <= maximumSize, "Too large %s");
            if (maximumSize == null)
            {
                if (aligned)
                {
                    return PerAlignedUtils.encodeSemiConstrainedLengthOfBytes(value);
                }
                else
                {
                    return PerUnalignedUtils.encodeSemiConstrainedLengthOfBytes(value);
                }
            }
            else if (minimumSize == maximumSize)
            {
                if (maximumSize == 0)
                {
                    var builder = ImmutableList.CreateBuilder<BitStream>();
                    return builder.ToImmutable();
                    //return ImmutableList.of();
                }
                if (maximumSize < PerAlignedUtils.SIXTYFOUR_K)
                {
                    BitStream result = new BitStream();
                    for (int i = 0; i < maximumSize; i++)
                    {
                        result.appendByte(value[i]);
                    }
                    if (aligned && maximumSize > 2)
                    {
                        result.setBeginByteAligned();
                    }
                    var builder = ImmutableList.CreateBuilder<BitStream>();
                    builder.Add(result);
                    return builder.ToImmutable();
                    //return ImmutableList.of(result);
                }
            }
            if (aligned)
            {
                return PerAlignedUtils.encodeConstrainedLengthOfBytes(
                    value, minimumSize, maximumSize.Value);
            }
            else
            {
                return PerUnalignedUtils.encodeConstrainedLengthOfBytes(
                    value, minimumSize, maximumSize.Value);
            }
        }
    }
}