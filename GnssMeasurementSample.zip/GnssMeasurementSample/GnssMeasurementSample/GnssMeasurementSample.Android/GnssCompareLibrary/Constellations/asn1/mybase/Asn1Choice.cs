﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.Lang;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public abstract class Asn1Choice : Asn1Object
    {
        /**
           * Dummy non-tag used as default tag for CHOICE, which reflects the BER encoding idea
           * that CHOICE is not an object in itself, it just gets coded as its value. This means
           * that it doesn't matter whether the choice object tag is designated as IMPLICIT or
           * EXPLICIT, it gets coded the same way anyway.
           */
        private static Asn1Tag DUMMY_DEFAULT_TAG = new Asn1TagChoice(null, Integer.MinValue);
 

        public class Asn1TagChoice : Asn1Tag
        {
            public Asn1TagChoice(Asn1TagClass tagClass, int tagNumber) : base(tagClass, tagNumber)
            { 
            } 
            override public int getTaggedLength(int valueLength)
            {
                return valueLength;
            }

            override public void writeTagAndLength(ByteBuffer buf, bool constructed, int valueLength)
            {
                // Do nothing.
            }

            override public int getValue()
            {
                throw new UnsupportedOperationException("This is not a real tag.");
            }
        }


        /**
         * Returns true if the type has an extension marker.
         */
        protected abstract bool isExtensible();

              /**
               * Returns true if the value set is an extension value.
               */
              protected abstract bool hasExtensionValue();

              /**
               * Returns the ordinal of the chosen value (extension values re-start at 0),
               * or null if no value is set.
               */
               protected abstract int getSelectionOrdinal();

               protected abstract ChoiceComponent getSelectedComponent();

              /** Returns the chosen value. */
              public abstract Asn1Object getValue();

              /**
               * Returns the number of choices available for the current value of
               * {@code hasExtensionValue()}. If no value has been set, the number of
               * choices for a non-extension value is returned.
               */
              protected abstract int getOptionCount();

              /**
               * Creates a new instance of the type specified by the parameters, sets
               * the current value of this instance to it and returns the newly created
               * value.
               */
              protected abstract Asn1Object createAndSetValue(bool isExtensionValue,
                                                              int ordinal);

              /**
               * Given an Asn1Tag, creates and sets the value of this enumeration to a newly created object.
               * Used in BER decoding.
               *
               * @param tag the tag read from the input stream (less the "constructed" bit)
               * @return the newly created enumeration component
               * @throws IllegalArgumentException if the tag is not recognized. This currently includes
               * extension values.
               */
              protected abstract ChoiceComponent createAndSetValue(Asn1Tag tag);

              override public Asn1Tag getDefaultTag()
              {
                  return DUMMY_DEFAULT_TAG;
              }

              public bool isConstructed()
              {
                  return true;
              }


              override
        public int getBerValueLength()
              {
                  if (hasExtensionValue())
                  {
                      throw new UnsupportedOperationException("BER for extension values is unsupported");
                  }
                  ChoiceComponent select = getSelectedComponent();
                  if (select == null)
                  {
                      throw new NullPointerException("No component set");
                  }
                  if (select.getTag() != null)
                  {
                      int valueLen;
                      if (select.isImplicitTagging())
                      {
                          valueLen = getValue().getBerValueLength();
                      }
                      else
                      {
                          valueLen = getValue().getBerLength();
                      }
                      return select.getTag().getTaggedLength(valueLen);
                  }
                  return getValue().getBerLength();
              }

        override public void encodeBerValue(ByteBuffer buf)
        {
            if (hasExtensionValue())
            {
                throw new UnsupportedOperationException("BER for extension values is unsupported");
            }
            ChoiceComponent select = getSelectedComponent();
            if (select == null)
            {
                throw new NullPointerException("No component set");
            }
            Asn1Object value = getValue();
            if (select.getTag() != null)
            {
                if (select.isImplicitTagging())
                {
                    select.getTag().writeTagAndLength(buf, value.isConstructed(), value.getBerValueLength());
                    value.encodeBerValue(buf);
                }
                else
                {
                    select.getTag().writeTagAndLength(buf, true, value.getBerLength());
                    value.encodeBer(buf);
                }
            }
            else
            {
                value.encodeBer(buf);
            }
        }

        override public void decodeBerValue(ByteBuffer buf)
        {
            Asn1Tag tag = Asn1Tag.peekTag(buf);
            ChoiceComponent select = createAndSetValue(tag);
            if (select == null)
            {
                throw new IllegalArgumentException("Unknown selection tag: " + tag);
            }
            Asn1Object element = getValue();
            if (select.getTag() != null)
            {
                Asn1Tag.readTag(buf); // Read the tag off.
                int valueLen = Asn1Tag.readLength(buf);

                if (valueLen != buf.Remaining())
                {
                    throw new IllegalArgumentException("Length mismatch: expected=" + buf.Remaining()
                        + ", actual=" + valueLen);
                }

                if (select.isImplicitTagging())
                {
                    element.decodeBerValue(buf);
                    return;
                }
            }
            element.decodeBer(buf);
        }

        override public void decodeBer(ByteBuffer buf)
        {
            if (getTag() != null)
            {
                // This CHOICE is tagged
                Asn1Tag tag = Asn1Tag.readTag(buf);
                Asn1Tag.readLength(buf); // read len, but not used.
                checkTag(tag, getTag());
            }
            decodeBerValue(buf);
        }


        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            bool extensionValued = false;
            int selectionOrdinal = 0;
            if (isExtensible())
            {
                extensionValued = reader.readBit();
            }
            if (extensionValued)
            {
                if (aligned)
                {
                    selectionOrdinal = PerAlignedUtils.decodeNormallySmallWholeNumber(reader);
                }
                else
                {
                    selectionOrdinal = PerUnalignedUtils.decodeNormallySmallWholeNumber(reader);
                }
            }
            else if (getOptionCount() > 1)
            {
                if (aligned)
                {
                    selectionOrdinal = PerAlignedUtils.decodeSmallConstrainedWholeNumber(
                        reader, 0, getOptionCount() - 1);
                }
                else
                {
                    selectionOrdinal = PerUnalignedUtils.decodeConstrainedWholeNumber(
                        reader, 0, getOptionCount() - 1);
                }
            }
            if (extensionValued)
            {
                Asn1Object element = createAndSetValue(extensionValued, selectionOrdinal);
                if (aligned)
                {
                    PerAlignedUtils.decodeOpenTypeField(reader, element);
                }
                else
                {
                    PerUnalignedUtils.decodeOpenTypeField(reader, element);
                }
            }
            else if (getOptionCount() > 0)
            {
                Asn1Object element = createAndSetValue(extensionValued, selectionOrdinal);
                if (aligned)
                {
                    element.decodePerAligned(reader);
                }
                else
                {
                    element.decodePerUnaligned(reader);
                }
            }
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl(false);
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl(true);
        }
         

        private IEnumerable<BitStream> encodePerImpl(bool aligned)
        {
            ImmutableList<BitStream>.Builder listBuilder = ImmutableList.CreateBuilder<BitStream>(); 
            if (isExtensible())
            {
                BitStream extensionMarker = new BitStream();
                extensionMarker.appendBit(hasExtensionValue());
                listBuilder.Add(extensionMarker);
            }

            int optionCount = getOptionCount();
            int selectionOrdinal = getSelectionOrdinal();
            Preconditions.CheckState(optionCount == 0 || selectionOrdinal != null,
                                     "No value set.");
            if (hasExtensionValue())
            {
                if (aligned)
                {
                    using (var secuence = PerAlignedUtils.encodeNormallySmallWholeNumber(selectionOrdinal).GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            listBuilder.Add(secuence.Current);
                        }
                    }
                    //listBuilder.addAll(
                    //    PerAlignedUtils.encodeNormallySmallWholeNumber(selectionOrdinal));
                }
                else
                {
                    using (var secuence = PerAlignedUtils.encodeNormallySmallWholeNumber(selectionOrdinal).GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            listBuilder.Add(secuence.Current);
                        }
                    }
                    //listBuilder.addAll(  PerUnalignedUtils.encodeNormallySmallWholeNumber( selectionOrdinal));
                }
            }
            else if (optionCount > 1)
            {
                if (aligned)
                {
                    listBuilder.Add(
                        PerAlignedUtils.encodeSmallConstrainedWholeNumber(
                            selectionOrdinal, 0, optionCount - 1));
                }
                else
                {
                    listBuilder.Add(
                        PerUnalignedUtils.encodeConstrainedWholeNumber(
                            selectionOrdinal, 0, optionCount - 1));
                }
            }

            if (optionCount > 0)
            {
                Asn1Object value = getValue();
                if (hasExtensionValue())
                {
                    if (aligned)
                    {
                        using (var secuence = PerAlignedUtils.encodeOpenTypeField(value).GetEnumerator())
                        {
                            while (secuence.MoveNext())
                            {
                                // Do something with sequenceEnum.Current.
                                listBuilder.Add(secuence.Current);
                            }
                        }
                        //listBuilder.addAll(PerAlignedUtils.encodeOpenTypeField(value));
                    }
                    else
                    {
                        using (var secuence = PerAlignedUtils.encodeOpenTypeField(value).GetEnumerator())
                        {
                            while (secuence.MoveNext())
                            {
                                // Do something with sequenceEnum.Current.
                                listBuilder.Add(secuence.Current);
                            }
                        }
                        //listBuilder.addAll( PerUnalignedUtils.encodeOpenTypeField(value));
                    }
                }
                else
                {
                    if (aligned)
                    {
                        using (var secuence = value.encodePerAligned().GetEnumerator())
                        {
                            while (secuence.MoveNext())
                            {
                                // Do something with sequenceEnum.Current.
                                listBuilder.Add(secuence.Current);
                            }
                        }
                        //listBuilder.addAll(value.encodePerAligned());
                    }
                    else
                    {
                        using (var secuence = value.encodePerUnaligned().GetEnumerator())
                        {
                            while (secuence.MoveNext())
                            {
                                // Do something with sequenceEnum.Current.
                                listBuilder.Add(secuence.Current);
                            }
                        }
                        //listBuilder.addAll(value.encodePerUnaligned());
                    }
                }
            }
            return listBuilder.ToImmutable();
        }

    }
}