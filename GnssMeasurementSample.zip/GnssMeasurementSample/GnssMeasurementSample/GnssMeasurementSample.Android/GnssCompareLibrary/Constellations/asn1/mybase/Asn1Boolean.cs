﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class Asn1Boolean : Asn1Object
    {
        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.boolean);

        private bool value;

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        public bool getValue()
        {
            return value;
        }

        public void setValue(bool value)
        {
            this.value = value;
        }


        public override void decodeBerValue(ByteBuffer buf)
        {
            if (buf.Remaining() != 1)
            {
                throw new ArgumentException("Invalid remaining bytes: " + buf.Remaining());
            }
            value = (buf.Get() != 0);
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            buf.Put(value ? /*(sbyte)0xFF*/SByte.MaxValue : (sbyte)0x00);
        }

        public override int getBerValueLength()
        {
            return 1;
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            value = reader.readBit();
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            value = reader.readBit();
        }

        public override Asn1Tag getDefaultTag()
        {
            return Asn1Tag.boolean;
        }
        private IEnumerable<BitStream> encodePerImpl()
        {
            BitStream result = new BitStream();
            result.appendBit(value);
            var builder = ImmutableList.CreateBuilder<BitStream>();
            builder.Add(result);
            return builder.ToImmutable();
            //return ImmutableList.of(result);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl();
        }
    }
}