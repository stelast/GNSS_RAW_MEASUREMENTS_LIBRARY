﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
	public abstract class Asn1Object
	{
        /**
          * Returns the tags that can decode to this type. Subclasses are expected to "fauxverride".
          */
        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            throw new SystemException("No first tags defined");
        }

        /**
         * Returns the universal tag defined for the base type.
         */
        public abstract Asn1Tag getDefaultTag();

        /**
         * Returns the declared tag for this type. Tagged subclasses must override, the
         * default implementation returns null.
         */
        virtual public Asn1Tag getTag()
        {
            return null;
        }

        /**
         * Returns true if implicit tagging is to be applied to the type. Tagged subclasses must
         * override, the default implementation throws.
         */
        virtual public bool isTagImplicit()
        {
            throw new SystemException("Not a tagged subclass");
        }

        /**
         * Returns true if this object is "constructed", that is, it's composed of further TLVs
         * (as opposed to being primitive).
         */
        public bool isConstructed()
        {
            return false;
        }

        /**
         * Returns the number of octets in the BER encoding of this object. Called by
         * {@link #encodeBer()} to allocate a buffer of the correct size before starting
         * the encoding.
         */
        public int getBerLength()
        {
            int valueLen = getBerValueLength();
            Asn1Tag tag = getTag();
            if (tag == null)
            {
                tag = getDefaultTag();
            }
            else if (!isTagImplicit())
            {
                valueLen = getDefaultTag().getTaggedLength(valueLen);
            }
            return tag.getTaggedLength(valueLen);
        }

        /**
         * Returns the number of octets required to encoded the value of this {@link Asn1Object}.
         */
        public abstract int getBerValueLength();

        /**
         * Returns the BER encoding of this object.
         */
        public byte[] encodeBer()
        {
            ByteBuffer buf = ByteBuffer.Allocate(getBerLength());
            encodeBer(buf);
            byte[] arr = new byte[buf.Remaining()];
            buf.Get(arr);
            return arr;
        }

        public void encodeBer(ByteBuffer buf)
        {
            int valueLen = getBerValueLength();
            Asn1Tag tag = getTag();
            if (tag == null)
            {
                tag = getDefaultTag();
            }
            else
            {
                if (!isTagImplicit())
                {
                    int innerValueLen = getDefaultTag().getTaggedLength(valueLen);
                    tag.writeTagAndLength(buf, true, innerValueLen);
                    tag = getDefaultTag();
                }
            }
            tag.writeTagAndLength(buf, isConstructed(), valueLen);
            encodeBerValue(buf);
        }

        /**
         * Writes the BER encoded value of this {@link Asn1Object} into the specified buffer.
         *
         * @param buf the byte buffer to write to
         * @throws BufferOverflowException If there is insufficient space in the buffer
         * @throws ReadOnlyBufferException If the buffer is read-only
         */
        public abstract void encodeBerValue(ByteBuffer buf);

        /**
         * BER decodes the provided buffer. Should only be called on newly created instances as subclasses
         * may not write optional fields not explicitly present in the input.
         *
         * @param data the BER encoded input
         * @throws SystemException in case of parsing failure
         */
        virtual public void decodeBer(byte[] data)
        {
            decodeBer(ByteBuffer.Wrap(data));
        }

        virtual public void decodeBer(ByteBuffer buf)
        {
            Asn1Tag tag = Asn1Tag.readTag(buf);
            int valueLen = Asn1Tag.readLength(buf);

            if (valueLen != buf.Remaining())
            {
                throw new SystemException("Length mismatch: expected=" + buf.Remaining()
                    + ", actual=" + valueLen);
            }

            if (getTag() != null)
            {
                checkTag(tag, getTag());
                if (!isTagImplicit())
                {
                    // read inner tag and length
                    Asn1Tag innerTag = Asn1Tag.readTag(buf);
                    int innerValueLen = Asn1Tag.readLength(buf);
                    if (innerValueLen != buf.Remaining())
                    {
                        throw new SystemException("Length mismatch: expected=" + buf.Remaining()
                            + ", actual=" + innerValueLen);
                    }
                    checkTag(innerTag, getDefaultTag());
                }
            }

            decodeBerValue(buf);

            if (buf.HasRemaining)
            {
                throw new SystemException("BER encoded input not fully read");
            }
        }

        public void checkTag(Asn1Tag actual, Asn1Tag expected)
        {
            if (!expected.equals(actual))
            {
                throw new SystemException("Invalid tag: expected=" + expected
                    + ", actual=" + actual);
            }
        }

        /**
         * Decodes the BER encoded value of this {@link Asn1Object}. On return from this method the
         * provided buffer should be empty.
         */
        public abstract void decodeBerValue(ByteBuffer buf);

        /**
         * Returns remaining bytes in the {@link ByteBuffer} in a newly allocated byte array of exactly
         * the right size. The ByteBuffer will be empty upon return.
         */
        public static byte[] getRemaining(ByteBuffer buf)
        {
            byte[] bytes = new byte[buf.Remaining()];
            buf.Get(bytes);
            return bytes;
        }

        public abstract IEnumerable<BitStream> encodePerAligned();

        public abstract IEnumerable<BitStream> encodePerUnaligned();

        ///**
        // * This method should only be called on a newly created instance to avoid
        // * having residue state in it.
        // */
        public abstract void decodePerUnaligned(BitStreamReader reader);


        ///**
        // * This method should only be called on a newly created instance to avoid
        // * having residue state in it.
        // */
        public abstract void decodePerAligned(BitStreamReader reader);

        public String toIndentedString(String indent)
        {
            return indent + ToString();
        }
    }
}