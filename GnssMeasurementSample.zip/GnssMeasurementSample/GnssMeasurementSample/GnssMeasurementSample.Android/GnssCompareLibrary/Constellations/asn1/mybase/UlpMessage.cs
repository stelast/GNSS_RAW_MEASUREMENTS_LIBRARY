﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public class UlpMessage : Asn1Choice
    {
        private static readonly Asn1Tag TAG_UlpMessage = Asn1Tag.fromClassAndNumber(-1, -1);

        private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;

        public bool isMsSUPLRESPONSE()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.MsSUPLRESPONSE == selection.getTypeEnum();
        }
        public bool isMsSUPLEND()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.MsSUPLEND == selection.getTypeEnum();
        }
        public bool isMsSUPLPOSINIT()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.MsSUPLPOSINIT == selection.getTypeEnum();
        }
        public bool isMsSUPLPOS()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.MsSUPLPOS == selection.getTypeEnum();
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_UlpMessage != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_UlpMessage);
                return builder.ToImmutable();
            }
            else
            {
                return tagToSelection.Keys.ToImmutableList();
            }
        }
        /**
         * @throws {@code IllegalStateException} if {@code !isMsSUPLPOS}.
         */
        public SUPLPOS getMsSUPLPOS()
        {
            if (!isMsSUPLPOS())
            {
                throw new SystemException("UlpMessage value not a MsSUPLPOS");
            }
            return (SUPLPOS)element;
        }

        public void setMsSUPLPOSINIT(SUPLPOSINIT selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLPOSINIT); 
            //selection = Select.$MsSUPLPOSINIT;
            extension = false;
            element = selected;
        }

        public SUPLPOSINIT setMsSUPLPOSINITToNewInstance()
        {
            SUPLPOSINIT element = new SUPLPOSINIT();
            setMsSUPLPOSINIT(element);
            return element;
        }

        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Extend(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 8,9,10,11,12,13,14 };
            }

            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTART:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 8), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDRESPONSE:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 9), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTOP:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 10), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLNOTIFY:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 11), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLNOTIFYRESPONSE:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 12), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLSETINIT:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 13), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLREPORT:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 14), true, choose);
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                throw new NotImplementedException();
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return tipo;
            }

            public bool isImplicitTagging()
            {
                return this.isImplicitTaggin;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }

        public class Select : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Select(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 0,1,2,3,4,5,6,7 };
            }

            public static Select Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                { 
                    case ChoiceComponent.SelectEnum.MsSUPLINIT:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 0), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLSTART:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 1), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLRESPONSE:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 2), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLPOSINIT:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 3), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLPOS:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 4), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLEND:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 5), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHREQ:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 6), true, choose);
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHRESP:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 7), true, choose);
                    default:
                        return null;
                }
            }

            public int ordinal()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.MsSUPLINIT:
                        return 0;
                    case ChoiceComponent.SelectEnum.MsSUPLSTART:
                        return 1;
                    case ChoiceComponent.SelectEnum.MsSUPLRESPONSE:
                        return 2;
                    case ChoiceComponent.SelectEnum.MsSUPLPOSINIT:
                        return 3;
                    case ChoiceComponent.SelectEnum.MsSUPLPOS:
                        return 4;
                    case ChoiceComponent.SelectEnum.MsSUPLEND:
                        return 5;
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHREQ:
                        return 6;
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHRESP:
                        return 7;
                    default:
                        return 0;
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }
            virtual public List<Asn1Tag> getPossibleFirstTags()
            {
                return new List<Asn1Tag>();
            }

            virtual public String elementIndentedString(Asn1Object element, String indent)
            {
                return "Select " + " : " + element.toIndentedString(indent);
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.MsSUPLINIT:
                        return new SUPLINIT();
                    case ChoiceComponent.SelectEnum.MsSUPLSTART:
                        return new SUPLSTART();
                    case ChoiceComponent.SelectEnum.MsSUPLRESPONSE:
                        return new SUPLRESPONSE();
                    case ChoiceComponent.SelectEnum.MsSUPLPOSINIT:
                        return new SUPLPOSINIT();
                    case ChoiceComponent.SelectEnum.MsSUPLPOS:
                        return new SUPLPOS();
                    case ChoiceComponent.SelectEnum.MsSUPLEND:
                        return new SUPLEND();
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHREQ:
                        return new SUPLAUTHREQ();
                    case ChoiceComponent.SelectEnum.MsSUPLAUTHRESP:
                        return new SUPLAUTHRESP();
                    /*
                case ChoiceComponent.SelectEnum.Horvel:
                    return new Horvel();
                case ChoiceComponent.SelectEnum.Horandvervel:
                    return new Horandvervel();
                case ChoiceComponent.SelectEnum.Horveluncert:
                    return new Horveluncert();
                case ChoiceComponent.SelectEnum.Horandveruncert:
                    return new Horandveruncert(); */
                    default:
                        throw new SystemException("Select template error");
                }
            }

            ChoiceComponent.SelectEnum ChoiceComponent.getTypeEnum()
            {
                return tipo;
            }
        }  

        /**
         * @throws {@code IllegalStateException} if {@code !isMsSUPLPOSINIT}.
         */ 
        public SUPLPOSINIT getMsSUPLPOSINIT()
        {
            if (!isMsSUPLPOSINIT())
            {
                throw new Exception("UlpMessage value not a MsSUPLPOSINIT");
            }
            return (SUPLPOSINIT)element;
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        protected override bool isExtensible()
        {
            return true;
        }

        protected override bool hasExtensionValue()
        {
            return extension;
        }

        protected override int getSelectionOrdinal()
        {
            return selection.ordinal();
        }

        protected override ChoiceComponent getSelectedComponent()
        {
            return selection;
        }

        public override Asn1Object getValue()
        {
            return element;
        }

        protected override int getOptionCount()
        {
            if (hasExtensionValue())
            {
                return Extend.values().Count();
            }
            return Select.values().Count();
        }

        protected override Asn1Object createAndSetValue(bool isExtensionValue, int ordinal)
        {
            extension = isExtensionValue;
            if (isExtensionValue)
            { 
                //ordinal = ordinal + 8; 
                switch (ordinal)
                {
                    case 8:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTART);
                        break;
                    case 9:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDRESPONSE);
                        break;
                    case 10:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTOP);
                        break;
                    case 11:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLNOTIFY);
                        break;
                    case 12:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLNOTIFYRESPONSE);
                        break;
                    case 13:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLSETINIT);
                        break;
                    case 14:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLREPORT);
                        break;
                }
            }
            else
            {
                switch (ordinal)
                {
                    case 0:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLPOSINIT);
                        break;
                    case 1:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLSTART);
                        break;
                    case 2:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLRESPONSE);
                        break;
                    case 3:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLPOSINIT);
                        break;
                    case 4:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLPOS);
                        break;
                    case 5:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLEND);
                        break;
                    case 6:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLAUTHREQ);
                        break;
                    case 7:
                        selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLAUTHRESP);
                        break;
                }
            }
            element = selection.createElement();
            return element;
        }

        protected override ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            Select select = tagToSelection[tag];
            if (select == null)
            {
                throw new ArgumentException("Unknown selection tag: " + tag);
            }
            element = select.createElement();
            selection = select;
            extension = false;
            return select;
        }



        public bool isMsSUPLSTART()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.MsSUPLSTART == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$MsSUPLSTART == selection;
        }

        /**
         * @throws {@code IllegalStateException} if {@code !isMsSUPLSTART}.
         */
        public SUPLSTART getMsSUPLSTART()
        {
            if (!isMsSUPLSTART())
            {
                throw new Exception("UlpMessage value not a MsSUPLSTART");
            }
            return (SUPLSTART)element;
        }

        public void setMsSUPLSTART(SUPLSTART selected)
        {
            this.selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLSTART);
            //selection = Select.$MsSUPLSTART;
            this.extension = false;
            this.element = selected;
        }

        public SUPLSTART setMsSUPLSTARTToNewInstance()
        {
            SUPLSTART element = new SUPLSTART();
            setMsSUPLSTART(element);
            return element;
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }
    }
}