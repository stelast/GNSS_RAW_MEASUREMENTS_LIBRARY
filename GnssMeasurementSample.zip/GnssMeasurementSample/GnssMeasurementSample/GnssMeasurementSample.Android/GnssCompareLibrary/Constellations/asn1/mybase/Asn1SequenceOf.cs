﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public abstract class Asn1SequenceOf<T> : Asn1Object
        where T: Asn1Object
    {
        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.SEQUENCE); 

        protected LinkedList<T> sequence = new LinkedList<T>();
        private int minimumSize = 0;
        private Nullable<int> maximumSize = null; // Null is unbounded.

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        protected void setMinSize(int min)
        {
            minimumSize = min;
        }

        protected void setMaxSize(int max)
        {
            maximumSize = max;
        }

        public void add(T component)
        {
            sequence.AddLast(component);
        }
        

        public IEnumerable<T> getValues()
        {
            return sequence;
        }

        public abstract T createAndAddValue();

        Asn1Tag getDefaultTag()
        {
            return Asn1Tag.SEQUENCE;
        }

        bool isConstructed()
        {
            return true;
        }

        override public int getBerValueLength()
        {
            int length = 0;
            foreach (Asn1Object component in sequence)
            {
                length += component.getBerLength();
            }
            return length;
        }

        override public void encodeBerValue(ByteBuffer buf)
        {
            foreach (Asn1Object component in sequence)
            {
                component.encodeBer(buf);
            }
        }

        override public void decodeBerValue(ByteBuffer buf)
        {
            while (buf.HasRemaining)
            {
                Asn1Tag tag = Asn1Tag.readTag(buf);
                int valueLength = Asn1Tag.readLength(buf);
                T value = createAndAddValue();
                if (value.getTag() != null)
                {
                    checkTag(tag, value.getTag());
                    if (!value.isTagImplicit())
                    {
                        // read inner tag + length
                        checkTag(value.getDefaultTag(), Asn1Tag.readTag(buf));
                        valueLength = Asn1Tag.readLength(buf);
                    }
                }
                else
                {
                    checkTag(tag, value.getDefaultTag());
                }
                byte[] arr = new byte[buf.Remaining()];
                buf.Get(arr);
                ByteBuffer subBuf = ByteBuffer.Wrap(arr, buf.Position(), valueLength);
                value.decodeBerValue(subBuf);
                if (subBuf.HasRemaining)
                {
                    throw new ArgumentException("child failed to consume all input");
                }
                buf.Position(buf.Position() + valueLength);
            }
        }
        
        private IEnumerable<BitStream> encodePerImpl(bool aligned)
        {
            Preconditions.CheckState(sequence.Count() >= minimumSize,
                                     "Too few components.");
            Preconditions.CheckState(maximumSize == null
                                     || sequence.Count() <= maximumSize,
                                     "Too many components.");
            ImmutableList<BitStream>.Builder listBuilder = ImmutableList.CreateBuilder<BitStream>(); 
            if (maximumSize == null || maximumSize >= PerAlignedUtils.SIXTYFOUR_K)
            {
                if (aligned)
                {
                    listBuilder.Add(PerAlignedUtils.encodeSemiConstrainedLength(sequence.Count()));
                }
                else
                {
                    listBuilder.Add(PerUnalignedUtils.encodeSemiConstrainedLength(sequence.Count()));
                }
            }
            else if (maximumSize != minimumSize)
            {
                if (aligned)
                {
                    listBuilder.Add(
                        PerAlignedUtils.encodeSmallConstrainedWholeNumber(
                            sequence.Count(), minimumSize, maximumSize.Value));
                }
                else
                {
                    listBuilder.Add(
                        PerUnalignedUtils.encodeConstrainedWholeNumber(
                            sequence.Count(), minimumSize, maximumSize.Value));
                }
            }
            foreach (Asn1Object component in sequence)
            {
                if (aligned)
                {
                    using (var secuence = component.encodePerAligned().GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            listBuilder.Add(secuence.Current);
                        }
                    }
                    //listBuilder.addAll(component.encodePerAligned());
                }
                else
                {
                    using (var secuence = component.encodePerUnaligned().GetEnumerator())
                    {
                        while (secuence.MoveNext())
                        {
                            // Do something with sequenceEnum.Current.
                            listBuilder.Add(secuence.Current);
                        }
                    }
                    //listBuilder.addAll(component.encodePerUnaligned());
                }
            }
            return listBuilder.ToImmutable();
        }

        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return encodePerImpl(false);
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return encodePerImpl(true);
        }
        

        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            int size = minimumSize;
            if (maximumSize == null || maximumSize >= PerAlignedUtils.SIXTYFOUR_K)
            {
                if (aligned)
                {
                    size = PerAlignedUtils.decodeSemiConstrainedLength(reader);
                }
                else
                {
                    size = PerUnalignedUtils.decodeSemiConstrainedLength(reader);
                }
            }
            else if (maximumSize != minimumSize)
            {
                if (aligned)
                {
                    size = PerAlignedUtils.decodeSmallConstrainedWholeNumber(
                        reader, minimumSize, maximumSize.Value);
                }
                else
                {
                    size = PerUnalignedUtils.decodeConstrainedWholeNumber(
                        reader, minimumSize, maximumSize.Value);
                }
            }
            for (int i = 0; i < size; i++)
            {
                T value = createAndAddValue();
                if (aligned)
                {
                    value.decodePerAligned(reader);
                }
                else
                {
                    value.decodePerUnaligned(reader);
                }
            }
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

    }
}