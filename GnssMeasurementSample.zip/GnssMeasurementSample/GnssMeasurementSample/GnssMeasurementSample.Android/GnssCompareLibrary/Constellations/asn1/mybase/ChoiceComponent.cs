﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase
{
    public interface ChoiceComponent
    {
        int ordinal();

        Asn1Object createElement();

        Asn1Tag getTag();

        bool isImplicitTagging();

        public enum SelectEnum
        {
            MsSUPLINIT,  // 0
            MsSUPLSTART,    // 1
            MsSUPLRESPONSE,
            MsSUPLPOSINIT,
            MsSUPLPOS,
            MsSUPLEND,
            MsSUPLAUTHREQ,
            MsSUPLAUTHRESP, // 7

            MsSUPLTRIGGEREDSTART,  //8
            MsSUPLTRIGGEREDRESPONSE,
            MsSUPLTRIGGEREDSTOP,
            MsSUPLNOTIFY,
            MsSUPLNOTIFYRESPONSE,
            MsSUPLSETINIT,
            MsSUPLREPORT,  //14

            GsmCell,    //15
            WcdmaCell,
            CdmaCell,

            Ver2_CellInfo_extension,    //18

            HrpdCell,   //19
            UmbCell,
            LteCell,
            WlanAP,
            WimaxBS,

            undefined,  //24

            Horvel, //25
            Horandvervel,
            Horveluncert,
            Horandveruncert,

            Ipv4Address,  //29
            Ipv6Address,
            IPAddress,

        }
        public SelectEnum getTypeEnum();
    }
}