﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;
using static GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase.UlpMessage;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Velocity : Asn1Choice
    {
        private static readonly Asn1Tag TAG_Velocity = Asn1Tag.fromClassAndNumber(-1, -1);

        private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;

        //        static {
        //    for (Select select : Select.values()) {
        //      for (Asn1Tag tag : select.getPossibleFirstTags()) {
        //        Select select0;
        //        if ((select0 = tagToSelection.put(tag, select)) != null) {
        //          throw new Exception(
        //            "Velocity: " + tag + " maps to both " + select0 + " and " + select);
        //    }
        //}
        //    }
        //  }

        public Velocity() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_Velocity;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Velocity != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_Velocity);
                return builder.ToImmutable();
            }
            else
            {
                return tagToSelection.Keys.ToImmutableList();
            }
        } 

        /**
         * Creates a new Velocity from encoded stream.
         */
        public static Velocity fromPerUnaligned(byte[] encodedBytes)
        {
            Velocity result = new Velocity();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Velocity from encoded stream.
         */
        public static Velocity fromPerAligned(byte[] encodedBytes)
        {
            Velocity result = new Velocity();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }
          

        override protected ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            Select select = tagToSelection[tag];
            if (select == null)
            {
                throw new ArgumentException("Unknown selection tag: " + tag);
            }
            element = select.createElement();
            selection = select;
            extension = false;
            return select;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        ///**
        // * @throws {@code IllegalStateException} if {@code !isMsSUPLPOS}.
        // */
        //public SUPLPOS getMsSUPLPOS()
        //{
        //    if (!isMsSUPLPOS())
        //    {
        //        throw new SystemException("UlpMessage value not a MsSUPLPOS");
        //    }
        //    return (SUPLPOS)element;
        //}

        public void setMsSUPLPOSINIT(SUPLPOSINIT selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.MsSUPLPOSINIT);//$MsSUPLPOSINIT;
            //selection = Select.$MsSUPLPOSINIT;
            extension = false;
            element = selected;
        }

        public SUPLPOSINIT setMsSUPLPOSINITToNewInstance()
        {
            SUPLPOSINIT element = new SUPLPOSINIT();
            setMsSUPLPOSINIT(element);
            return element;
        }

        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag2;
            readonly bool isImplicitTaggin;
             

            public Extend(Asn1Tag tag, bool isImplicitTaggin)
            {
                this.tag2 = tag;
                this.isImplicitTaggin = isImplicitTaggin;
            }

            public static List<int> values()
            {
                return new List<int>() {  };
            }

            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                { 
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                throw new NotImplementedException();
            }

            public Asn1Tag getTag()
            {
                return tag2;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return ChoiceComponent.SelectEnum.undefined;
            }

            public bool isImplicitTagging()
            {
                return this.isImplicitTaggin;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }

        public bool isHorvel()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Horvel == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Horvel == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isHorvel}.
         */ 
        public Horvel getHorvel()
        {
            if (!isHorvel())
            {
                throw new Exception("Velocity value not a Horvel");
            }
            return (Horvel)element;
        }

        public void setHorvel(Horvel selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Horvel); 
            //selection = Select.$Horvel;
            extension = false;
            element = selected;
        }

        public Horvel setHorvelToNewInstance()
        {
            Horvel element = new Horvel();
            setHorvel(element);
            return element;
        }



        public bool isHorandvervel()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Horandvervel == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Horandvervel == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isHorandvervel}.
         */ 
        public Horandvervel getHorandvervel()
        {
            if (!isHorandvervel())
            {
                throw new Exception("Velocity value not a Horandvervel");
            }
            return (Horandvervel)element;
        }

        public void setHorandvervel(Horandvervel selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Horandvervel);
            //selection = Select.$Horandvervel;
            extension = false;
            element = selected;
        }

        public Horandvervel setHorandvervelToNewInstance()
        {
            Horandvervel element = new Horandvervel();
            setHorandvervel(element);
            return element;
        }
         

        public bool isHorveluncert()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Horveluncert == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Horveluncert == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isHorveluncert}.
         */ 
        public Horveluncert getHorveluncert()
        {
            if (!isHorveluncert())
            {
                throw new Exception("Velocity value not a Horveluncert");
            }
            return (Horveluncert)element;
        }

        public void setHorveluncert(Horveluncert selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Horveluncert);
            //selection = Select.$Horveluncert;
            extension = false;
            element = selected;
        }

        public Horveluncert setHorveluncertToNewInstance()
        {
            Horveluncert element = new Horveluncert();
            setHorveluncert(element);
            return element;
        } 

        public bool isHorandveruncert()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Horandveruncert == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Horandveruncert == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isHorandveruncert}.
         */ 
        public Horandveruncert getHorandveruncert()
        {
            if (!isHorandveruncert())
            {
                throw new Exception("Velocity value not a Horandveruncert");
            }
            return (Horandveruncert)element;
        }

        public void setHorandveruncert(Horandveruncert selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Horandveruncert);
            //selection = Select.$Horandveruncert;
            extension = false;
            element = selected;
        }

        public Horandveruncert setHorandveruncertToNewInstance()
        {
            Horandveruncert element = new Horandveruncert();
            setHorandveruncert(element);
            return element;
        }
         


        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}
         

        public String toString()
        {
            return toIndentedString("");
        } 

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        protected override bool hasExtensionValue()
        {
            return extension;
        }

        protected override int getSelectionOrdinal()
        {
            return selection.ordinal();
        }

        protected override ChoiceComponent getSelectedComponent()
        {
            return selection;
        }

        public override Asn1Object getValue()
        {
            return element;
        }

        protected override int getOptionCount()
        {
            if (hasExtensionValue())
            {
                return Extend.values().Count();
            }
            return Select.values().Count();
        }

        protected override Asn1Object createAndSetValue(bool isExtensionValue, int ordinal)
        {
            extension = isExtensionValue;
            if (isExtensionValue)
            {
                //ordinal = ordinal + 8; 
                switch (ordinal)
                { 
                    default:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.undefined);
                        break;
                }
            }
            else
            {
                switch (ordinal)
                {
                    case 25:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Horvel);
                        break;
                    case 26:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Horandvervel);
                        break;
                    case 27:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Horveluncert);
                        break;
                    case 28:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Horandveruncert);
                        break;  
                }
            }
            element = selection.createElement();
            return element;

            //extension = isExtensionValue;
            //if (isExtensionValue)
            //{
            //    selection = Extend.values()[ordinal];
            //}
            //else
            //{
            //    selection = Select.values()[ordinal];
            //}
            //element = selection.createElement();
            //return element;
        }
    }
}