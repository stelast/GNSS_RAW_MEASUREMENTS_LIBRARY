﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;
using Java.Math;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class NavigationModel : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_NavigationModel
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public NavigationModel() : base()
        { 
        }

        override public Asn1Tag getTag()
        {
            return TAG_NavigationModel;
        }

        override public bool  isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_NavigationModel != null)
            {
                //return ImmutableList.of(TAG_NavigationModel);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new NavigationModel from encoded stream.
         */
        public static NavigationModel fromPerUnaligned(byte[] encodedBytes)
        {
            NavigationModel result = new NavigationModel();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new NavigationModel from encoded stream.
         */
        public static NavigationModel fromPerAligned(byte[] encodedBytes)
        {
            NavigationModel result = new NavigationModel();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private NavigationModel.gpsWeekType gpsWeek_;
        public NavigationModel.gpsWeekType getGpsWeek()
        {
            return gpsWeek_;
        }
        /**
         * @throws ClassCastException if value is not a NavigationModel.gpsWeekType
         */
        public void setGpsWeek(Asn1Object value)
        {
            this.gpsWeek_ = (NavigationModel.gpsWeekType)value;
        }
        public NavigationModel.gpsWeekType setGpsWeekToNewInstance()
        {
            gpsWeek_ = new NavigationModel.gpsWeekType();
            return gpsWeek_;
        }

        private NavigationModel.gpsToeType gpsToe_;
        public NavigationModel.gpsToeType getGpsToe()
        {
            return gpsToe_;
        }
        /**
         * @throws ClassCastException if value is not a NavigationModel.gpsToeType
         */
        public void setGpsToe(Asn1Object value)
        {
            this.gpsToe_ = (NavigationModel.gpsToeType)value;
        }
        public NavigationModel.gpsToeType setGpsToeToNewInstance()
        {
            gpsToe_ = new NavigationModel.gpsToeType();
            return gpsToe_;
        }

        private NavigationModel.nSATType nSAT_;
        public NavigationModel.nSATType getNSAT()
        {
            return nSAT_;
        }
        /**
         * @throws ClassCastException if value is not a NavigationModel.nSATType
         */
        public void setNSAT(Asn1Object value)
        {
            this.nSAT_ = (NavigationModel.nSATType)value;
        }
        public NavigationModel.nSATType setNSATToNewInstance()
        {
            nSAT_ = new NavigationModel.nSATType();
            return nSAT_;
        }

        private NavigationModel.toeLimitType toeLimit_;
        public NavigationModel.toeLimitType getToeLimit()
        {
            return toeLimit_;
        }
        /**
         * @throws ClassCastException if value is not a NavigationModel.toeLimitType
         */
        public void setToeLimit(Asn1Object value)
        {
            this.toeLimit_ = (NavigationModel.toeLimitType)value;
        }
        public NavigationModel.toeLimitType setToeLimitToNewInstance()
        {
            toeLimit_ = new NavigationModel.toeLimitType();
            return toeLimit_;
        }

        private SatelliteInfo satInfo_;
        public SatelliteInfo getSatInfo()
        {
            return satInfo_;
        }
        /**
         * @throws ClassCastException if value is not a SatelliteInfo
         */
        public void setSatInfo(Asn1Object value)
        {
            this.satInfo_ = (SatelliteInfo)value;
        }
        public SatelliteInfo setSatInfoToNewInstance()
        {
            satInfo_ = new SatelliteInfo();
            return satInfo_;
        }

        /**
         * 
         */
        public class gpsWeekType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_gpsWeekType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public gpsWeekType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("1023"));

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_gpsWeekType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_gpsWeekType != null)
                {
                    //return ImmutableList.of(TAG_gpsWeekType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new gpsWeekType from encoded stream.
             */
            public static gpsWeekType fromPerUnaligned(byte[] encodedBytes)
            {
                gpsWeekType result = new gpsWeekType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new gpsWeekType from encoded stream.
             */
            public static gpsWeekType fromPerAligned(byte[] encodedBytes)
            {
                gpsWeekType result = new gpsWeekType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "gpsWeekType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class gpsToeType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_gpsToeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public gpsToeType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("167"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_gpsToeType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_gpsToeType != null)
                {
                    //return ImmutableList.of(TAG_gpsToeType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new gpsToeType from encoded stream.
             */
            public static gpsToeType fromPerUnaligned(byte[] encodedBytes)
            {
                gpsToeType result = new gpsToeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new gpsToeType from encoded stream.
             */
            public static gpsToeType fromPerAligned(byte[] encodedBytes)
            {
                gpsToeType result = new gpsToeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "gpsToeType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class nSATType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_nSATType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public nSATType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("31"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_nSATType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_nSATType != null)
                {
                    //return ImmutableList.of(TAG_nSATType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new nSATType from encoded stream.
             */
            public static nSATType fromPerUnaligned(byte[] encodedBytes)
            {
                nSATType result = new nSATType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new nSATType from encoded stream.
             */
            public static nSATType fromPerAligned(byte[] encodedBytes)
            {
                nSATType result = new nSATType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "nSATType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class toeLimitType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_toeLimitType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public toeLimitType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("10"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_toeLimitType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_toeLimitType != null)
                {
                    //return ImmutableList.of(TAG_toeLimitType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new toeLimitType from encoded stream.
             */
            public static toeLimitType fromPerUnaligned(byte[] encodedBytes)
            {
                toeLimitType result = new toeLimitType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new toeLimitType from encoded stream.
             */
            public static toeLimitType fromPerAligned(byte[] encodedBytes)
            {
                toeLimitType result = new toeLimitType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "toeLimitType = " + getInteger() + ";\n";
            }
        }







        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}