﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PrefMethod : Asn1Enumerated
    { 

        public class Value : Asn1Enumerated.Value
        {
            public enum ValueEnum
            {
                agpsSETassistedPreferred,
                agpsSETBasedPreferred,
                noPreference
            }
            public static List<int> values()
            {
                return new List<int>() { 0, 1, 2 };
            }
            public Value(ValueEnum rf)
            {
                switch (rf)
                {
                    case ValueEnum.agpsSETassistedPreferred:
                        value = 0;
                        break;
                    case ValueEnum.agpsSETBasedPreferred:
                        value = 1;
                        break;
                    case ValueEnum.noPreference:
                        value = 2;
                        break;
                }
            }
            public Value(int i)
            {
                value = i;
            }

            private int value;
            virtual public int getAssignedValue()
            {
                return value;
            }

            virtual public bool isExtensionValue()
            {
                return false;
            }

            public int ordinal()
            {
                return value;
            }
        }


        protected Value getDefaultValue()
        {
            return null;
        }
        public Value enumValue()
        {
            return (Value)getValue();
        }

        //public void setTo_agpsSETassistedPreferred()
        //{
        //    setValue(Value.agpsSETassistedPreferred);
        //}

        //public void setTo_agpsSETBasedPreferred()
        //{
        //    setValue(Value.agpsSETBasedPreferred);
        //}

        //public void setTo_noPreference()
        //{
        //    setValue(Value.noPreference);
        //}

        /**
         * Creates a new PrefMethod from encoded stream.
         */
        public static PrefMethod fromPerUnaligned(byte[] encodedBytes)
        {
            PrefMethod result = new PrefMethod();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public class ExtensionValue : Asn1Enumerated.Value
        {

            public ExtensionValue(int i)
            {
                value = i;
            }

            private int value;
            public int getAssignedValue()
            {
                return value;
            }

            public static List<int> values()
            {
                return new List<int>() { };
            }
            public bool isExtensionValue()
            {
                return true;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }

        /**
         * Creates a new PrefMethod from encoded stream.
         */
        public static PrefMethod fromPerAligned(byte[] encodedBytes)
        {
            PrefMethod result = new PrefMethod();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        protected override int getValueCount()
        {
            return Value.values().Count();
        }

        protected override bool isExtensible()
        {
            return false;
        }

        protected override Asn1Enumerated.Value lookupExtensionValue(int ordinal)
        {
            return new ExtensionValue(Value.values()[ordinal]);
        }

        protected override Asn1Enumerated.Value lookupValue(int ordinal)
        {
            return new Value(Value.values()[ordinal]);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }
    }
}