﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SUPLPOS : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_SUPLPOS = Asn1Tag.fromClassAndNumber(-1, -1);

        public SUPLPOS() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_SUPLPOS;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SUPLPOS != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_SUPLPOS);
                return builder.ToImmutable();
            }
            else
            {
                return Asn1Integer.getPossibleFirstTags();
            }
        } 

        /**
         * Creates a new SUPLPOS from encoded stream.
         */
        public static SUPLPOS fromPerUnaligned(byte[] encodedBytes)
        {
            SUPLPOS result = new SUPLPOS();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SUPLPOS from encoded stream.
         */
        public static SUPLPOS fromPerAligned(byte[] encodedBytes)
        {
            SUPLPOS result = new SUPLPOS();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>(); 
            builder.Add(new M3(this));
            return builder.ToImmutable();
        }

        protected override bool isExtensible()
        {
            return true;
        }

        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            SUPLPOS objeto;
            public M1(SUPLPOS objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getPosPayLoad();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosPayLoad.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getPosPayLoad() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setPosPayLoadToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getPosPayLoad().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            SUPLPOS objeto;
            public M2(SUPLPOS objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getVelocity();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_SUPLPOS != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_SUPLPOS);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getVelocity() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setVelocityToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getVelocity().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        { 
            SUPLPOS objeto;
            public M3(SUPLPOS objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getExtensionVer2_SUPL_POS_extension();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                throw new UnsupportedOperationException(
                    "BER decoding not supported for extension elements");
            }

            public Asn1Tag getTag()
            {
                throw new UnsupportedOperationException(
                    "BER is not supported for extension elements");
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getExtensionVer2_SUPL_POS_extension() != null;
            }

            public bool isImplicitTagging()
            {
                throw new UnsupportedOperationException(
                    "BER is not supported for extension elements");
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setExtensionVer2_SUPL_POS_extensionToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "ver2_SUPL_POS_extension : "
                    + this.objeto.getExtensionVer2_SUPL_POS_extension().toIndentedString(indent);
            }
        }


        private PosPayLoad posPayLoad_;
        public PosPayLoad getPosPayLoad()
        {
            return posPayLoad_;
        }
        /**
         * @throws ClassCastException if value is not a PosPayLoad
         */
        public void setPosPayLoad(Asn1Object value)
        {
            this.posPayLoad_ = (PosPayLoad)value;
        }
        public PosPayLoad setPosPayLoadToNewInstance()
        {
            posPayLoad_ = new PosPayLoad();
            return posPayLoad_;
        }

        private Velocity velocity_;
        public Velocity getVelocity()
        {
            return velocity_;
        }
        /**
         * @throws ClassCastException if value is not a Velocity
         */
        public void setVelocity(Asn1Object value)
        {
            this.velocity_ = (Velocity)value;
        }
        public Velocity setVelocityToNewInstance()
        {
            velocity_ = new Velocity();
            return velocity_;
        }
         

        private Ver2_SUPL_POS_extension extensionVer2_SUPL_POS_extension;
        public Ver2_SUPL_POS_extension getExtensionVer2_SUPL_POS_extension()
        {
            return extensionVer2_SUPL_POS_extension;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_SUPL_POS_extension
         */
        public void setExtensionVer2_SUPL_POS_extension(Asn1Object value)
        {
            extensionVer2_SUPL_POS_extension = (Ver2_SUPL_POS_extension)value;
        }
        public void setExtensionVer2_SUPL_POS_extensionToNewInstance()
        {
            extensionVer2_SUPL_POS_extension = new Ver2_SUPL_POS_extension();
        }

        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public string toString()
        {
            return toIndentedString("");
        }


    }
}