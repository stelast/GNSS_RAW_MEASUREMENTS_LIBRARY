﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class CellInfo : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_CellInfo = Asn1Tag.fromClassAndNumber(-1, -1);

        //private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;

        //        static {
        //    for (Select select : Select.values()) {
        //      for (Asn1Tag tag : select.getPossibleFirstTags()) {
        //        Select select0;
        //        if ((select0 = tagToSelection.put(tag, select)) != null) {
        //          throw new Exception(
        //            "CellInfo: " + tag + " maps to both " + select0 + " and " + select);
        //    }
        //}
        //    }
        //  }

        public CellInfo() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_CellInfo;
        }

        override public bool isTagImplicit()
        {
            return true;
        }
         

        /**
         * Creates a new CellInfo from encoded stream.
         */
        public static CellInfo fromPerUnaligned(byte[] encodedBytes)
        {
            CellInfo result = new CellInfo();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new CellInfo from encoded stream.
         */
        public static CellInfo fromPerAligned(byte[] encodedBytes)
        {
            CellInfo result = new CellInfo();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        protected bool hasExtensionValue()
        {
            return extension;
        }

        protected int getSelectionOrdinal()
        {
            return selection.ordinal();
        }


        protected ChoiceComponent getSelectedComponent()
        {
            return selection;
        }
         
        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        public bool isExtensionVer2_CellInfo_extension()
        {
            return hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Ver2_CellInfo_extension == selection.getTypeEnum();
            //return hasExtensionValue() && Extend.$Ver2_CellInfo_extension == selection;
        }

        /**
         * @throws {@code IllegalStateException} if {@code !isVer2_CellInfo_extension}.
         */
        public Ver2_CellInfo_extension getExtensionVer2_CellInfo_extension()
        {
            if (!isExtensionVer2_CellInfo_extension())
            {
                throw new IllegalStateException("CellInfo value not a Ver2_CellInfo_extension");
            }
            return (Ver2_CellInfo_extension)element;
        }
 
        public void setExtensionVer2_CellInfo_extensionToNewInstance()
        {
            Ver2_CellInfo_extension element = new Ver2_CellInfo_extension();
            setExtensionVer2_CellInfo_extension(element);
        }

        public void setExtensionVer2_CellInfo_extension(Ver2_CellInfo_extension selected)
        {
            selection = Extend.Create(ChoiceComponent.SelectEnum.Ver2_CellInfo_extension);
            //selection = Extend.$Ver2_CellInfo_extension;
            extension = true;
            element = selected;
        }




        //private static enum Extend : ChoiceComponent
        //{

        //    $Ver2_CellInfo_:(Asn1Tag.fromClassAndNumber(2, 3),
        //    true) {
        //    override
        //    public Asn1Object createElement()
        //    {
        //        return new Ver2_CellInfo_:();
        //    }

        //    override 
        //    String elementIndentedString(Asn1Object element, String indent)
        //        {
        //            return toString() + " : " + ((Ver2_CellInfo_:)element).toIndentedString(indent);
        //        }
        //    },


        //    ;
        //     private readonly Asn1Tag tag;
        //    private readonly bool isImplicitTagging;

        //    Extend(Asn1Tag tag, bool isImplicitTagging)
        //    {
        //        this.tag = tag;
        //        this.isImplicitTagging = isImplicitTagging;
        //    }

        //    public Asn1Object createElement()
        //    {
        //        throw new Exception("Extend template error");
        //    }

        //    override

        //        public Asn1Tag getTag()
        //    {
        //        return tag;
        //    }

        //    override
        //        public bool isImplicitTagging()
        //    {
        //        return isImplicitTagging;
        //    }

        //    String elementIndentedString(Asn1Object element, String indent)
        //    {
        //        throw new Exception("Extend template error");
        //    }
        //}





        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        //public String toString()
        //{
        //    return toIndentedString("");
        //}

        protected override bool isExtensible()
        {
            throw new NotImplementedException();
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        public class Select : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Select(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }
            public static Select Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.GsmCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 15), true, choose);
                    case ChoiceComponent.SelectEnum.WcdmaCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 16), true, choose);
                    case ChoiceComponent.SelectEnum.CdmaCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 17), true, choose);
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.GsmCell:
                        return new GsmCellInformation();
                    case ChoiceComponent.SelectEnum.WcdmaCell:
                        return new WcdmaCellInformation();
                    case ChoiceComponent.SelectEnum.CdmaCell:
                        return new CdmaCellInformation();
                    default:
                        throw new SystemException("Select template error");
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return tipo;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }

        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Extend(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }
            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.Ver2_CellInfo_extension:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 15), true, choose);
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.Ver2_CellInfo_extension:
                        return new Ver2_CellInfo_extension();
                    default:
                        throw new SystemException("Select template error");
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return tipo;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }
    }
}