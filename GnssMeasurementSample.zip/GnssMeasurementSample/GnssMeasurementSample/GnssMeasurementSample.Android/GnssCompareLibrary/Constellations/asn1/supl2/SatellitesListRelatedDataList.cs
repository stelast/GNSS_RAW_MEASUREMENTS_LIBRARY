﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SatellitesListRelatedDataList : Asn1SequenceOf<SatellitesListRelatedData>
    {
        private static readonly Asn1Tag TAG_SatellitesListRelatedDataList = Asn1Tag.fromClassAndNumber(-1, -1);

        public SatellitesListRelatedDataList() : base()
        {
            setMinSize(0);
            setMaxSize(32);

        }
        override public Asn1Tag getTag()
        {
            return TAG_SatellitesListRelatedDataList;
        }
         
        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SatellitesListRelatedDataList != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_SatellitesListRelatedDataList);
                return builder.ToImmutable();
            }
            else
            {
                return Asn1Integer.getPossibleFirstTags();
            }
        }

        public override SatellitesListRelatedData createAndAddValue()
        {
            SatellitesListRelatedData value = new SatellitesListRelatedData();
            add(value);
            return value;
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            throw new NotImplementedException();
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            throw new NotImplementedException();
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}