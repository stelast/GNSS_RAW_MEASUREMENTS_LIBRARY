﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Java.Math;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SetSessionID : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_SetSessionID = Asn1Tag.fromClassAndNumber(-1, -1);

        public SetSessionID() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_SetSessionID;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SetSessionID != null)
            {
                //return ImmutableList.of(TAG_SetSessionID);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new SetSessionID from encoded stream.
         */
        public static SetSessionID fromPerUnaligned(byte[] encodedBytes)
        {
            SetSessionID result = new SetSessionID();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SetSessionID from encoded stream.
         */
        public static SetSessionID fromPerAligned(byte[] encodedBytes)
        {
            SetSessionID result = new SetSessionID();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            return false;
        }

        protected override bool isExtensible()
        {
            return false;
        }

        private SetSessionID.sessionIdType sessionId_;
        public SetSessionID.sessionIdType getSessionId()
        {
            return sessionId_;
        }
        /**
         * @throws ClassCastException if value is not a SetSessionID.sessionIdType
         */
        public void setSessionId(Asn1Object value)
        {
            this.sessionId_ = (SetSessionID.sessionIdType)value;
        }
        public SetSessionID.sessionIdType setSessionIdToNewInstance()
        {
            sessionId_ = new SetSessionID.sessionIdType();
            return sessionId_;
        }

        private SETId setId_;
        public SETId getSetId()
        {
            return setId_;
        }
        /**
         * @throws ClassCastException if value is not a SETId
         */
        public void setSetId(Asn1Object value)
        {
            this.setId_ = (SETId)value;
        }
        public SETId setSetIdToNewInstance()
        {
            setId_ = new SETId();
            return setId_;
        }

        /**
         * 
         */
        public class sessionIdType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_sessionIdType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public sessionIdType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("65535"));

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_sessionIdType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_sessionIdType != null)
                {
                    //return ImmutableList.of(TAG_sessionIdType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new sessionIdType from encoded stream.
             */
            public static sessionIdType fromPerUnaligned(byte[] encodedBytes)
            {
                sessionIdType result = new sessionIdType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new sessionIdType from encoded stream.
             */
            public static sessionIdType fromPerAligned(byte[] encodedBytes)
            {
                sessionIdType result = new sessionIdType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "sessionIdType = " + getInteger() + ";\n";
            }
        }

         

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            SetSessionID objeto;
            public M1(SetSessionID objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSessionId();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SetSessionID.sessionIdType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSessionId() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setSessionIdToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "sessionId : " + this.objeto.getSessionId().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            SetSessionID objeto;
            public M2(SetSessionID objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSetId();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SETId.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSetId() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setSetIdToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "setId : " + this.objeto.getSetId().toIndentedString(indent);
            }
        }
    }
}