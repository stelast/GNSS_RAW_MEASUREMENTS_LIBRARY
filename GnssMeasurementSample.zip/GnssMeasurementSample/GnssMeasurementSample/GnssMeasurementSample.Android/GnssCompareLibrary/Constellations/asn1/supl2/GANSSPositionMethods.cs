﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class GANSSPositionMethods : Asn1SequenceOf<GANSSPositionMethod>
    {

        //private static readonly TAG_GANSSPositionMethods = Asn1Tag.fromClassAndNumber(-1, -1);

        public GANSSPositionMethods() : base()
        {
            setMinSize(1);
            setMaxSize(16);

        }

        //override public Asn1Tag getTag()
        //{
        //    return TAG_GANSSPositionMethods;
        //}

        override
        public bool isTagImplicit()
        {
            return true;
        }

        //public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        //{
        //    if (TAG_GANSSPositionMethods != null)
        //    {
        //        //return ImmutableList.of(TAG_GANSSPositionMethods);
        //        return Asn1SequenceOf.getPossibleFirstTags();
        //    }
        //    else
        //    {
        //        return Asn1SequenceOf.getPossibleFirstTags();
        //    }
        //}

        /**
         * Creates a new GANSSPositionMethods from encoded stream.
         */
        public static GANSSPositionMethods fromPerUnaligned(byte[] encodedBytes)
        {
            GANSSPositionMethods result = new GANSSPositionMethods();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new GANSSPositionMethods from encoded stream.
         */
        public static GANSSPositionMethods fromPerAligned(byte[] encodedBytes)
        {
            GANSSPositionMethods result = new GANSSPositionMethods();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        override public GANSSPositionMethod createAndAddValue()
        {
            GANSSPositionMethod value = new GANSSPositionMethod();
            add(value);
            return value;
        }



        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("GANSSPositionMethods = [\n");
            String internalIndent = indent + "  ";
            //for (GANSSPositionMethod value : getValues())
            //{
            //    builder.Append(internalIndent)
            //        .Append(value.toIndentedString(internalIndent));
            //}
            builder.Append(indent).Append("];\n");
            return builder.ToString();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}