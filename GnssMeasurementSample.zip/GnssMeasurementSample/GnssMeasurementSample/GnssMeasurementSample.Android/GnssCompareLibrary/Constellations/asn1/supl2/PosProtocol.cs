﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PosProtocol : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_PosProtocol
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public PosProtocol() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_PosProtocol;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_PosProtocol != null)
            {
                //return ImmutableList.of(TAG_PosProtocol);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new PosProtocol from encoded stream.
         */
        public static PosProtocol fromPerUnaligned(byte[] encodedBytes)
        {
            PosProtocol result = new PosProtocol();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new PosProtocol from encoded stream.
         */
        public static PosProtocol fromPerAligned(byte[] encodedBytes)
        {
            PosProtocol result = new PosProtocol();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private PosProtocol.tia801Type tia801_;
        public PosProtocol.tia801Type getTia801()
        {
            return tia801_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocol.tia801Type
         */
        public void setTia801(Asn1Object value)
        {
            this.tia801_ = (PosProtocol.tia801Type)value;
        }
        public PosProtocol.tia801Type setTia801ToNewInstance()
        {
            tia801_ = new PosProtocol.tia801Type();
            return tia801_;
        }

        private PosProtocol.rrlpType rrlp_;
        public PosProtocol.rrlpType getRrlp()
        {
            return rrlp_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocol.rrlpType
         */
        public void setRrlp(Asn1Object value)
        {
            this.rrlp_ = (PosProtocol.rrlpType)value;
        }
        public PosProtocol.rrlpType setRrlpToNewInstance()
        {
            rrlp_ = new PosProtocol.rrlpType();
            return rrlp_;
        }

        private PosProtocol.rrcType rrc_;
        public PosProtocol.rrcType getRrc()
        {
            return rrc_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocol.rrcType
         */
        public void setRrc(Asn1Object value)
        {
            this.rrc_ = (PosProtocol.rrcType)value;
        }
        public PosProtocol.rrcType setRrcToNewInstance()
        {
            rrc_ = new PosProtocol.rrcType();
            return rrc_;
        }



        private Ver2_PosProtocol_extension extensionVer2_PosProtocol_extension;
        public Ver2_PosProtocol_extension getExtensionVer2_PosProtocol_extension()
        {
            return extensionVer2_PosProtocol_extension;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_PosProtocol_extension
         */
        public void setExtensionVer2_PosProtocol_extension(Asn1Object value)
        {
            extensionVer2_PosProtocol_extension = (Ver2_PosProtocol_extension)value;
        }
        public void setExtensionVer2_PosProtocol_extensionToNewInstance()
        {
            extensionVer2_PosProtocol_extension = new Ver2_PosProtocol_extension();
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>(); 
            return builder.ToImmutable();
        }


        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            PosProtocol objeto;
            public M1(PosProtocol objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getTia801();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosProtocol.tia801Type.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getTia801() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setTia801ToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "tia801 : " + this.objeto.getTia801().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            PosProtocol objeto;
            public M2(PosProtocol objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getRrlp();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosProtocol.rrlpType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getRrlp() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setRrlpToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "rrlp : " + this.objeto.getRrlp().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            PosProtocol objeto;
            public M3(PosProtocol objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getRrc();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosProtocol.rrcType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getRrc() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setRrcToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "rrc : " + this.objeto.getRrc().toIndentedString(indent);
            }
        } 

        /**
         * 
         */
        public class tia801Type : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_tia801Type
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public tia801Type() : base()
            {
            }

            override

      public Asn1Tag getTag()
            {
                return TAG_tia801Type;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_tia801Type != null)
                {
                    //return ImmutableList.of(TAG_tia801Type);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new tia801Type from encoded stream.
             */
            public static tia801Type fromPerUnaligned(byte[] encodedBytes)
            {
                tia801Type result = new tia801Type();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new tia801Type from encoded stream.
             */
            public static tia801Type fromPerAligned(byte[] encodedBytes)
            {
                tia801Type result = new tia801Type();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "tia801Type = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class rrlpType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_rrlpType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public rrlpType() : base()
            {
            }

            override

          public Asn1Tag getTag()
            {
                return TAG_rrlpType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_rrlpType != null)
                {
                    //return ImmutableList.of(TAG_rrlpType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new rrlpType from encoded stream.
             */
            public static rrlpType fromPerUnaligned(byte[] encodedBytes)
            {
                rrlpType result = new rrlpType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new rrlpType from encoded stream.
             */
            public static rrlpType fromPerAligned(byte[] encodedBytes)
            {
                rrlpType result = new rrlpType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "rrlpType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class rrcType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_rrcType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public rrcType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_rrcType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_rrcType != null)
                {
                    //return ImmutableList.of(TAG_rrcType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new rrcType from encoded stream.
             */
            public static rrcType fromPerUnaligned(byte[] encodedBytes)
            {
                rrcType result = new rrcType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new rrcType from encoded stream.
             */
            public static rrcType fromPerAligned(byte[] encodedBytes)
            {
                rrcType result = new rrcType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "rrcType = " + getValue() + ";\n";
            }
        }













    }
}