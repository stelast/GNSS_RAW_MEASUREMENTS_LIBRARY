﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Java.Math;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class WlanAPInformation : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_WlanAPInformation = Asn1Tag.fromClassAndNumber(-1, -1);

        public WlanAPInformation() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_WlanAPInformation;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_WlanAPInformation != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_WlanAPInformation);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new WlanAPInformation from encoded stream.
         */
        public static WlanAPInformation fromPerUnaligned(byte[] encodedBytes)
        {
            WlanAPInformation result = new WlanAPInformation();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new WlanAPInformation from encoded stream.
         */
        public static WlanAPInformation fromPerAligned(byte[] encodedBytes)
        {
            WlanAPInformation result = new WlanAPInformation();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private WlanAPInformation.apMACAddressType apMACAddress_;
        public WlanAPInformation.apMACAddressType getApMACAddress()
        {
            return apMACAddress_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apMACAddressType
         */
        public void setApMACAddress(Asn1Object value)
        {
            this.apMACAddress_ = (WlanAPInformation.apMACAddressType)value;
        }
        public WlanAPInformation.apMACAddressType setApMACAddressToNewInstance()
        {
            apMACAddress_ = new WlanAPInformation.apMACAddressType();
            return apMACAddress_;
        }

        private WlanAPInformation.apTransmitPowerType apTransmitPower_;
        public WlanAPInformation.apTransmitPowerType getApTransmitPower()
        {
            return apTransmitPower_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apTransmitPowerType
         */
        public void setApTransmitPower(Asn1Object value)
        {
            this.apTransmitPower_ = (WlanAPInformation.apTransmitPowerType)value;
        }
        public WlanAPInformation.apTransmitPowerType setApTransmitPowerToNewInstance()
        {
            apTransmitPower_ = new WlanAPInformation.apTransmitPowerType();
            return apTransmitPower_;
        }

        private WlanAPInformation.apAntennaGainType apAntennaGain_;
        public WlanAPInformation.apAntennaGainType getApAntennaGain()
        {
            return apAntennaGain_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apAntennaGainType
         */
        public void setApAntennaGain(Asn1Object value)
        {
            this.apAntennaGain_ = (WlanAPInformation.apAntennaGainType)value;
        }
        public WlanAPInformation.apAntennaGainType setApAntennaGainToNewInstance()
        {
            apAntennaGain_ = new WlanAPInformation.apAntennaGainType();
            return apAntennaGain_;
        }

        private WlanAPInformation.apSignaltoNoiseType apSignaltoNoise_;
        public WlanAPInformation.apSignaltoNoiseType getApSignaltoNoise()
        {
            return apSignaltoNoise_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apSignaltoNoiseType
         */
        public void setApSignaltoNoise(Asn1Object value)
        {
            this.apSignaltoNoise_ = (WlanAPInformation.apSignaltoNoiseType)value;
        }
        public WlanAPInformation.apSignaltoNoiseType setApSignaltoNoiseToNewInstance()
        {
            apSignaltoNoise_ = new WlanAPInformation.apSignaltoNoiseType();
            return apSignaltoNoise_;
        }

        private WlanAPInformation.apDeviceTypeType apDeviceType_;
        public WlanAPInformation.apDeviceTypeType getApDeviceType()
        {
            return apDeviceType_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apDeviceTypeType
         */
        public void setApDeviceType(Asn1Object value)
        {
            this.apDeviceType_ = (WlanAPInformation.apDeviceTypeType)value;
        }
        public WlanAPInformation.apDeviceTypeType setApDeviceTypeToNewInstance()
        {
            apDeviceType_ = new WlanAPInformation.apDeviceTypeType();
            return apDeviceType_;
        }

        private WlanAPInformation.apSignalStrengthType apSignalStrength_;
        public WlanAPInformation.apSignalStrengthType getApSignalStrength()
        {
            return apSignalStrength_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apSignalStrengthType
         */
        public void setApSignalStrength(Asn1Object value)
        {
            this.apSignalStrength_ = (WlanAPInformation.apSignalStrengthType)value;
        }
        public WlanAPInformation.apSignalStrengthType setApSignalStrengthToNewInstance()
        {
            apSignalStrength_ = new WlanAPInformation.apSignalStrengthType();
            return apSignalStrength_;
        }

        private WlanAPInformation.apChannelFrequencyType apChannelFrequency_;
        public WlanAPInformation.apChannelFrequencyType getApChannelFrequency()
        {
            return apChannelFrequency_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.apChannelFrequencyType
         */
        public void setApChannelFrequency(Asn1Object value)
        {
            this.apChannelFrequency_ = (WlanAPInformation.apChannelFrequencyType)value;
        }
        public WlanAPInformation.apChannelFrequencyType setApChannelFrequencyToNewInstance()
        {
            apChannelFrequency_ = new WlanAPInformation.apChannelFrequencyType();
            return apChannelFrequency_;
        }

        //private RTD apRoundTripDelay_;
        //public RTD getApRoundTripDelay()
        //{
        //    return apRoundTripDelay_;
        //}
        ///**
        // * @throws ClassCastException if value is not a RTD
        // */
        //public void setApRoundTripDelay(Asn1Object value)
        //{
        //    this.apRoundTripDelay_ = (RTD)value;
        //}
        //public RTD setApRoundTripDelayToNewInstance()
        //{
        //    apRoundTripDelay_ = new RTD();
        //    return apRoundTripDelay_;
        //}

        private WlanAPInformation.setTransmitPowerType setTransmitPower_;
        public WlanAPInformation.setTransmitPowerType getSetTransmitPower()
        {
            return setTransmitPower_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.setTransmitPowerType
         */
        public void setSetTransmitPower(Asn1Object value)
        {
            this.setTransmitPower_ = (WlanAPInformation.setTransmitPowerType)value;
        }
        public WlanAPInformation.setTransmitPowerType setSetTransmitPowerToNewInstance()
        {
            setTransmitPower_ = new WlanAPInformation.setTransmitPowerType();
            return setTransmitPower_;
        }

        private WlanAPInformation.setAntennaGainType setAntennaGain_;
        public WlanAPInformation.setAntennaGainType getSetAntennaGain()
        {
            return setAntennaGain_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.setAntennaGainType
         */
        public void setSetAntennaGain(Asn1Object value)
        {
            this.setAntennaGain_ = (WlanAPInformation.setAntennaGainType)value;
        }
        public WlanAPInformation.setAntennaGainType setSetAntennaGainToNewInstance()
        {
            setAntennaGain_ = new WlanAPInformation.setAntennaGainType();
            return setAntennaGain_;
        }

        private WlanAPInformation.setSignaltoNoiseType setSignaltoNoise_;
        public WlanAPInformation.setSignaltoNoiseType getSetSignaltoNoise()
        {
            return setSignaltoNoise_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.setSignaltoNoiseType
         */
        public void setSetSignaltoNoise(Asn1Object value)
        {
            this.setSignaltoNoise_ = (WlanAPInformation.setSignaltoNoiseType)value;
        }
        public WlanAPInformation.setSignaltoNoiseType setSetSignaltoNoiseToNewInstance()
        {
            setSignaltoNoise_ = new WlanAPInformation.setSignaltoNoiseType();
            return setSignaltoNoise_;
        }

        private WlanAPInformation.setSignalStrengthType setSignalStrength_;
        public WlanAPInformation.setSignalStrengthType getSetSignalStrength()
        {
            return setSignalStrength_;
        }
        /**
         * @throws ClassCastException if value is not a WlanAPInformation.setSignalStrengthType
         */
        public void setSetSignalStrength(Asn1Object value)
        {
            this.setSignalStrength_ = (WlanAPInformation.setSignalStrengthType)value;
        }
        public WlanAPInformation.setSignalStrengthType setSetSignalStrengthToNewInstance()
        {
            setSignalStrength_ = new WlanAPInformation.setSignalStrengthType();
            return setSignalStrength_;
        }

        //private ReportedLocation apReportedLocation_;
        //public ReportedLocation getApReportedLocation()
        //{
        //    return apReportedLocation_;
        //}
        ///**
        // * @throws ClassCastException if value is not a ReportedLocation
        // */
        //public void setApReportedLocation(Asn1Object value)
        //{
        //    this.apReportedLocation_ = (ReportedLocation)value;
        //}
        //public ReportedLocation setApReportedLocationToNewInstance()
        //{
        //    apReportedLocation_ = new ReportedLocation();
        //    return apReportedLocation_;
        //}


        /**
         * 
         */
        public class apMACAddressType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_apMACAddressType = Asn1Tag.fromClassAndNumber(-1, -1);

            public apMACAddressType() : base()
            {
                setMinSize(48);
                setMaxSize(48);

            }

            override
            
  public Asn1Tag getTag()
            {
                return TAG_apMACAddressType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apMACAddressType != null)
                {
                    //return ImmutableList.of(TAG_apMACAddressType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apMACAddressType from encoded stream.
             */
            public static apMACAddressType fromPerUnaligned(byte[] encodedBytes)
            {
                apMACAddressType result = new apMACAddressType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apMACAddressType from encoded stream.
             */
            public static apMACAddressType fromPerAligned(byte[] encodedBytes)
            {
                apMACAddressType result = new apMACAddressType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apMACAddressType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apTransmitPowerType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_apTransmitPowerType
      = Asn1Tag.fromClassAndNumber(-1, -1);

            public apTransmitPowerType() : base()
            { 
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override
            
      public Asn1Tag getTag()
            {
                return TAG_apTransmitPowerType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apTransmitPowerType != null)
                {
                    //return ImmutableList.of(TAG_apTransmitPowerType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apTransmitPowerType from encoded stream.
             */
            public static apTransmitPowerType fromPerUnaligned(byte[] encodedBytes)
            {
                apTransmitPowerType result = new apTransmitPowerType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apTransmitPowerType from encoded stream.
             */
            public static apTransmitPowerType fromPerAligned(byte[] encodedBytes)
            {
                apTransmitPowerType result = new apTransmitPowerType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apTransmitPowerType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apAntennaGainType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_apAntennaGainType
      = Asn1Tag.fromClassAndNumber(-1, -1);

            public apAntennaGainType() : base()
            { 
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override
            
          public Asn1Tag getTag()
            {
                return TAG_apAntennaGainType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apAntennaGainType != null)
                {
                    //return ImmutableList.of(TAG_apAntennaGainType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apAntennaGainType from encoded stream.
             */
            public static apAntennaGainType fromPerUnaligned(byte[] encodedBytes)
            {
                apAntennaGainType result = new apAntennaGainType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apAntennaGainType from encoded stream.
             */
            public static apAntennaGainType fromPerAligned(byte[] encodedBytes)
            {
                apAntennaGainType result = new apAntennaGainType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apAntennaGainType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apSignaltoNoiseType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_apSignaltoNoiseType
      = Asn1Tag.fromClassAndNumber(-1, -1);

            public apSignaltoNoiseType() : base()
            { 
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override
            
          public Asn1Tag getTag()
            {
                return TAG_apSignaltoNoiseType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apSignaltoNoiseType != null)
                {
                    //return ImmutableList.of(TAG_apSignaltoNoiseType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apSignaltoNoiseType from encoded stream.
             */
            public static apSignaltoNoiseType fromPerUnaligned(byte[] encodedBytes)
            {
                apSignaltoNoiseType result = new apSignaltoNoiseType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apSignaltoNoiseType from encoded stream.
             */
            public static apSignaltoNoiseType fromPerAligned(byte[] encodedBytes)
            {
                apSignaltoNoiseType result = new apSignaltoNoiseType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apSignaltoNoiseType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apDeviceTypeType : Asn1Enumerated
        {
            public class Value : Asn1Enumerated.Value
            {
                public enum ValueEnum {
                    wlan802_11a,
                    wlan802_11b,
                    wlan802_11g,
                }
                ValueEnum type;
                public Value (ValueEnum val)
                {
                    type = val;
                }
                public static List<int> values()
                {
                    return new List<int>() { 0,1,2 };
                }

                public static Value create(ValueEnum val)
                {
                    switch (val)
                    {
                        case ValueEnum.wlan802_11a:
                            return new Value(ValueEnum.wlan802_11a);
                        case ValueEnum.wlan802_11b:
                            return new Value(ValueEnum.wlan802_11b);
                        case ValueEnum.wlan802_11g:
                            return new Value(ValueEnum.wlan802_11g);
                        default:
                            throw new NotImplementedException();
                    }
                }

                Value(int i)
                {
                    value = i;
                }

                private int value;
                public int getAssignedValue()
                {
                    return value;
                }

                public bool isExtensionValue()
                {
                    return false;
                }

                public int ordinal()
                {
                    throw new NotImplementedException();
                }
            }
             

            public Value enumValue()
            {
                return (Value)getValue();
            }



            public void setTo_wlan802_11a()
            {
                setValue(Value.create(Value.ValueEnum.wlan802_11a));
            }

            public void setTo_wlan802_11b()
            {
                setValue(Value.create(Value.ValueEnum.wlan802_11b)); 
            }

            public void setTo_wlan802_11g()
            {
                setValue(Value.create(Value.ValueEnum.wlan802_11g)); 
            }



            public class ExtensionValue : Asn1Enumerated.Value
            { 

                ExtensionValue(int i) {
                    value = i;
                }
                public static List<int> values()
                {
                    return new List<int>() { };
                }

                private int value; 
                public int getAssignedValue()
                {
                    return value;
                }

                public bool isExtensionValue()
                {
                    return true;
                }

                public int ordinal()
                {
                    throw new NotImplementedException();
                }
            }

            public ExtensionValue extEnumValue()
            {
                return (ExtensionValue)getValue();
            }
             

            private static readonly Asn1Tag TAG_apDeviceTypeType = Asn1Tag.fromClassAndNumber(-1, -1);

            public apDeviceTypeType() : base()
            {
                // use template substitution instead of calling getDefaultValue(), since
                // calling virtual methods from a ctor is frowned upon here.
                setValue(null);
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_apDeviceTypeType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apDeviceTypeType != null)
                {
                    //return ImmutableList.of(TAG_apDeviceTypeType);
                    return Asn1Enumerated.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Enumerated.getPossibleFirstTags();
                }
            }

            override protected bool isExtensible()
            {
                return true;
            }

            override protected Asn1Enumerated.Value lookupValue(int ordinal)
            {
                switch (ordinal)
                {
                    case 0:
                        return Value.create(Value.ValueEnum.wlan802_11a);
                    case 1:
                        return Value.create(Value.ValueEnum.wlan802_11b);
                    case 2:
                        return Value.create(Value.ValueEnum.wlan802_11g);
                    default:
                        return null;
                }
            }

            override protected Asn1Enumerated.Value lookupExtensionValue(int ordinal)
            {
                return null;
            }

            override protected int getValueCount()
            {
                return Value.values().Count();
            }

            /**
             * Creates a new apDeviceTypeType from encoded stream.
             */
            public static apDeviceTypeType fromPerUnaligned(byte[] encodedBytes)
            {
                apDeviceTypeType result = new apDeviceTypeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apDeviceTypeType from encoded stream.
             */
            public static apDeviceTypeType fromPerAligned(byte[] encodedBytes)
            {
                apDeviceTypeType result = new apDeviceTypeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apDeviceTypeType = " + getValue() + ";\n";
            }

            public override IEnumerable<BitStream> encodePerAligned()
            {
                throw new NotImplementedException();
            }

            public override IEnumerable<BitStream> encodePerUnaligned()
            {
                throw new NotImplementedException();
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apSignalStrengthType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_apSignalStrengthType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public apSignalStrengthType() : base()
            { 
                setValueRange(new BigInteger("-127"), new BigInteger("128")); 
            }

            override

          public Asn1Tag getTag()
            {
                return TAG_apSignalStrengthType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apSignalStrengthType != null)
                {
                    //return ImmutableList.of(TAG_apSignalStrengthType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apSignalStrengthType from encoded stream.
             */
            public static apSignalStrengthType fromPerUnaligned(byte[] encodedBytes)
            {
                apSignalStrengthType result = new apSignalStrengthType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apSignalStrengthType from encoded stream.
             */
            public static apSignalStrengthType fromPerAligned(byte[] encodedBytes)
            {
                apSignalStrengthType result = new apSignalStrengthType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apSignalStrengthType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class apChannelFrequencyType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_apChannelFrequencyType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public apChannelFrequencyType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("256"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_apChannelFrequencyType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_apChannelFrequencyType != null)
                {
                    //return ImmutableList.of(TAG_apChannelFrequencyType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new apChannelFrequencyType from encoded stream.
             */
            public static apChannelFrequencyType fromPerUnaligned(byte[] encodedBytes)
            {
                apChannelFrequencyType result = new apChannelFrequencyType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new apChannelFrequencyType from encoded stream.
             */
            public static apChannelFrequencyType fromPerAligned(byte[] encodedBytes)
            {
                apChannelFrequencyType result = new apChannelFrequencyType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "apChannelFrequencyType = " + getInteger() + ";\n";
            }
        }




        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class setTransmitPowerType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_setTransmitPowerType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public setTransmitPowerType() : base()
            {
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_setTransmitPowerType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_setTransmitPowerType != null)
                {
                    //return ImmutableList.of(TAG_setTransmitPowerType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new setTransmitPowerType from encoded stream.
             */
            public static setTransmitPowerType fromPerUnaligned(byte[] encodedBytes)
            {
                setTransmitPowerType result = new setTransmitPowerType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new setTransmitPowerType from encoded stream.
             */
            public static setTransmitPowerType fromPerAligned(byte[] encodedBytes)
            {
                setTransmitPowerType result = new setTransmitPowerType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "setTransmitPowerType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class setAntennaGainType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_setAntennaGainType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public setAntennaGainType() : base()
            {
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_setAntennaGainType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_setAntennaGainType != null)
                {
                    //return ImmutableList.of(TAG_setAntennaGainType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new setAntennaGainType from encoded stream.
             */
            public static setAntennaGainType fromPerUnaligned(byte[] encodedBytes)
            {
                setAntennaGainType result = new setAntennaGainType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new setAntennaGainType from encoded stream.
             */
            public static setAntennaGainType fromPerAligned(byte[] encodedBytes)
            {
                setAntennaGainType result = new setAntennaGainType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "setAntennaGainType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class setSignaltoNoiseType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_setSignaltoNoiseType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public setSignaltoNoiseType() : base()
            {
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_setSignaltoNoiseType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_setSignaltoNoiseType != null)
                {
                    //return ImmutableList.of(TAG_setSignaltoNoiseType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new setSignaltoNoiseType from encoded stream.
             */
            public static setSignaltoNoiseType fromPerUnaligned(byte[] encodedBytes)
            {
                setSignaltoNoiseType result = new setSignaltoNoiseType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new setSignaltoNoiseType from encoded stream.
             */
            public static setSignaltoNoiseType fromPerAligned(byte[] encodedBytes)
            {
                setSignaltoNoiseType result = new setSignaltoNoiseType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "setSignaltoNoiseType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class setSignalStrengthType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_setSignalStrengthType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public setSignalStrengthType() : base()
            {
                setValueRange(new BigInteger("-127"), new BigInteger("128"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_setSignalStrengthType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_setSignalStrengthType != null)
                {
                    //return ImmutableList.of(TAG_setSignalStrengthType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new setSignalStrengthType from encoded stream.
             */
            public static setSignalStrengthType fromPerUnaligned(byte[] encodedBytes)
            {
                setSignalStrengthType result = new setSignalStrengthType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new setSignalStrengthType from encoded stream.
             */
            public static setSignalStrengthType fromPerAligned(byte[] encodedBytes)
            {
                setSignalStrengthType result = new setSignalStrengthType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "setSignalStrengthType = " + getInteger() + ";\n";
            }
        }







        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}