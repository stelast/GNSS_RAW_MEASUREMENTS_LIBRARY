﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Java.Nio;
using System.Collections.Immutable;
using Java.Time.Format;
using Java.Lang; 

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Asn1UTCTime : Asn1Object
    {

        private static readonly ImmutableList<Asn1Tag> possibleFirstTags = ImmutableList.Create<Asn1Tag>(Asn1Tag.UTC_TIME);
        //private static readonly List<Asn1Tag> possibleFirstTags = ImmutableList.of(Asn1Tag.UTC_TIME);

        //// duplicate previous behavior of all 0 fields for ctor().
        //private MutableDateTime value = new MutableDateTime(0, 1, 1, 0, 0, 0, 0, DateTimeZone.Utc);
        DateTime value = new DateTime(0,1,1,0,0,0,0, DateTimeKind.Utc);

        //private static readonly DateTimeFormatter humanFormatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");

        //private static readonly DateTimeFormatter ia5Formatter = DateTimeFormat.forPattern("yyMMddHHmmss'Z'");

        public Asn1UTCTime()
        {
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            return possibleFirstTags;
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void decodePerAligned(BitStreamReader reader)
        {
            throw new NotImplementedException();
        }

        public override void decodePerUnaligned(BitStreamReader reader)
        {
            throw new NotImplementedException();
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public void assignTo(Asn1UTCTime other)
        {
            value = other.value;
        }

        public int getYear()
        {
            return value.Year;
        }

        public void setYear(int newYear)
        {
            value.AddYears(newYear - value.Year); //.setYear(newYear);
        }

        public int getMonth()
        {
            return value.Month;
        }

        public void setMonth(int newMonth)
        {
            value.AddMonths(newMonth - value.Month);
            //value.setMonthOfYear(newMonth);
        }

        public int getDay()
        {
            return value.Day;
        }

        public void setDay(int newDay)
        {
            value.AddDays(newDay - value.Day);
            //value.setDayOfMonth(newDay);
        }

        public int getHour()
        {
            return value.Hour;
        }

        public void setHour(int newHour)
        {
            value.AddDays(newHour - value.Hour);
            //value.setHourOfDay(newHour);
        }

        public int getMinute()
        {
            return value.Minute;
        }

        public void setMinute(int newMinute)
        {
            value.AddDays(newMinute - value.Minute);
            //value.setMinuteOfHour(newMinute);
        }

        public int getSecond()
        {
            return value.Second;
        }

        public void setSecond(int newSecond)
        {
            value.AddDays(newSecond - value.Second);
            //value.setSecondOfMinute(newSecond);
        }

        //private Asn1IA5String encodeToIA5string()
        //{
        //    string textRepresentation = ia5Formatter.print(value);
        //    Asn1IA5String result = new Asn1IA5String();
        //    result.setMaxSize(255);
        //    result.setValue(textRepresentation);
        //    return result;
        //}

        //public string toHumanReadablestring()
        //{
        //    return humanFormatter.print(value);
        //}

        //override Asn1Tag getDefaultTag()
        //{
        //    return Asn1Tag.UTC_TIME;
        //}

        //override int getBerValueLength()
        //{
        //    return encodeToIA5string().getBerValueLength();
        //}

        //override void encodeBerValue(ByteBuffer buf)
        //{
        //    encodeToIA5string().encodeBerValue(buf);
        //}

        //override public void decodeBerValue(ByteBuffer buf)
        //{
        //    Asn1IA5String result = new Asn1IA5String();
        //    result.setMaxSize(255);
        //    result.decodeBerValue(buf);
        //    retrieveResult(result);
        //}

        //      override
        //public Iterable<BitStream> encodePerAligned()
        //      {
        //          Asn1IA5String result = encodeToIA5string();
        //          return result.encodePerAligned();
        //      }

        //      override
        //public Iterable<BitStream> encodePerUnaligned()
        //      {
        //          Asn1IA5String result = encodeToIA5string();
        //          return result.encodePerUnaligned();
        //      }

        /**
         * Gets the value as a {@link DateTime} in UTC.
         *
         * @return the datetime
         */
        //      public DateTime getValue()
        //      {
        //          return value.toDateTime();
        //      }

        //      /**
        //       * Sets the value from a {@link DateTime}.
        //       *
        //       * @param dateTime the datetime
        //       */
        //      public void setValue(DateTime dateTime)
        //      {
        //          value = new MutableDateTime(dateTime);
        //          value.setZone(DateTimeZone.UTC);
        //      }

        //      private static readonly int LENGTH_OF_SIGN = "+".length();
        //      private static readonly int LENGTH_OF_2_DIGIT = "00".length();
        //      private static readonly int LENGTH_OF_ZONE_HOUR_OFFSET = LENGTH_OF_SIGN + LENGTH_OF_2_DIGIT;
        //      private static readonly int LENGTH_OF_ZONE_OFFSET = LENGTH_OF_ZONE_HOUR_OFFSET + LENGTH_OF_2_DIGIT;
        //      private static readonly Splitter SPLITTER_2_DIGIT = Splitter.fixedLength(LENGTH_OF_2_DIGIT);

        //      public class TimeTextAndZone
        //      {
        //          public string timestring;
        //          public DateTimeZone zone;
        //      }

        //      private static TimeTextAndZone extractZone(string rawTimestring)
        //      {
        //          int timeLength = rawTimestring.length();
        //          TimeTextAndZone timeTextAndZone = new TimeTextAndZone();
        //          timeTextAndZone.zone = DateTimeZone.UTC;
        //          // If the raw time string has trailing 'Z', remove it.
        //          if (rawTimestring[timeLength - 1] == 'Z')
        //          {
        //              --timeLength;
        //          }
        //          else
        //          {
        //              int signIndicator;
        //              switch (rawTimestring[timeLength - LENGTH_OF_ZONE_OFFSET])
        //              {
        //                  case '+':
        //                      signIndicator = 1;
        //                      break;
        //                  case '-':
        //                      signIndicator = -1;
        //                      break;
        //                  default:
        //                      signIndicator = 0;
        //                      break;
        //              }
        //              if (signIndicator != 0)
        //              {
        //                  timeLength -= LENGTH_OF_ZONE_OFFSET;
        //                  int hourOffset = Integer.ParseInt(rawTimestring.substring(
        //                      timeLength + LENGTH_OF_SIGN, timeLength + LENGTH_OF_ZONE_HOUR_OFFSET));
        //                  int minuteOffset = Integer.ParseInt(rawTimestring.substring(
        //                      timeLength + LENGTH_OF_ZONE_HOUR_OFFSET, timeLength + LENGTH_OF_ZONE_OFFSET));
        //                  if (signIndicator < 0)
        //                  {
        //                      hourOffset = -hourOffset;
        //                      minuteOffset = -minuteOffset;
        //                  }
        //                  if (hourOffset != 0 || minuteOffset != 0)
        //                  {
        //                      timeTextAndZone.zone = DateTimeZone.forOffsetHoursMinutes(hourOffset, minuteOffset);
        //                  }
        //              }
        //          }
        //          timeTextAndZone.timestring = rawTimestring.substring(0, timeLength);
        //          return timeTextAndZone;
        //      }

        //      /**
        //       * Parses a text representation of a time into the new value of this instance.
        //       *
        //       * <p>The format definition of UTCTime:
        //       *
        //       * <p>http://www.obj-sys.com/asn1tutorial/node15.html
        //       * http://www.obj-sys.com/asn1tutorial/node14.html
        //       *
        //       * <p>We currently support "[YY]YYMMDDHHMM[SS][Z]" or "[YY]YYMMDDHHMM[SS][+|-]HHMM"
        //       *
        //       * @param Asn1IA5String the text representation
        //       * @throws ArgumentException if Asn1IA5String contains a malformed representation or the
        //       *     date part values are out of range
        //       * @throws NumberFormatException if parts of Asn1IA5String that should parse to numbers can't
        //       */
        //      private void retrieveResult(Asn1IA5String Asn1IA5String)
        //      {
        //          TimeTextAndZone timeTextAndZone = extractZone(Asn1IA5String.getValue());
        //          int yearLength;
        //          int timeLength = timeTextAndZone.timestring.Count();
        //          bool hasSecond = true;
        //          switch (timeLength)
        //          {
        //              case 10: // 2 digit year, no seconds
        //                  hasSecond = false;
        //                  break;
        //              // Fall-through
        //              case 12: // 2 digit year, with seconds
        //                  yearLength = LENGTH_OF_2_DIGIT;
        //                  break;
        //              case 14: // 4 digit year, with seconds
        //                  yearLength = 2 * LENGTH_OF_2_DIGIT;
        //                  break;
        //              default:
        //                  throw new ArgumentException(
        //                      "malformed UTCTime format: " + timeTextAndZone.timestring);
        //          }
        //          int year = Integer.ParseInt(timeTextAndZone.timestring.substring(0, yearLength));
        //          // Two-digit year's range is from 1954 to 2053.
        //          if (yearLength == LENGTH_OF_2_DIGIT)
        //          {
        //              if (year > 53)
        //              {
        //                  year += 1900;
        //              }
        //              else
        //              {
        //                  year += 2000;
        //              }
        //          }
        //          List<string> fields = SPLITTER_2_DIGIT.splitToList(
        //              timeTextAndZone.timestring.subSequence(yearLength, timeLength));
        //          int month = Integer.ParseInt(fields[0]);
        //          int day = Integer.ParseInt(fields[1]);
        //          int hour = Integer.ParseInt(fields[2]);
        //          int minute = Integer.ParseInt(fields[3]);
        //          int second = 0;
        //          if (hasSecond)
        //          {
        //              second = Integer.ParseInt(fields[4]);
        //          }
        //          value = new MutableDateTime(year, month, day, hour, minute, second, 0, timeTextAndZone.zone);
        //          if (!DateTimeZone.UTC.equals(timeTextAndZone.zone))
        //          {
        //              value.setZone(DateTimeZone.UTC);
        //          }
        //      }
        //      override
        //public void decodePerAligned(BitStreamReader reader)
        //      {
        //          Asn1IA5String result = new Asn1IA5String();
        //          result.setMaxSize(255);
        //          result.decodePerAligned(reader);
        //          retrieveResult(result);
        //      }

        //      override
        //public void decodePerUnaligned(BitStreamReader reader)
        //      {
        //          Asn1IA5String result = new Asn1IA5String();
        //          result.setMaxSize(255);
        //          result.decodePerUnaligned(reader);
        //          retrieveResult(result);
        //      }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }
    }
}