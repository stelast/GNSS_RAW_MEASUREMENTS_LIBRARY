﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Status : Asn1Enumerated
    { 

        public class Value : Asn1Enumerated.Value
        {
            public enum ValueEnum
            {
                state,
                current,
                unknown
            }
            public static List<int> values()
            {
                return new List<int>() { 0, 1, 2 };
            }
            public Value(ValueEnum rf)
            {
                switch (rf)
                {
                    case ValueEnum.state:
                        value = 0;
                        break;
                    case ValueEnum.current:
                        value = 1;
                        break;
                    case ValueEnum.unknown:
                        value = 2;
                        break;
                }
            }
            public Value(int i)
            {
                value = i;
            }

            private int value;
            virtual public int getAssignedValue()
            {
                return value;
            }

            virtual public bool isExtensionValue()
            {
                return false;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }

        public class ExtensionValue : Asn1Enumerated.Value
        {

            public ExtensionValue(int i)
            {
                value = i;
            }

            private int value;
            public int getAssignedValue()
            {
                return value;
            }

            public static List<int> values()
            {
                return new List<int>() { };
            }
            public bool isExtensionValue()
            {
                return true;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }
        protected override int getValueCount()
        {
            throw new NotImplementedException();
        }

        protected override bool isExtensible()
        {
            throw new NotImplementedException();
        }

        protected override Asn1Enumerated.Value lookupExtensionValue(int ordinal)
        {
            return new ExtensionValue(Value.values()[ordinal]);
        }

        protected override Asn1Enumerated.Value lookupValue(int ordinal)
        {
            return new Value(Value.values()[ordinal]);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}