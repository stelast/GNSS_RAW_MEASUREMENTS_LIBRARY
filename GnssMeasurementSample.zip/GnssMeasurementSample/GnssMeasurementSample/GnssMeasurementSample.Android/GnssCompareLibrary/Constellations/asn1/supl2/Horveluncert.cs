﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Horveluncert : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Horveluncert
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Horveluncert() : base()
        { 
        }

        override public Asn1Tag getTag()
        {
            return TAG_Horveluncert;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Horveluncert != null)
            {
                //return ImmutableList.of(TAG_Horveluncert);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Horveluncert from encoded stream.
         */
        public static Horveluncert fromPerUnaligned(byte[] encodedBytes)
        {
            Horveluncert result = new Horveluncert();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Horveluncert from encoded stream.
         */
        public static Horveluncert fromPerAligned(byte[] encodedBytes)
        {
            Horveluncert result = new Horveluncert();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        private Horveluncert.bearingType bearing_;
        public Horveluncert.bearingType getBearing()
        {
            return bearing_;
        }
        /**
         * @throws ClassCastException if value is not a Horveluncert.bearingType
         */
        public void setBearing(Asn1Object value)
        {
            this.bearing_ = (Horveluncert.bearingType)value;
        }
        public Horveluncert.bearingType setBearingToNewInstance()
        {
            bearing_ = new Horveluncert.bearingType();
            return bearing_;
        }

        private Horveluncert.horspeedType horspeed_;
        public Horveluncert.horspeedType getHorspeed()
        {
            return horspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horveluncert.horspeedType
         */
        public void setHorspeed(Asn1Object value)
        {
            this.horspeed_ = (Horveluncert.horspeedType)value;
        }
        public Horveluncert.horspeedType setHorspeedToNewInstance()
        {
            horspeed_ = new Horveluncert.horspeedType();
            return horspeed_;
        }

        private Horveluncert.uncertspeedType uncertspeed_;
        public Horveluncert.uncertspeedType getUncertspeed()
        {
            return uncertspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horveluncert.uncertspeedType
         */
        public void setUncertspeed(Asn1Object value)
        {
            this.uncertspeed_ = (Horveluncert.uncertspeedType)value;
        }
        public Horveluncert.uncertspeedType setUncertspeedToNewInstance()
        {
            uncertspeed_ = new Horveluncert.uncertspeedType();
            return uncertspeed_;
        }


        /**
         * 
         */
        public class bearingType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_bearingType
          = Asn1Tag.fromClassAndNumber(-1, -1);

            public bearingType() : base()
            {
                setMinSize(9);
                setMaxSize(9);

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_bearingType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_bearingType != null)
                {
                    //return ImmutableList.of(TAG_bearingType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerUnaligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerAligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "bearingType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class horspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_horspeedType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public horspeedType() : base()
            {
                setMinSize(16);
                setMaxSize(16);

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_horspeedType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horspeedType != null)
                {
                    //return ImmutableList.of(TAG_horspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerAligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horspeedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class uncertspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_uncertspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public uncertspeedType() : base()
            {
                setMinSize(8);
                setMaxSize(8);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_uncertspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_uncertspeedType != null)
                {
                    //return ImmutableList.of(TAG_uncertspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new uncertspeedType from encoded stream.
             */
            public static uncertspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                uncertspeedType result = new uncertspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new uncertspeedType from encoded stream.
             */
            public static uncertspeedType fromPerAligned(byte[] encodedBytes)
            {
                uncertspeedType result = new uncertspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "uncertspeedType = " + getValue() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}