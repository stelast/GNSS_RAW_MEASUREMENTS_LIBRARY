﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class LocationId : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_LocationId
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public LocationId() : base()
        { 
        }

        override public Asn1Tag getTag()
        {
            return TAG_LocationId;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_LocationId != null)
            {
                //return ImmutableList.of(TAG_LocationId);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new LocationId from encoded stream.
         */
        public static LocationId fromPerUnaligned(byte[] encodedBytes)
        {
            LocationId result = new LocationId();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new LocationId from encoded stream.
         */
        public static LocationId fromPerAligned(byte[] encodedBytes)
        {
            LocationId result = new LocationId();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private CellInfo cellInfo_;
        public CellInfo getCellInfo()
        {
            return cellInfo_;
        }
        /**
         * @throws ClassCastException if value is not a CellInfo
         */
        public void setCellInfo(Asn1Object value)
        {
            this.cellInfo_ = (CellInfo)value;
        }
        public CellInfo setCellInfoToNewInstance()
        {
            cellInfo_ = new CellInfo();
            return cellInfo_;
        }

        private Status status_;
        public Status getStatus()
        {
            return status_;
        }
        /**
         * @throws ClassCastException if value is not a Status
         */
        public void setStatus(Asn1Object value)
        {
            this.status_ = (Status)value;
        }
        public Status setStatusToNewInstance()
        {
            status_ = new Status();
            return status_;
        }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}