﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Java.Math;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PositionEstimate : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_PositionEstimate = Asn1Tag.fromClassAndNumber(-1, -1);

        public PositionEstimate() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_PositionEstimate;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_PositionEstimate != null)
            {
                //return ImmutableList.of(TAG_PositionEstimate);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new PositionEstimate from encoded stream.
         */
        public static PositionEstimate fromPerUnaligned(byte[] encodedBytes)
        {
            PositionEstimate result = new PositionEstimate();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new PositionEstimate from encoded stream.
         */
        public static PositionEstimate fromPerAligned(byte[] encodedBytes)
        {
            PositionEstimate result = new PositionEstimate();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private PositionEstimate.latitudeSignType latitudeSign_;
        public PositionEstimate.latitudeSignType getLatitudeSign()
        {
            return latitudeSign_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate.latitudeSignType
         */
        public void setLatitudeSign(Asn1Object value)
        {
            this.latitudeSign_ = (PositionEstimate.latitudeSignType)value;
        }
        public PositionEstimate.latitudeSignType setLatitudeSignToNewInstance()
        {
            latitudeSign_ = new PositionEstimate.latitudeSignType();
            return latitudeSign_;
        }

        private PositionEstimate.latitudeType latitude_;
        public PositionEstimate.latitudeType getLatitude()
        {
            return latitude_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate.latitudeType
         */
        public void setLatitude(Asn1Object value)
        {
            this.latitude_ = (PositionEstimate.latitudeType)value;
        }
        public PositionEstimate.latitudeType setLatitudeToNewInstance()
        {
            latitude_ = new PositionEstimate.latitudeType();
            return latitude_;
        }

        private PositionEstimate.longitudeType longitude_;
        public PositionEstimate.longitudeType getLongitude()
        {
            return longitude_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate.longitudeType
         */
        public void setLongitude(Asn1Object value)
        {
            this.longitude_ = (PositionEstimate.longitudeType)value;
        }
        public PositionEstimate.longitudeType setLongitudeToNewInstance()
        {
            longitude_ = new PositionEstimate.longitudeType();
            return longitude_;
        }

        private PositionEstimate.uncertaintyType uncertainty_;
        public PositionEstimate.uncertaintyType getUncertainty()
        {
            return uncertainty_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate.uncertaintyType
         */
        public void setUncertainty(Asn1Object value)
        {
            this.uncertainty_ = (PositionEstimate.uncertaintyType)value;
        }
        public PositionEstimate.uncertaintyType setUncertaintyToNewInstance()
        {
            uncertainty_ = new PositionEstimate.uncertaintyType();
            return uncertainty_;
        }

        private PositionEstimate.confidenceType confidence_;
        public PositionEstimate.confidenceType getConfidence()
        {
            return confidence_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate.confidenceType
         */
        public void setConfidence(Asn1Object value)
        {
            this.confidence_ = (PositionEstimate.confidenceType)value;
        }
        public PositionEstimate.confidenceType setConfidenceToNewInstance()
        {
            confidence_ = new PositionEstimate.confidenceType();
            return confidence_;
        }

        private AltitudeInfo altitudeInfo_;
        public AltitudeInfo getAltitudeInfo()
        {
            return altitudeInfo_;
        }
        /**
         * @throws ClassCastException if value is not a AltitudeInfo
         */
        public void setAltitudeInfo(Asn1Object value)
        {
            this.altitudeInfo_ = (AltitudeInfo)value;
        }
        public AltitudeInfo setAltitudeInfoToNewInstance()
        {
            altitudeInfo_ = new AltitudeInfo();
            return altitudeInfo_;
        }


        //public static class latitudeSignType : Asn1Enumerated
        //{
        //}


        //

            /**
             * 
             */
        public class latitudeType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_latitudeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public latitudeType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("8388607"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_latitudeType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_latitudeType != null)
                {
                    //return ImmutableList.of(TAG_latitudeType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new latitudeType from encoded stream.
             */
            public static latitudeType fromPerUnaligned(byte[] encodedBytes)
            {
                latitudeType result = new latitudeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new latitudeType from encoded stream.
             */
            public static latitudeType fromPerAligned(byte[] encodedBytes)
            {
                latitudeType result = new latitudeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "latitudeType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class longitudeType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_longitudeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public longitudeType() : base()
            {
                setValueRange(new BigInteger("-8388608"), new BigInteger("8388607"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_longitudeType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_longitudeType != null)
                {
                    //return ImmutableList.of(TAG_longitudeType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new longitudeType from encoded stream.
             */
            public static longitudeType fromPerUnaligned(byte[] encodedBytes)
            {
                longitudeType result = new longitudeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new longitudeType from encoded stream.
             */
            public static longitudeType fromPerAligned(byte[] encodedBytes)
            {
                longitudeType result = new longitudeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "longitudeType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
        * 
*/
        public class uncertaintyType : Asn1Sequence
        {
            //

            private static readonly Asn1Tag TAG_uncertaintyType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public uncertaintyType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_uncertaintyType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_uncertaintyType != null)
                {
                    //return ImmutableList.of(TAG_uncertaintyType);
                    return Asn1Sequence.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Sequence.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new uncertaintyType from encoded stream.
             */
            public static uncertaintyType fromPerUnaligned(byte[] encodedBytes)
            {
                uncertaintyType result = new uncertaintyType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new uncertaintyType from encoded stream.
             */
            public static uncertaintyType fromPerAligned(byte[] encodedBytes)
            {
                uncertaintyType result = new uncertaintyType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }



            override protected bool isExtensible()
            {
                return false;
            }

            override public bool containsExtensionValues()
            {
                foreach (SequenceComponent extensionComponent in getExtensionComponents())
                {
                    if (extensionComponent.isExplicitlySet()) return true;
                }
                return false;
            }


            private uncertaintyType.uncertaintySemiMajorType uncertaintySemiMajor_;
            public uncertaintyType.uncertaintySemiMajorType getUncertaintySemiMajor()
            {
                return uncertaintySemiMajor_;
            }
            /**
             * @throws ClassCastException if value is not a uncertaintyType.uncertaintySemiMajorType
             */
            public void setUncertaintySemiMajor(Asn1Object value)
            {
                this.uncertaintySemiMajor_ = (uncertaintyType.uncertaintySemiMajorType)value;
            }
            public uncertaintyType.uncertaintySemiMajorType setUncertaintySemiMajorToNewInstance()
            {
                uncertaintySemiMajor_ = new uncertaintyType.uncertaintySemiMajorType();
                return uncertaintySemiMajor_;
            }

            private uncertaintyType.uncertaintySemiMinorType uncertaintySemiMinor_;
            public uncertaintyType.uncertaintySemiMinorType getUncertaintySemiMinor()
            {
                return uncertaintySemiMinor_;
            }
            /**
             * @throws ClassCastException if value is not a uncertaintyType.uncertaintySemiMinorType
             */
            public void setUncertaintySemiMinor(Asn1Object value)
            {
                this.uncertaintySemiMinor_ = (uncertaintyType.uncertaintySemiMinorType)value;
            }
            public uncertaintyType.uncertaintySemiMinorType setUncertaintySemiMinorToNewInstance()
            {
                uncertaintySemiMinor_ = new uncertaintyType.uncertaintySemiMinorType();
                return uncertaintySemiMinor_;
            }

            private uncertaintyType.orientationMajorAxisType orientationMajorAxis_;
            public uncertaintyType.orientationMajorAxisType getOrientationMajorAxis()
            {
                return orientationMajorAxis_;
            }
            /**
             * @throws ClassCastException if value is not a uncertaintyType.orientationMajorAxisType
             */
            public void setOrientationMajorAxis(Asn1Object value)
            {
                this.orientationMajorAxis_ = (uncertaintyType.orientationMajorAxisType)value;
            }
            public uncertaintyType.orientationMajorAxisType setOrientationMajorAxisToNewInstance()
            {
                orientationMajorAxis_ = new uncertaintyType.orientationMajorAxisType();
                return orientationMajorAxis_;
            }



            // Copyright 2008 Google Inc. All Rights Reserved.
            /*
             * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
             */


            //

            /**
             * 
             */
            public class uncertaintySemiMajorType : Asn1Integer
            {
                //

                private static readonly Asn1Tag TAG_uncertaintySemiMajorType
                    = Asn1Tag.fromClassAndNumber(-1, -1);

                public uncertaintySemiMajorType() : base()
                {
                    setValueRange(new BigInteger("0"), new BigInteger("127"));

                }

                override

                  public Asn1Tag getTag()
                {
                    return TAG_uncertaintySemiMajorType;
                }

                override
                  public bool isTagImplicit()
                {
                    return true;
                }

                public static ImmutableList<Asn1Tag> getPossibleFirstTags()
                {
                    if (TAG_uncertaintySemiMajorType != null)
                    {
                        //return ImmutableList.of(TAG_uncertaintySemiMajorType);
                        return Asn1Integer.getPossibleFirstTags();
                    }
                    else
                    {
                        return Asn1Integer.getPossibleFirstTags();
                    }
                }

                /**
                 * Creates a new uncertaintySemiMajorType from encoded stream.
                 */
                public static uncertaintySemiMajorType fromPerUnaligned(byte[] encodedBytes)
                {
                    uncertaintySemiMajorType result = new uncertaintySemiMajorType();
                    result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                /**
                 * Creates a new uncertaintySemiMajorType from encoded stream.
                 */
                public static uncertaintySemiMajorType fromPerAligned(byte[] encodedBytes)
                {
                    uncertaintySemiMajorType result = new uncertaintySemiMajorType();
                    result.decodePerAligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                //override public Iterable<BitStream> encodePerUnaligned()
                //{
                //    return base.encodePerUnaligned();
                //}

                //override public Iterable<BitStream> encodePerAligned()
                //{
                //    return base.encodePerAligned();
                //}

                override public void decodePerUnaligned(BitStreamReader reader)
                {
                    base.decodePerUnaligned(reader);
                }

                override public void decodePerAligned(BitStreamReader reader)
                {
                    base.decodePerAligned(reader);
                }

                public String toString()
                {
                    return toIndentedString("");
                }

                public String toIndentedString(String indent)
                {
                    return "uncertaintySemiMajorType = " + getInteger() + ";\n";
                }
            }


            // Copyright 2008 Google Inc. All Rights Reserved.
            /*
             * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
             */


            //

            /**
             * 
             */
            public class uncertaintySemiMinorType : Asn1Integer
            {
                //

                private static readonly Asn1Tag TAG_uncertaintySemiMinorType
                    = Asn1Tag.fromClassAndNumber(-1, -1);

                public uncertaintySemiMinorType() : base()
                {
                    setValueRange(new BigInteger("0"), new BigInteger("127"));

                }

                override

                  public Asn1Tag getTag()
                {
                    return TAG_uncertaintySemiMinorType;
                }

                override
                  public bool isTagImplicit()
                {
                    return true;
                }

                public static ImmutableList<Asn1Tag> getPossibleFirstTags()
                {
                    if (TAG_uncertaintySemiMinorType != null)
                    {
                        //return ImmutableList.of(TAG_uncertaintySemiMinorType);
                        return Asn1Integer.getPossibleFirstTags();
                    }
                    else
                    {
                        return Asn1Integer.getPossibleFirstTags();
                    }
                }

                /**
                 * Creates a new uncertaintySemiMinorType from encoded stream.
                 */
                public static uncertaintySemiMinorType fromPerUnaligned(byte[] encodedBytes)
                {
                    uncertaintySemiMinorType result = new uncertaintySemiMinorType();
                    result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                /**
                 * Creates a new uncertaintySemiMinorType from encoded stream.
                 */
                public static uncertaintySemiMinorType fromPerAligned(byte[] encodedBytes)
                {
                    uncertaintySemiMinorType result = new uncertaintySemiMinorType();
                    result.decodePerAligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                //override public Iterable<BitStream> encodePerUnaligned()
                //{
                //    return base.encodePerUnaligned();
                //}

                //override public Iterable<BitStream> encodePerAligned()
                //{
                //    return base.encodePerAligned();
                //}

                override public void decodePerUnaligned(BitStreamReader reader)
                {
                    base.decodePerUnaligned(reader);
                }

                override public void decodePerAligned(BitStreamReader reader)
                {
                    base.decodePerAligned(reader);
                }

                public String toString()
                {
                    return toIndentedString("");
                }

                public String toIndentedString(String indent)
                {
                    return "uncertaintySemiMinorType = " + getInteger() + ";\n";
                }
            }


            // Copyright 2008 Google Inc. All Rights Reserved.
            /*
             * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
             */


            //

            /**
             * 
             */
            public class orientationMajorAxisType : Asn1Integer
            {
                //

                private static readonly Asn1Tag TAG_orientationMajorAxisType
                    = Asn1Tag.fromClassAndNumber(-1, -1);

                public orientationMajorAxisType() : base()
                {
                    setValueRange(new BigInteger("0"), new BigInteger("180"));

                }

                override

                  public Asn1Tag getTag()
                {
                    return TAG_orientationMajorAxisType;
                }

                override
                  public bool isTagImplicit()
                {
                    return true;
                }

                public static ImmutableList<Asn1Tag> getPossibleFirstTags()
                {
                    if (TAG_orientationMajorAxisType != null)
                    {
                        //return ImmutableList.of(TAG_orientationMajorAxisType);
                        return Asn1Integer.getPossibleFirstTags();
                    }
                    else
                    {
                        return Asn1Integer.getPossibleFirstTags();
                    }
                }

                /**
                 * Creates a new orientationMajorAxisType from encoded stream.
                 */
                public static orientationMajorAxisType fromPerUnaligned(byte[] encodedBytes)
                {
                    orientationMajorAxisType result = new orientationMajorAxisType();
                    result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                /**
                 * Creates a new orientationMajorAxisType from encoded stream.
                 */
                public static orientationMajorAxisType fromPerAligned(byte[] encodedBytes)
                {
                    orientationMajorAxisType result = new orientationMajorAxisType();
                    result.decodePerAligned(new BitStreamReader(encodedBytes));
                    return result;
                }

                //override public Iterable<BitStream> encodePerUnaligned()
                //{
                //    return base.encodePerUnaligned();
                //}

                //override public Iterable<BitStream> encodePerAligned()
                //{
                //    return base.encodePerAligned();
                //}

                override public void decodePerUnaligned(BitStreamReader reader)
                {
                    base.decodePerUnaligned(reader);
                }

                override public void decodePerAligned(BitStreamReader reader)
                {
                    base.decodePerAligned(reader);
                }

                public String toString()
                {
                    return toIndentedString("");
                }

                public String toIndentedString(String indent)
                {
                    return "orientationMajorAxisType = " + getInteger() + ";\n";
                }
            }





            //  override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            protected override IEnumerable<SequenceComponent> getComponents()
            {
                ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
                return builder.ToImmutable();
            }

            protected override IEnumerable<SequenceComponent> getExtensionComponents()
            {
                ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
                return builder.ToImmutable();
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class confidenceType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_confidenceType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public confidenceType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("100"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_confidenceType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_confidenceType != null)
                {
                    //return ImmutableList.of(TAG_confidenceType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new confidenceType from encoded stream.
             */
            public static confidenceType fromPerUnaligned(byte[] encodedBytes)
            {
                confidenceType result = new confidenceType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new confidenceType from encoded stream.
             */
            public static confidenceType fromPerAligned(byte[] encodedBytes)
            {
                confidenceType result = new confidenceType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "confidenceType = " + getInteger() + ";\n";
            }
        }



        /**
         * 
         */
        public class latitudeSignType : Asn1Enumerated
        {
            public class Value : Asn1Enumerated.Value
            {
                public enum ValueEnum {
                    north,
                    south
                } 
                public static List<int> values()
                {
                    return new List<int>() { 0,1 };
                }
                public Value(ValueEnum rf)
                {
                    switch (rf)
                    {
                        case ValueEnum.north:
                            value = 0;
                            break;
                        case ValueEnum.south:
                            value = 1;
                            break;
                    }
                }
                public Value(int i)
                {
                    value = i;
                }

                private int value;
                virtual public int getAssignedValue()
                {
                    return value;
                }

                virtual public bool isExtensionValue()
                {
                    return false;
                }

                public int ordinal()
                {
                    throw new NotImplementedException();
                }
            }

            protected Value getDefaultValue()
            {
                return null;
            }
             
            public Value enumValue()
            {
                return (Value)getValue();
            }
             

            public void setTo_north()
            {
                setValue(new Value(Value.ValueEnum.north));
            }

            public void setTo_south()
            {
                setValue(new Value(Value.ValueEnum.south));
            }
             

            public class ExtensionValue : Asn1Enumerated.Value
            { 

                public ExtensionValue(int i) {
                    value = i;
                }

                private int value;
                public int getAssignedValue()
                {
                    return value;
                }

                public static List<int> values()
                {
                    return new List<int>() { };
                }
                public bool isExtensionValue()
                {
                    return true;
                }

                public int ordinal()
                {
                    throw new NotImplementedException();
                }
            }
             
            public ExtensionValue extEnumValue()
            {
                return (ExtensionValue)getValue();
            }
             

            private static readonly Asn1Tag TAG_latitudeSignType = Asn1Tag.fromClassAndNumber(-1, -1);

            public latitudeSignType() : base()
            { 
                // use template substitution instead of calling getDefaultValue(), since
                // calling virtual methods from a ctor is frowned upon here.
                setValue(null);
            }

            override public Asn1Tag getTag()
            {
                return TAG_latitudeSignType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_latitudeSignType != null)
                {
                    //return ImmutableList.of(TAG_latitudeSignType);
                    return Asn1Enumerated.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Enumerated.getPossibleFirstTags();
                }
            }

            override protected bool isExtensible()
            {
                return false;
            }

            override protected Asn1Enumerated.Value lookupValue(int ordinal)
            {
                return new Value(Value.values()[ordinal]);
            }

            override protected Asn1Enumerated.Value lookupExtensionValue(int ordinal)
            {
                return new ExtensionValue(Value.values()[ordinal]); 
            }

            override protected int getValueCount()
            {
                return Value.values().Count();
            }

            /**
             * Creates a new latitudeSignType from encoded stream.
             */
            public static latitudeSignType fromPerUnaligned(byte[] encodedBytes)
            {
                latitudeSignType result = new latitudeSignType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new latitudeSignType from encoded stream.
             */
            public static latitudeSignType fromPerAligned(byte[] encodedBytes)
            {
                latitudeSignType result = new latitudeSignType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "latitudeSignType = " + getValue() + ";\n";
            }

            public override IEnumerable<BitStream> encodePerAligned()
            {
                throw new NotImplementedException();
            }

            public override IEnumerable<BitStream> encodePerUnaligned()
            {
                throw new NotImplementedException();
            }
        }



        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}