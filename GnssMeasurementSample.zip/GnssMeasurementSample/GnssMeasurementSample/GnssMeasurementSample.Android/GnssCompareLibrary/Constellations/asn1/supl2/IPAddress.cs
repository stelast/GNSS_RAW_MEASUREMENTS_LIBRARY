﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class IPAddress : Asn1Choice
    {
        private static readonly Asn1Tag TAG_IPAddress = Asn1Tag.fromClassAndNumber(-1, -1);

        private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;

        public IPAddress() : base()
        { 
        }

        override public Asn1Tag getTag()
        {
            return TAG_IPAddress;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_IPAddress != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_IPAddress);
                return builder.ToImmutable(); 
            }
            else
            {
                return tagToSelection.Keys.ToImmutableList();
            }
        }

        /**
         * Creates a new IPAddress from encoded stream.
         */
        public static IPAddress fromPerUnaligned(byte[] encodedBytes)
        {
            IPAddress result = new IPAddress();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new IPAddress from encoded stream.
         */
        public static IPAddress fromPerAligned(byte[] encodedBytes)
        {
            IPAddress result = new IPAddress();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override Asn1Object getValue()
        {
            return element;
        }

        protected override Asn1Object createAndSetValue(bool isExtensionValue, int ordinal)
        {
            extension = isExtensionValue;
            if (isExtensionValue)
            {
                //ordinal = ordinal + 8; 
                switch (ordinal)
                {
                    case 8:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTART);
                        break;
                    case 9:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDRESPONSE);
                        break;
                    case 10:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLTRIGGEREDSTOP);
                        break;
                    case 11:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLNOTIFY);
                        break;
                    case 12:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLNOTIFYRESPONSE);
                        break;
                    case 13:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLSETINIT);
                        break;
                    case 14:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.MsSUPLREPORT);
                        break;
                }
            }
            else
            {
                switch (ordinal)
                {
                    case 29:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Ipv4Address);
                        break;
                    case 30:
                        selection = Select.Create(ChoiceComponent.SelectEnum.Ipv6Address);
                        break;  
                }
            }
            element = selection.createElement();
            return element;
        }

        protected override ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            Select select = tagToSelection[tag];
            if (select == null)
            {
                throw new Exception("Unknown selection tag: " + tag);
            }
            element = select.createElement();
            selection = select;
            extension = false;
            return select;
        }

        protected override int getOptionCount()
        {
            if (hasExtensionValue())
            {
                return Extend.values().Count();
            }
            return Select.values().Count();
        }

        protected override ChoiceComponent getSelectedComponent()
        {
            return selection;
        }

        protected override int getSelectionOrdinal()
        {
            return selection.ordinal();
        }

        protected override bool hasExtensionValue()
        {
            return extension;
        }

        protected override bool isExtensible()
        {
            return false;
        }

        /**
         * 
         */
        public class ipv4AddressType : Asn1OctetString
        {
            //

            private static readonly Asn1Tag TAG_ipv4AddressType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ipv4AddressType() : base()
            {
                setMinSize(4);
                setMaxSize(4);

            }

            override

            public Asn1Tag getTag()
            {
                return TAG_ipv4AddressType;
            }

            override
            public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ipv4AddressType != null)
                {
                    //return ImmutableList.of(TAG_ipv4AddressType);
                    return Asn1OctetString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1OctetString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ipv4AddressType from encoded stream.
             */
            public static ipv4AddressType fromPerUnaligned(byte[] encodedBytes)
            {
                ipv4AddressType result = new ipv4AddressType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ipv4AddressType from encoded stream.
             */
            public static ipv4AddressType fromPerAligned(byte[] encodedBytes)
            {
                ipv4AddressType result = new ipv4AddressType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            protected String getTypeName()
            {
                return "ipv4AddressType";
            }
        }


        public bool isIpv4Address()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Ipv4Address == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Ipv4Address == selection;
        }

        /**
         * @throws {@code IllegalStateException} if {@code !isIpv4Address}.
         */
        public IPAddress.ipv4AddressType getIpv4Address()
        {
            if (!isIpv4Address())
            {
                throw new Exception("IPAddress value not a Ipv4Address");
            }
            return (IPAddress.ipv4AddressType)element;
        }

        public void setIpv4Address(IPAddress.ipv4AddressType selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Ipv4Address);
            //selection = Select.$Ipv4Address;
            extension = false;
            element = selected;
        }

        public IPAddress.ipv4AddressType setIpv4AddressToNewInstance()
        {
            IPAddress.ipv4AddressType element = new IPAddress.ipv4AddressType();
            setIpv4Address(element);
            return element;
        }

        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ipv6AddressType : Asn1OctetString
        {
            //

            private static readonly Asn1Tag TAG_ipv6AddressType = Asn1Tag.fromClassAndNumber(-1, -1);

            public ipv6AddressType() : base()
            {
                setMinSize(16);
                setMaxSize(16);

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_ipv6AddressType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ipv6AddressType != null)
                {
                    //return ImmutableList.of(TAG_ipv6AddressType);
                    return Asn1OctetString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1OctetString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ipv6AddressType from encoded stream.
             */
            public static ipv6AddressType fromPerUnaligned(byte[] encodedBytes)
            {
                ipv6AddressType result = new ipv6AddressType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ipv6AddressType from encoded stream.
             */
            public static ipv6AddressType fromPerAligned(byte[] encodedBytes)
            {
                ipv6AddressType result = new ipv6AddressType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            protected String getTypeName()
            {
                return "ipv6AddressType";
            }
        }


        public bool isIpv6Address()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.Ipv6Address == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$Ipv6Address == selection;
        }

        /**
         * @throws {@code IllegalStateException} if {@code !isIpv6Address}.
         */
        public IPAddress.ipv6AddressType getIpv6Address()
        {
            if (!isIpv6Address())
            {
                throw new Exception("IPAddress value not a Ipv6Address");
            }
            return (IPAddress.ipv6AddressType)element;
        }

        public void setIpv6Address(IPAddress.ipv6AddressType selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.Ipv6Address);
            //selection = Select.$Ipv6Address;
            extension = false;
            element = selected;
        }

        public IPAddress.ipv6AddressType setIpv6AddressToNewInstance()
        {
            IPAddress.ipv6AddressType element = new IPAddress.ipv6AddressType();
            setIpv6Address(element);
            return element;
        }

        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Extend(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 24 };
            }

            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.undefined:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 24), true, choose); 
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                throw new NotImplementedException();
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return tipo;
            }

            public bool isImplicitTagging()
            {
                return this.isImplicitTaggin;
            }

            public int ordinal()
            {
                throw new NotImplementedException();
            }
        }


        public class Select : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Select(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 29, 30 };
            }

            public static Select Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.Ipv4Address:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 29), true, choose);
                    case ChoiceComponent.SelectEnum.Ipv6Address:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 30), true, choose); 
                    default:
                        return null;
                }
            }

            public int ordinal()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.Ipv4Address:
                        return 29;
                    case ChoiceComponent.SelectEnum.Ipv6Address:
                        return 30;
                    default:
                        return 0;
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }
            virtual public List<Asn1Tag> getPossibleFirstTags()
            {
                return new List<Asn1Tag>();
            }

            virtual public String elementIndentedString(Asn1Object element, String indent)
            {
                return "Select " + " : " + element.toIndentedString(indent);
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.Ipv4Address:
                        return new Horvel();
                    case ChoiceComponent.SelectEnum.Ipv6Address:
                        return new Horandvervel(); 
                    default:
                        throw new SystemException("Select template error");
                }
            }

            ChoiceComponent.SelectEnum ChoiceComponent.getTypeEnum()
            {
                return tipo;
            }
        }


    }
}