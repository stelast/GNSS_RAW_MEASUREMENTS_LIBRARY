﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using Java.Math;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SatelliteInfoElement : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_SatelliteInfoElement
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public SatelliteInfoElement() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_SatelliteInfoElement;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SatelliteInfoElement != null)
            {
                //return ImmutableList.of(TAG_SatelliteInfoElement);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new SatelliteInfoElement from encoded stream.
         */
        public static SatelliteInfoElement fromPerUnaligned(byte[] encodedBytes)
        {
            SatelliteInfoElement result = new SatelliteInfoElement();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SatelliteInfoElement from encoded stream.
         */
        public static SatelliteInfoElement fromPerAligned(byte[] encodedBytes)
        {
            SatelliteInfoElement result = new SatelliteInfoElement();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private SatelliteInfoElement.satIdType satId_;
        public SatelliteInfoElement.satIdType getSatId()
        {
            return satId_;
        }
        /**
         * @throws ClassCastException if value is not a SatelliteInfoElement.satIdType
         */
        public void setSatId(Asn1Object value)
        {
            this.satId_ = (SatelliteInfoElement.satIdType)value;
        }
        public SatelliteInfoElement.satIdType setSatIdToNewInstance()
        {
            satId_ = new SatelliteInfoElement.satIdType();
            return satId_;
        }

        private SatelliteInfoElement.iODEType iODE_;
        public SatelliteInfoElement.iODEType getIODE()
        {
            return iODE_;
        }
        /**
         * @throws ClassCastException if value is not a SatelliteInfoElement.iODEType
         */
        public void setIODE(Asn1Object value)
        {
            this.iODE_ = (SatelliteInfoElement.iODEType)value;
        }
        public SatelliteInfoElement.iODEType setIODEToNewInstance()
        {
            iODE_ = new SatelliteInfoElement.iODEType();
            return iODE_;
        }


        /**
         * 
         */
        public class satIdType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_satIdType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public satIdType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("63"));

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_satIdType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_satIdType != null)
                {
                    //return ImmutableList.of(TAG_satIdType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new satIdType from encoded stream.
             */
            public static satIdType fromPerUnaligned(byte[] encodedBytes)
            {
                satIdType result = new satIdType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new satIdType from encoded stream.
             */
            public static satIdType fromPerAligned(byte[] encodedBytes)
            {
                satIdType result = new satIdType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "satIdType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class iODEType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_iODEType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public iODEType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_iODEType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_iODEType != null)
                {
                    //return ImmutableList.of(TAG_iODEType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new iODEType from encoded stream.
             */
            public static iODEType fromPerUnaligned(byte[] encodedBytes)
            {
                iODEType result = new iODEType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new iODEType from encoded stream.
             */
            public static iODEType fromPerAligned(byte[] encodedBytes)
            {
                iODEType result = new iODEType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "iODEType = " + getInteger() + ";\n";
            }
        }





        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}