﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SUPLPOSINIT : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_SUPLPOSINIT = Asn1Tag.fromClassAndNumber(-1, -1);

        public SUPLPOSINIT() : base()
        {
        }
        override public Asn1Tag getTag()
        {
            return TAG_SUPLPOSINIT;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SUPLPOSINIT != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_SUPLPOSINIT);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new SUPLPOSINIT from encoded stream.
         */
        public static SUPLPOSINIT fromPerUnaligned(byte[] encodedBytes)
        {
            SUPLPOSINIT result = new SUPLPOSINIT();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SUPLPOSINIT from encoded stream.
         */
        public static SUPLPOSINIT fromPerAligned(byte[] encodedBytes)
        {
            SUPLPOSINIT result = new SUPLPOSINIT();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private SETCapabilities sETCapabilities_;
        public SETCapabilities getSETCapabilities()
        {
            return sETCapabilities_;
        }
        /**
         * @throws ClassCastException if value is not a SETCapabilities
         */
        public void setSETCapabilities(Asn1Object value)
        {
            this.sETCapabilities_ = (SETCapabilities)value;
        }
        public SETCapabilities setSETCapabilitiesToNewInstance()
        {
            sETCapabilities_ = new SETCapabilities();
            return sETCapabilities_;
        }

        private RequestedAssistData requestedAssistData_;
        public RequestedAssistData getRequestedAssistData()
        {
            return requestedAssistData_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData
         */
        public void setRequestedAssistData(Asn1Object value)
        {
            this.requestedAssistData_ = (RequestedAssistData)value;
        }
        public RequestedAssistData setRequestedAssistDataToNewInstance()
        {
            requestedAssistData_ = new RequestedAssistData();
            return requestedAssistData_;
        }


        private LocationId locationId_;
        public LocationId getLocationId()
        {
            return locationId_;
        }
        /**
         * @throws ClassCastException if value is not a LocationId
         */
        public void setLocationId(Asn1Object value)
        {
            this.locationId_ = (LocationId)value;
        }
        public LocationId setLocationIdToNewInstance()
        {
            locationId_ = new LocationId();
            return locationId_;
        }

        private Position position_;
        public Position getPosition()
        {
            return position_;
        }
        /**
         * @throws ClassCastException if value is not a Position
         */
        public void setPosition(Asn1Object value)
        {
            this.position_ = (Position)value;
        }
        public Position setPositionToNewInstance()
        {
            position_ = new Position();
            return position_;
        }

        private SUPLPOS sUPLPOS_;
        public SUPLPOS getSUPLPOS()
        {
            return sUPLPOS_;
        }
        /**
         * @throws ClassCastException if value is not a SUPLPOS
         */
        public void setSUPLPOS(Asn1Object value)
        {
            this.sUPLPOS_ = (SUPLPOS)value;
        }
        public SUPLPOS setSUPLPOSToNewInstance()
        {
            sUPLPOS_ = new SUPLPOS();
            return sUPLPOS_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        //private Ver ver_;
        //public Ver getVer()
        //{
        //    return ver_;
        //}
        /**
         * @throws ClassCastException if value is not a Ver
         */
        //public void setVer(Asn1Object value)
        //{
        //    this.ver_ = (Ver)value;
        //}
        //public Ver setVerToNewInstance()
        //{
        //    ver_ = new Ver();
        //    return ver_;
        //}



        //private Ver2_SUPL_POS_INIT_extension extensionVer2_SUPL_POS_INIT_extension;
        //public Ver2_SUPL_POS_INIT_extension getExtensionVer2_SUPL_POS_INIT_extension()
        //{
        //    return extensionVer2_SUPL_POS_INIT_extension;
        //}
        /**
         * @throws ClassCastException if value is not a Ver2_SUPL_POS_INIT_extension
         */
        //public void setExtensionVer2_SUPL_POS_INIT_extension(Asn1Object value)
        //{
        //    extensionVer2_SUPL_POS_INIT_extension = (Ver2_SUPL_POS_INIT_extension)value;
        //}
        //public void setExtensionVer2_SUPL_POS_INIT_extensionToNewInstance()
        //{
        //    extensionVer2_SUPL_POS_INIT_extension = new Ver2_SUPL_POS_INIT_extension();
        //}





    }
}