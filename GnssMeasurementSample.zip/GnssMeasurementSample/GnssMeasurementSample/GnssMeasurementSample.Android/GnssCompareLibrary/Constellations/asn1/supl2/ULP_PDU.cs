﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using Java.Math;
using System.Collections.Generic;
using Version = GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2.Version;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class ULP_PDU : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_ULP_PDU = Asn1Tag.fromClassAndNumber(-1, -1);

        public ULP_PDU() : base()
        {
        }

        private SessionID sessionID_;
        public SessionID getSessionID()
        {
            return sessionID_;
        }

        /**
         * Creates a new ULP_PDU from encoded stream.
         */
        public static ULP_PDU fromPerUnaligned(byte[] encodedBytes)
        {
            ULP_PDU result = new ULP_PDU();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        protected override bool isExtensible()
        {
            return false;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }
        /**
         * @throws ClassCastException if value is not a SessionID
         */
        public void setSessionID(Asn1Object value)
        {
            this.sessionID_ = (SessionID)value;
        }
        public SessionID setSessionIDToNewInstance()
        {
            sessionID_ = new SessionID();
            return sessionID_;
        }

        private UlpMessage message_;
        public UlpMessage getMessage()
        {
            return message_;
        }
        /**
         * @throws ClassCastException if value is not a UlpMessage
         */
        public void setMessage(Asn1Object value)
        {
            this.message_ = (UlpMessage)value;
        }
        public UlpMessage setMessageToNewInstance()
        {
            message_ = new UlpMessage();
            return message_;
        }


        private ULP_PDU.lengthType length_;
        public ULP_PDU.lengthType getLength()
        {
            return length_;
        }
        /**
         * @throws ClassCastException if value is not a ULP_PDU.lengthType
         */
        public void setLength(Asn1Object value)
        {
            this.length_ = (ULP_PDU.lengthType)value;
        }
        public ULP_PDU.lengthType setLengthToNewInstance()
        {
            length_ = new ULP_PDU.lengthType();
            return length_;
        }

        private Version version_;
        public Version getVersion()
        {
            return version_;
        }
        /**
         * @throws ClassCastException if value is not a Version
         */
        public void setVersion(Asn1Object value)
        {
            this.version_ = (Version)value;
        }
        public Version setVersionToNewInstance()
        {
            version_ = new Version();
            return version_;
        }


        /**
         * 
         */
        public class lengthType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_lengthType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public lengthType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("65535"));

            }

            override public Asn1Tag getTag()
            {
                return TAG_lengthType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ULP_PDU != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_ULP_PDU);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new lengthType from encoded stream.
             */
            public static lengthType fromPerUnaligned(byte[] encodedBytes)
            {
                lengthType result = new lengthType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new lengthType from encoded stream.
             */
            public static lengthType fromPerAligned(byte[] encodedBytes)
            {
                lengthType result = new lengthType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "lengthType = " + getInteger() + ";\n";
            }
        }
         

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        } 

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this));
            builder.Add(new M4(this));
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            ULP_PDU objeto;
            public M1(ULP_PDU objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getLength();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if( tag == null )
                {
                    return ULP_PDU.lengthType.getPossibleFirstTags();
                } else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable(); 
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getLength() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setLengthToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getLength().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            ULP_PDU objeto;
            public M2(ULP_PDU objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getVersion();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return Version.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getVersion() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setVersionToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getVersion().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            ULP_PDU objeto;
            public M3(ULP_PDU objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSessionID();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SessionID.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSessionID() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setSessionIDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getSessionID().toIndentedString(indent);
            }
        }
        public class M4 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
            ULP_PDU objeto;
            public M4(ULP_PDU objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getMessage();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return UlpMessage.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getMessage() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setMessageToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getMessage().toIndentedString(indent);
            }
        }

    }
}