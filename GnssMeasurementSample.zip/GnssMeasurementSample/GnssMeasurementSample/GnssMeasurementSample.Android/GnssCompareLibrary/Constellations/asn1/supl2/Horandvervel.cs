﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Immutable;
using System.Collections.Generic;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Horandvervel : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Horandvervel
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Horandvervel() : base()
        {
        }

        override
  public Asn1Tag getTag()
        {
            return TAG_Horandvervel;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Horandvervel != null)
            {
                //return ImmutableList.of(TAG_Horandvervel);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Horandvervel from encoded stream.
         */
        public static Horandvervel fromPerUnaligned(byte[] encodedBytes)
        {
            Horandvervel result = new Horandvervel();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Horandvervel from encoded stream.
         */
        public static Horandvervel fromPerAligned(byte[] encodedBytes)
        {
            Horandvervel result = new Horandvervel();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }
        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        private Horandvervel.verdirectType verdirect_;
        public Horandvervel.verdirectType getVerdirect()
        {
            return verdirect_;
        }
        /**
         * @throws ClassCastException if value is not a Horandvervel.verdirectType
         */
        public void setVerdirect(Asn1Object value)
        {
            this.verdirect_ = (Horandvervel.verdirectType)value;
        }
        public Horandvervel.verdirectType setVerdirectToNewInstance()
        {
            verdirect_ = new Horandvervel.verdirectType();
            return verdirect_;
        }

        private Horandvervel.bearingType bearing_;
        public Horandvervel.bearingType getBearing()
        {
            return bearing_;
        }
        /**
         * @throws ClassCastException if value is not a Horandvervel.bearingType
         */
        public void setBearing(Asn1Object value)
        {
            this.bearing_ = (Horandvervel.bearingType)value;
        }
        public Horandvervel.bearingType setBearingToNewInstance()
        {
            bearing_ = new Horandvervel.bearingType();
            return bearing_;
        }

        private Horandvervel.horspeedType horspeed_;
        public Horandvervel.horspeedType getHorspeed()
        {
            return horspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandvervel.horspeedType
         */
        public void setHorspeed(Asn1Object value)
        {
            this.horspeed_ = (Horandvervel.horspeedType)value;
        }
        public Horandvervel.horspeedType setHorspeedToNewInstance()
        {
            horspeed_ = new Horandvervel.horspeedType();
            return horspeed_;
        }

        private Horandvervel.verspeedType verspeed_;
        public Horandvervel.verspeedType getVerspeed()
        {
            return verspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandvervel.verspeedType
         */
        public void setVerspeed(Asn1Object value)
        {
            this.verspeed_ = (Horandvervel.verspeedType)value;
        }
        public Horandvervel.verspeedType setVerspeedToNewInstance()
        {
            verspeed_ = new Horandvervel.verspeedType();
            return verspeed_;
        }


        /**
         * 
         */
        public class verdirectType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_verdirectType
          = Asn1Tag.fromClassAndNumber(-1, -1);

            public verdirectType() : base()
            {
                setMinSize(1);
                setMaxSize(1);

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_verdirectType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_verdirectType != null)
                {
                    //return ImmutableList.of(TAG_verdirectType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new verdirectType from encoded stream.
             */
            public static verdirectType fromPerUnaligned(byte[] encodedBytes)
            {
                verdirectType result = new verdirectType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new verdirectType from encoded stream.
             */
            public static verdirectType fromPerAligned(byte[] encodedBytes)
            {
                verdirectType result = new verdirectType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "verdirectType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class bearingType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_bearingType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public bearingType() : base()
            {
                setMinSize(9);
                setMaxSize(9);

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_bearingType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_bearingType != null)
                {
                    //return ImmutableList.of(TAG_bearingType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerUnaligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerAligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "bearingType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class horspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_horspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public horspeedType() : base()
            {
                setMinSize(16);
                setMaxSize(16);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_horspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horspeedType != null)
                {
                    //return ImmutableList.of(TAG_horspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerAligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horspeedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class verspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_verspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public verspeedType() : base()
            {
                setMinSize(8);
                setMaxSize(8);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_verspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_verspeedType != null)
                {
                    //return ImmutableList.of(TAG_verspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new verspeedType from encoded stream.
             */
            public static verspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                verspeedType result = new verspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new verspeedType from encoded stream.
             */
            public static verspeedType fromPerAligned(byte[] encodedBytes)
            {
                verspeedType result = new verspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "verspeedType = " + getValue() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}