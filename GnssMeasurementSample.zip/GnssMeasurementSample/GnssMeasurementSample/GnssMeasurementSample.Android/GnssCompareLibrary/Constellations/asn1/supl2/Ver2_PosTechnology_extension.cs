﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Ver2_PosTechnology_extension : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_Ver2_PosTechnology_extension
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Ver2_PosTechnology_extension() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_Ver2_PosTechnology_extension;
        }

        override
        public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Ver2_PosTechnology_extension != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_Ver2_PosTechnology_extension);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Ver2_PosTechnology_extension from encoded stream.
         */
        public static Ver2_PosTechnology_extension fromPerUnaligned(byte[] encodedBytes)
        {
            Ver2_PosTechnology_extension result = new Ver2_PosTechnology_extension();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Ver2_PosTechnology_extension from encoded stream.
         */
        public static Ver2_PosTechnology_extension fromPerAligned(byte[] encodedBytes)
        {
            Ver2_PosTechnology_extension result = new Ver2_PosTechnology_extension();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private GANSSPositionMethods gANSSPositionMethods_;
        public GANSSPositionMethods getGANSSPositionMethods()
        {
            return gANSSPositionMethods_;
        }
        /**
         * @throws ClassCastException if value is not a GANSSPositionMethods
         */
        public void setGANSSPositionMethods(Asn1Object value)
        {
            this.gANSSPositionMethods_ = (GANSSPositionMethods)value;
        }
        public GANSSPositionMethods setGANSSPositionMethodsToNewInstance()
        {
            gANSSPositionMethods_ = new GANSSPositionMethods();
            return gANSSPositionMethods_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}