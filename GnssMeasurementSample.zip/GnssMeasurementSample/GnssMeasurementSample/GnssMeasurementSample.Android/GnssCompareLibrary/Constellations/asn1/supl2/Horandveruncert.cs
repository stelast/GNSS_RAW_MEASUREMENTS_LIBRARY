﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Horandveruncert : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Horandveruncert = Asn1Tag.fromClassAndNumber(-1, -1);

        public Horandveruncert() : base()
        {
        }

        public Asn1Tag getTag()
        {
            return TAG_Horandveruncert;
        }

        public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Horandveruncert != null)
            {
                //return ImmutableList.of(TAG_Horandveruncert);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Horandveruncert from encoded stream.
         */
        public static Horandveruncert fromPerUnaligned(byte[] encodedBytes)
        {
            Horandveruncert result = new Horandveruncert();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Horandveruncert from encoded stream.
         */
        public static Horandveruncert fromPerAligned(byte[] encodedBytes)
        {
            Horandveruncert result = new Horandveruncert();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private Horandveruncert.verdirectType verdirect_;
        public Horandveruncert.verdirectType getVerdirect()
        {
            return verdirect_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.verdirectType
         */
        public void setVerdirect(Asn1Object value)
        {
            this.verdirect_ = (Horandveruncert.verdirectType)value;
        }
        public Horandveruncert.verdirectType setVerdirectToNewInstance()
        {
            verdirect_ = new Horandveruncert.verdirectType();
            return verdirect_;
        }

        private Horandveruncert.bearingType bearing_;
        public Horandveruncert.bearingType getBearing()
        {
            return bearing_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.bearingType
         */
        public void setBearing(Asn1Object value)
        {
            this.bearing_ = (Horandveruncert.bearingType)value;
        }
        public Horandveruncert.bearingType setBearingToNewInstance()
        {
            bearing_ = new Horandveruncert.bearingType();
            return bearing_;
        }

        private Horandveruncert.horspeedType horspeed_;
        public Horandveruncert.horspeedType getHorspeed()
        {
            return horspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.horspeedType
         */
        public void setHorspeed(Asn1Object value)
        {
            this.horspeed_ = (Horandveruncert.horspeedType)value;
        }
        public Horandveruncert.horspeedType setHorspeedToNewInstance()
        {
            horspeed_ = new Horandveruncert.horspeedType();
            return horspeed_;
        }

        private Horandveruncert.verspeedType verspeed_;
        public Horandveruncert.verspeedType getVerspeed()
        {
            return verspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.verspeedType
         */
        public void setVerspeed(Asn1Object value)
        {
            this.verspeed_ = (Horandveruncert.verspeedType)value;
        }
        public Horandveruncert.verspeedType setVerspeedToNewInstance()
        {
            verspeed_ = new Horandveruncert.verspeedType();
            return verspeed_;
        }

        private Horandveruncert.horuncertspeedType horuncertspeed_;
        public Horandveruncert.horuncertspeedType getHoruncertspeed()
        {
            return horuncertspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.horuncertspeedType
         */
        public void setHoruncertspeed(Asn1Object value)
        {
            this.horuncertspeed_ = (Horandveruncert.horuncertspeedType)value;
        }
        public Horandveruncert.horuncertspeedType setHoruncertspeedToNewInstance()
        {
            horuncertspeed_ = new Horandveruncert.horuncertspeedType();
            return horuncertspeed_;
        }

        private Horandveruncert.veruncertspeedType veruncertspeed_;
        public Horandveruncert.veruncertspeedType getVeruncertspeed()
        {
            return veruncertspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horandveruncert.veruncertspeedType
         */
        public void setVeruncertspeed(Asn1Object value)
        {
            this.veruncertspeed_ = (Horandveruncert.veruncertspeedType)value;
        }
        public Horandveruncert.veruncertspeedType setVeruncertspeedToNewInstance()
        {
            veruncertspeed_ = new Horandveruncert.veruncertspeedType();
            return veruncertspeed_;
        }



        /**
         * 
         */
        public class verdirectType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_verdirectType
          = Asn1Tag.fromClassAndNumber(-1, -1);

            public verdirectType() : base()
            {
                setMinSize(1);
                setMaxSize(1);

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_verdirectType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_verdirectType != null)
                {
                    //return ImmutableList.of(TAG_verdirectType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new verdirectType from encoded stream.
             */
            public static verdirectType fromPerUnaligned(byte[] encodedBytes)
            {
                verdirectType result = new verdirectType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new verdirectType from encoded stream.
             */
            public static verdirectType fromPerAligned(byte[] encodedBytes)
            {
                verdirectType result = new verdirectType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "verdirectType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class bearingType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_bearingType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public bearingType() : base()
            {
                setMinSize(9);
                setMaxSize(9);

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_bearingType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_bearingType != null)
                {
                    //return ImmutableList.of(TAG_bearingType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerUnaligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new bearingType from encoded stream.
             */
            public static bearingType fromPerAligned(byte[] encodedBytes)
            {
                bearingType result = new bearingType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "bearingType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class horspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_horspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public horspeedType() : base()
            { 
                setMinSize(16);
                setMaxSize(16);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_horspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horspeedType != null)
                {
                    //return ImmutableList.of(TAG_horspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerAligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horspeedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class verspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_verspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public verspeedType() : base()
            { 
                setMinSize(8);
                setMaxSize(8);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_verspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_verspeedType != null)
                {
                    //return ImmutableList.of(TAG_verspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new verspeedType from encoded stream.
             */
            public static verspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                verspeedType result = new verspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new verspeedType from encoded stream.
             */
            public static verspeedType fromPerAligned(byte[] encodedBytes)
            {
                verspeedType result = new verspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "verspeedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class horuncertspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_horuncertspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public horuncertspeedType() : base()
            { 
                setMinSize(8);
                setMaxSize(8);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_horuncertspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horuncertspeedType != null)
                {
                    //return ImmutableList.of(TAG_horuncertspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horuncertspeedType from encoded stream.
             */
            public static horuncertspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                horuncertspeedType result = new horuncertspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horuncertspeedType from encoded stream.
             */
            public static horuncertspeedType fromPerAligned(byte[] encodedBytes)
            {
                horuncertspeedType result = new horuncertspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horuncertspeedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class veruncertspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_veruncertspeedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public veruncertspeedType() : base()
            { 
                setMinSize(8);
                setMaxSize(8);

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_veruncertspeedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_veruncertspeedType != null)
                {
                    //return ImmutableList.of(TAG_veruncertspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new veruncertspeedType from encoded stream.
             */
            public static veruncertspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                veruncertspeedType result = new veruncertspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new veruncertspeedType from encoded stream.
             */
            public static veruncertspeedType fromPerAligned(byte[] encodedBytes)
            {
                veruncertspeedType result = new veruncertspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "veruncertspeedType = " + getValue() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}