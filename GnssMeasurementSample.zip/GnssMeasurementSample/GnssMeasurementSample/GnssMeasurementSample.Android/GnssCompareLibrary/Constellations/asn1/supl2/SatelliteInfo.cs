﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Java.Nio;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SatelliteInfo : Asn1SequenceOf<SatelliteInfoElement>
    {


        private static readonly Asn1Tag TAG_SatelliteInfo = Asn1Tag.fromClassAndNumber(-1, -1);

        public SatelliteInfo() : base()
        { 
            setMinSize(1);
            setMaxSize(31);

        }

        override public Asn1Tag getTag()
        {
            return TAG_SatelliteInfo;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SatelliteInfo != null)
            {
                //return ImmutableList.of(TAG_SatelliteInfo);
                return Asn1SequenceOf<SatelliteInfo>.getPossibleFirstTags();
            }
            else
            {
                return Asn1SequenceOf<SatelliteInfo>.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new SatelliteInfo from encoded stream.
         */
        public static SatelliteInfo fromPerUnaligned(byte[] encodedBytes)
        {
            SatelliteInfo result = new SatelliteInfo();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SatelliteInfo from encoded stream.
         */
        public static SatelliteInfo fromPerAligned(byte[] encodedBytes)
        {
            SatelliteInfo result = new SatelliteInfo();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        override public SatelliteInfoElement createAndAddValue()
        {
            SatelliteInfoElement value = new SatelliteInfoElement();
            add(value);
            return value;
        }


        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}