﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PosPayLoad : Asn1Choice
    {
        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override Asn1Object getValue()
        {
            throw new NotImplementedException();
        }

        protected override Asn1Object createAndSetValue(bool isExtensionValue, int ordinal)
        {
            throw new NotImplementedException();
        }

        protected override ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            throw new NotImplementedException();
        }

        protected override int getOptionCount()
        {
            throw new NotImplementedException();
        }

        protected override ChoiceComponent getSelectedComponent()
        {
            throw new NotImplementedException();
        }

        protected override int getSelectionOrdinal()
        {
            throw new NotImplementedException();
        }

        protected override bool hasExtensionValue()
        {
            throw new NotImplementedException();
        }

        protected override bool isExtensible()
        {
            throw new NotImplementedException();
        }
    }
}