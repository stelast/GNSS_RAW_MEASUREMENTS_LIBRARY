﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class RequestedAssistData : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_RequestedAssistData = Asn1Tag.fromClassAndNumber(-1, -1);

        public RequestedAssistData() : base()
        {
        }

        override  public Asn1Tag getTag()
        {
            return TAG_RequestedAssistData;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_RequestedAssistData != null)
            {
                //return ImmutableList.of(TAG_RequestedAssistData);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new RequestedAssistData from encoded stream.
         */
        public static RequestedAssistData fromPerUnaligned(byte[] encodedBytes)
        {
            RequestedAssistData result = new RequestedAssistData();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new RequestedAssistData from encoded stream.
         */
        public static RequestedAssistData fromPerAligned(byte[] encodedBytes)
        {
            RequestedAssistData result = new RequestedAssistData();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }



        private RequestedAssistData.almanacRequestedType almanacRequested_;
        public RequestedAssistData.almanacRequestedType getAlmanacRequested()
        {
            return almanacRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.almanacRequestedType
         */
        public void setAlmanacRequested(Asn1Object value)
        {
            this.almanacRequested_ = (RequestedAssistData.almanacRequestedType)value;
        }
        public RequestedAssistData.almanacRequestedType setAlmanacRequestedToNewInstance()
        {
            almanacRequested_ = new RequestedAssistData.almanacRequestedType();
            return almanacRequested_;
        }

        private RequestedAssistData.utcModelRequestedType utcModelRequested_;
        public RequestedAssistData.utcModelRequestedType getUtcModelRequested()
        {
            return utcModelRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.utcModelRequestedType
         */
        public void setUtcModelRequested(Asn1Object value)
        {
            this.utcModelRequested_ = (RequestedAssistData.utcModelRequestedType)value;
        }
        public RequestedAssistData.utcModelRequestedType setUtcModelRequestedToNewInstance()
        {
            utcModelRequested_ = new RequestedAssistData.utcModelRequestedType();
            return utcModelRequested_;
        }

        private RequestedAssistData.ionosphericModelRequestedType ionosphericModelRequested_;
        public RequestedAssistData.ionosphericModelRequestedType getIonosphericModelRequested()
        {
            return ionosphericModelRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.ionosphericModelRequestedType
         */
        public void setIonosphericModelRequested(Asn1Object value)
        {
            this.ionosphericModelRequested_ = (RequestedAssistData.ionosphericModelRequestedType)value;
        }
        public RequestedAssistData.ionosphericModelRequestedType setIonosphericModelRequestedToNewInstance()
        {
            ionosphericModelRequested_ = new RequestedAssistData.ionosphericModelRequestedType();
            return ionosphericModelRequested_;
        }

        private RequestedAssistData.dgpsCorrectionsRequestedType dgpsCorrectionsRequested_;
        public RequestedAssistData.dgpsCorrectionsRequestedType getDgpsCorrectionsRequested()
        {
            return dgpsCorrectionsRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.dgpsCorrectionsRequestedType
         */
        public void setDgpsCorrectionsRequested(Asn1Object value)
        {
            this.dgpsCorrectionsRequested_ = (RequestedAssistData.dgpsCorrectionsRequestedType)value;
        }
        public RequestedAssistData.dgpsCorrectionsRequestedType setDgpsCorrectionsRequestedToNewInstance()
        {
            dgpsCorrectionsRequested_ = new RequestedAssistData.dgpsCorrectionsRequestedType();
            return dgpsCorrectionsRequested_;
        }

        private RequestedAssistData.referenceLocationRequestedType referenceLocationRequested_;
        public RequestedAssistData.referenceLocationRequestedType getReferenceLocationRequested()
        {
            return referenceLocationRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.referenceLocationRequestedType
         */
        public void setReferenceLocationRequested(Asn1Object value)
        {
            this.referenceLocationRequested_ = (RequestedAssistData.referenceLocationRequestedType)value;
        }
        public RequestedAssistData.referenceLocationRequestedType setReferenceLocationRequestedToNewInstance()
        {
            referenceLocationRequested_ = new RequestedAssistData.referenceLocationRequestedType();
            return referenceLocationRequested_;
        }

        private RequestedAssistData.referenceTimeRequestedType referenceTimeRequested_;
        public RequestedAssistData.referenceTimeRequestedType getReferenceTimeRequested()
        {
            return referenceTimeRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.referenceTimeRequestedType
         */
        public void setReferenceTimeRequested(Asn1Object value)
        {
            this.referenceTimeRequested_ = (RequestedAssistData.referenceTimeRequestedType)value;
        }
        public RequestedAssistData.referenceTimeRequestedType setReferenceTimeRequestedToNewInstance()
        {
            referenceTimeRequested_ = new RequestedAssistData.referenceTimeRequestedType();
            return referenceTimeRequested_;
        }

        private RequestedAssistData.acquisitionAssistanceRequestedType acquisitionAssistanceRequested_;
        public RequestedAssistData.acquisitionAssistanceRequestedType getAcquisitionAssistanceRequested()
        {
            return acquisitionAssistanceRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.acquisitionAssistanceRequestedType
         */
        public void setAcquisitionAssistanceRequested(Asn1Object value)
        {
            this.acquisitionAssistanceRequested_ = (RequestedAssistData.acquisitionAssistanceRequestedType)value;
        }
        public RequestedAssistData.acquisitionAssistanceRequestedType setAcquisitionAssistanceRequestedToNewInstance()
        {
            acquisitionAssistanceRequested_ = new RequestedAssistData.acquisitionAssistanceRequestedType();
            return acquisitionAssistanceRequested_;
        }

        private RequestedAssistData.realTimeIntegrityRequestedType realTimeIntegrityRequested_;
        public RequestedAssistData.realTimeIntegrityRequestedType getRealTimeIntegrityRequested()
        {
            return realTimeIntegrityRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.realTimeIntegrityRequestedType
         */
        public void setRealTimeIntegrityRequested(Asn1Object value)
        {
            this.realTimeIntegrityRequested_ = (RequestedAssistData.realTimeIntegrityRequestedType)value;
        }
        public RequestedAssistData.realTimeIntegrityRequestedType setRealTimeIntegrityRequestedToNewInstance()
        {
            realTimeIntegrityRequested_ = new RequestedAssistData.realTimeIntegrityRequestedType();
            return realTimeIntegrityRequested_;
        }

        private RequestedAssistData.navigationModelRequestedType navigationModelRequested_;
        public RequestedAssistData.navigationModelRequestedType getNavigationModelRequested()
        {
            return navigationModelRequested_;
        }
        /**
         * @throws ClassCastException if value is not a RequestedAssistData.navigationModelRequestedType
         */
        public void setNavigationModelRequested(Asn1Object value)
        {
            this.navigationModelRequested_ = (RequestedAssistData.navigationModelRequestedType)value;
        }
        public RequestedAssistData.navigationModelRequestedType setNavigationModelRequestedToNewInstance()
        {
            navigationModelRequested_ = new RequestedAssistData.navigationModelRequestedType();
            return navigationModelRequested_;
        }

        private NavigationModel navigationModelData_;
        public NavigationModel getNavigationModelData()
        {
            return navigationModelData_;
        }
        /**
         * @throws ClassCastException if value is not a NavigationModel
         */
        public void setNavigationModelData(Asn1Object value)
        {
            this.navigationModelData_ = (NavigationModel)value;
        }
        public NavigationModel setNavigationModelDataToNewInstance()
        {
            navigationModelData_ = new NavigationModel();
            return navigationModelData_;
        }



        private Ver2_RequestedAssistData_extension extensionVer2_RequestedAssistData_extension;
        public Ver2_RequestedAssistData_extension getExtensionVer2_RequestedAssistData_extension()
        {
            return extensionVer2_RequestedAssistData_extension;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_RequestedAssistData_extension
         */
        public void setExtensionVer2_RequestedAssistData_extension(Asn1Object value)
        {
            extensionVer2_RequestedAssistData_extension = (Ver2_RequestedAssistData_extension)value;
        }
        public void setExtensionVer2_RequestedAssistData_extensionToNewInstance()
        {
            extensionVer2_RequestedAssistData_extension = new Ver2_RequestedAssistData_extension();
        }


        /**
         * 
         */
        public class almanacRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_almanacRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public almanacRequestedType() : base()
            {
            }

            override

      public Asn1Tag getTag()
            {
                return TAG_almanacRequestedType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_almanacRequestedType != null)
                {
                    //return ImmutableList.of(TAG_almanacRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new almanacRequestedType from encoded stream.
             */
            public static almanacRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                almanacRequestedType result = new almanacRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new almanacRequestedType from encoded stream.
             */
            public static almanacRequestedType fromPerAligned(byte[] encodedBytes)
            {
                almanacRequestedType result = new almanacRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "almanacRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class utcModelRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_utcModelRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public utcModelRequestedType() : base()
            { 
            }

            override

          public Asn1Tag getTag()
            {
                return TAG_utcModelRequestedType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_utcModelRequestedType != null)
                {
                    //return ImmutableList.of(TAG_utcModelRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new utcModelRequestedType from encoded stream.
             */
            public static utcModelRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                utcModelRequestedType result = new utcModelRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new utcModelRequestedType from encoded stream.
             */
            public static utcModelRequestedType fromPerAligned(byte[] encodedBytes)
            {
                utcModelRequestedType result = new utcModelRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "utcModelRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ionosphericModelRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ionosphericModelRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ionosphericModelRequestedType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_ionosphericModelRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ionosphericModelRequestedType != null)
                {
                    //return ImmutableList.of(TAG_ionosphericModelRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ionosphericModelRequestedType from encoded stream.
             */
            public static ionosphericModelRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                ionosphericModelRequestedType result = new ionosphericModelRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ionosphericModelRequestedType from encoded stream.
             */
            public static ionosphericModelRequestedType fromPerAligned(byte[] encodedBytes)
            {
                ionosphericModelRequestedType result = new ionosphericModelRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ionosphericModelRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class dgpsCorrectionsRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_dgpsCorrectionsRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public dgpsCorrectionsRequestedType() : base()
            { 
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_dgpsCorrectionsRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_dgpsCorrectionsRequestedType != null)
                {
                    //return ImmutableList.of(TAG_dgpsCorrectionsRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new dgpsCorrectionsRequestedType from encoded stream.
             */
            public static dgpsCorrectionsRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                dgpsCorrectionsRequestedType result = new dgpsCorrectionsRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new dgpsCorrectionsRequestedType from encoded stream.
             */
            public static dgpsCorrectionsRequestedType fromPerAligned(byte[] encodedBytes)
            {
                dgpsCorrectionsRequestedType result = new dgpsCorrectionsRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "dgpsCorrectionsRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class referenceLocationRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_referenceLocationRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public referenceLocationRequestedType() : base()
            { 
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_referenceLocationRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_referenceLocationRequestedType != null)
                {
                    //return ImmutableList.of(TAG_referenceLocationRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new referenceLocationRequestedType from encoded stream.
             */
            public static referenceLocationRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                referenceLocationRequestedType result = new referenceLocationRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new referenceLocationRequestedType from encoded stream.
             */
            public static referenceLocationRequestedType fromPerAligned(byte[] encodedBytes)
            {
                referenceLocationRequestedType result = new referenceLocationRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "referenceLocationRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class referenceTimeRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_referenceTimeRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public referenceTimeRequestedType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_referenceTimeRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_referenceTimeRequestedType != null)
                {
                    //return ImmutableList.of(TAG_referenceTimeRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new referenceTimeRequestedType from encoded stream.
             */
            public static referenceTimeRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                referenceTimeRequestedType result = new referenceTimeRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new referenceTimeRequestedType from encoded stream.
             */
            public static referenceTimeRequestedType fromPerAligned(byte[] encodedBytes)
            {
                referenceTimeRequestedType result = new referenceTimeRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "referenceTimeRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class acquisitionAssistanceRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_acquisitionAssistanceRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public acquisitionAssistanceRequestedType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_acquisitionAssistanceRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_acquisitionAssistanceRequestedType != null)
                {
                    //return ImmutableList.of(TAG_acquisitionAssistanceRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new acquisitionAssistanceRequestedType from encoded stream.
             */
            public static acquisitionAssistanceRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                acquisitionAssistanceRequestedType result = new acquisitionAssistanceRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new acquisitionAssistanceRequestedType from encoded stream.
             */
            public static acquisitionAssistanceRequestedType fromPerAligned(byte[] encodedBytes)
            {
                acquisitionAssistanceRequestedType result = new acquisitionAssistanceRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "acquisitionAssistanceRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class realTimeIntegrityRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_realTimeIntegrityRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public realTimeIntegrityRequestedType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_realTimeIntegrityRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_realTimeIntegrityRequestedType != null)
                {
                    //return ImmutableList.of(TAG_realTimeIntegrityRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new realTimeIntegrityRequestedType from encoded stream.
             */
            public static realTimeIntegrityRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                realTimeIntegrityRequestedType result = new realTimeIntegrityRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new realTimeIntegrityRequestedType from encoded stream.
             */
            public static realTimeIntegrityRequestedType fromPerAligned(byte[] encodedBytes)
            {
                realTimeIntegrityRequestedType result = new realTimeIntegrityRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "realTimeIntegrityRequestedType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class navigationModelRequestedType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_navigationModelRequestedType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public navigationModelRequestedType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_navigationModelRequestedType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_navigationModelRequestedType != null)
                {
                    //return ImmutableList.of(TAG_navigationModelRequestedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new navigationModelRequestedType from encoded stream.
             */
            public static navigationModelRequestedType fromPerUnaligned(byte[] encodedBytes)
            {
                navigationModelRequestedType result = new navigationModelRequestedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new navigationModelRequestedType from encoded stream.
             */
            public static navigationModelRequestedType fromPerAligned(byte[] encodedBytes)
            {
                navigationModelRequestedType result = new navigationModelRequestedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "navigationModelRequestedType = " + getValue() + ";\n";
            }
        }









        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}