﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SatellitesListRelatedData : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_SatellitesListRelatedData = Asn1Tag.fromClassAndNumber(-1, -1);

        public SatellitesListRelatedData() : base()
        {
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }
        private SatellitesListRelatedData.satIdType satId_;
        public SatellitesListRelatedData.satIdType getSatId()
        {
            return satId_;
        }
        /**
         * @throws ClassCastException if value is not a SatellitesListRelatedData.satIdType
         */
        public void setSatId(Asn1Object value)
        {
            this.satId_ = (SatellitesListRelatedData.satIdType)value;
        }
        public SatellitesListRelatedData.satIdType setSatIdToNewInstance()
        {
            satId_ = new SatellitesListRelatedData.satIdType();
            return satId_;
        }

        private SatellitesListRelatedData.iodType iod_;
        public SatellitesListRelatedData.iodType getIod()
        {
            return iod_;
        }
        /**
         * @throws ClassCastException if value is not a SatellitesListRelatedData.iodType
         */
        public void setIod(Asn1Object value)
        {
            this.iod_ = (SatellitesListRelatedData.iodType)value;
        }
        public SatellitesListRelatedData.iodType setIodToNewInstance()
        {
            iod_ = new SatellitesListRelatedData.iodType();
            return iod_;
        }

        /**
         * 
         */
        public class satIdType : Asn1Integer
        {
  //

            private static readonly Asn1Tag TAG_satIdType = Asn1Tag.fromClassAndNumber(-1, -1);

            public satIdType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("63"));

            }

            override public Asn1Tag getTag()
            {
                return TAG_satIdType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_satIdType != null)
                {
                        //return ImmutableList.of(TAG_satIdType);
                        return Asn1Integer.getPossibleFirstTags();
                    }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new satIdType from encoded stream.
             */
            public static satIdType fromPerUnaligned(byte[] encodedBytes)
            {
                satIdType result = new satIdType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new satIdType from encoded stream.
             */
            public static satIdType fromPerAligned(byte[] encodedBytes)
            {
                satIdType result = new satIdType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "satIdType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class iodType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_iodType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public iodType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("1023"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_iodType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_iodType != null)
                {
                    //return ImmutableList.of(TAG_iodType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new iodType from encoded stream.
             */
            public static iodType fromPerUnaligned(byte[] encodedBytes)
            {
                iodType result = new iodType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new iodType from encoded stream.
             */
            public static iodType fromPerAligned(byte[] encodedBytes)
            {
                iodType result = new iodType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "iodType = " + getInteger() + ";\n";
            }
        }





        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        //public String toIndentedString(String indent)
        //{
        //    StringBuilder builder = new StringBuilder();
        //    builder.append("SatellitesListRelatedData = {\n");
        //    String internalIndent = indent + "  ";
        //    for (SequenceComponent component : getComponents())
        //    {
        //        if (component.isExplicitlySet())
        //        {
        //            builder.append(internalIndent)
        //                .append(component.toIndentedString(internalIndent));
        //        }
        //    }
        //    if (isExtensible())
        //    {
        //        builder.append(internalIndent).append("...\n");
        //        for (SequenceComponent component : getExtensionComponents())
        //        {
        //            if (component.isExplicitlySet())
        //            {
        //                builder.append(internalIndent)
        //                    .append(component.toIndentedString(internalIndent));
        //            }
        //        }
        //    }
        //    builder.append(indent).append("};\n");
        //    return builder.toString();
        //}






    }
}