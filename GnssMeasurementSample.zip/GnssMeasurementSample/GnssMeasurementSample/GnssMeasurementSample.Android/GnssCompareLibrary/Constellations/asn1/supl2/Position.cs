﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Position : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Position = Asn1Tag.fromClassAndNumber(-1, -1);

        public Position() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_Position;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Position != null)
            {
                //return ImmutableList.of(TAG_Position);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Position from encoded stream.
         */
        public static Position fromPerUnaligned(byte[] encodedBytes)
        {
            Position result = new Position();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Position from encoded stream.
         */
        public static Position fromPerAligned(byte[] encodedBytes)
        {
            Position result = new Position();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private Position.timestampType timestamp_;
        public Position.timestampType getTimestamp()
        {
            return timestamp_;
        }
        /**
         * @throws ClassCastException if value is not a Position.timestampType
         */
        public void setTimestamp(Asn1Object value)
        {
            this.timestamp_ = (Position.timestampType)value;
        }
        public Position.timestampType setTimestampToNewInstance()
        {
            timestamp_ = new Position.timestampType();
            return timestamp_;
        }

        private PositionEstimate positionEstimate_;
        public PositionEstimate getPositionEstimate()
        {
            return positionEstimate_;
        }
        /**
         * @throws ClassCastException if value is not a PositionEstimate
         */
        public void setPositionEstimate(Asn1Object value)
        {
            this.positionEstimate_ = (PositionEstimate)value;
        }
        public PositionEstimate setPositionEstimateToNewInstance()
        {
            positionEstimate_ = new PositionEstimate();
            return positionEstimate_;
        }

        private Velocity velocity_;
        public Velocity getVelocity()
        {
            return velocity_;
        }
        /**
         * @throws ClassCastException if value is not a Velocity
         */
        public void setVelocity(Asn1Object value)
        {
            this.velocity_ = (Velocity)value;
        }
        public Velocity setVelocityToNewInstance()
        {
            velocity_ = new Velocity();
            return velocity_;
        }

        /**
         * 
         */
        public class timestampType : Asn1UTCTime
        {
            //

            private static readonly Asn1Tag TAG_timestampType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public timestampType() : base()
            {
            }

            override public Asn1Tag getTag()
            {
                return TAG_timestampType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_timestampType != null)
                {
                    //return ImmutableList.of(TAG_timestampType);
                    return Asn1UTCTime.getPossibleFirstTags();
                }
                else
                {
                    return Asn1UTCTime.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new timestampType from encoded stream.
             */
            public static timestampType fromPerUnaligned(byte[] encodedBytes)
            {
                timestampType result = new timestampType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new timestampType from encoded stream.
             */
            public static timestampType fromPerAligned(byte[] encodedBytes)
            {
                timestampType result = new timestampType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "timestampType = [ " + /*toHumanReadableString() + */" ];\n";
            }

        } 



    //    override public Iterable<BitStream> encodePerUnaligned()
    //{
    //    return base.encodePerUnaligned();
    //}

    //override public Iterable<BitStream> encodePerAligned()
    //{
    //    return base.encodePerAligned();
    //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}