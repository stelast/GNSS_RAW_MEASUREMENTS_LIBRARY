﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Ver2_PosProtocol_extension : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_Ver2_PosProtocol_extension
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Ver2_PosProtocol_extension() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_Ver2_PosProtocol_extension;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Ver2_PosProtocol_extension != null)
            {
                //return ImmutableList.of(TAG_Ver2_PosProtocol_extension);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Ver2_PosProtocol_extension from encoded stream.
         */
        public static Ver2_PosProtocol_extension fromPerUnaligned(byte[] encodedBytes)
        {
            Ver2_PosProtocol_extension result = new Ver2_PosProtocol_extension();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Ver2_PosProtocol_extension from encoded stream.
         */
        public static Ver2_PosProtocol_extension fromPerAligned(byte[] encodedBytes)
        {
            Ver2_PosProtocol_extension result = new Ver2_PosProtocol_extension();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private Ver2_PosProtocol_extension.lppType lpp_;
        public Ver2_PosProtocol_extension.lppType getLpp()
        {
            return lpp_;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_PosProtocol_extension.lppType
         */
        public void setLpp(Asn1Object value)
        {
            this.lpp_ = (Ver2_PosProtocol_extension.lppType)value;
        }
        public Ver2_PosProtocol_extension.lppType setLppToNewInstance()
        {
            lpp_ = new Ver2_PosProtocol_extension.lppType();
            return lpp_;
        }

        private PosProtocolVersion3GPP posProtocolVersionRRLP_;
        public PosProtocolVersion3GPP getPosProtocolVersionRRLP()
        {
            return posProtocolVersionRRLP_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocolVersion3GPP
         */
        public void setPosProtocolVersionRRLP(Asn1Object value)
        {
            this.posProtocolVersionRRLP_ = (PosProtocolVersion3GPP)value;
        }
        public PosProtocolVersion3GPP setPosProtocolVersionRRLPToNewInstance()
        {
            posProtocolVersionRRLP_ = new PosProtocolVersion3GPP();
            return posProtocolVersionRRLP_;
        }

        //private PosProtocolVersion3GPP posProtocolVersionRRC_;
        //public PosProtocolVersion3GPP getPosProtocolVersionRRC()
        //{
        //    return posProtocolVersionRRC_;
        //}
        ///**
        // * @throws ClassCastException if value is not a PosProtocolVersion3GPP
        // */
        //public void setPosProtocolVersionRRC(Asn1Object value)
        //{
        //    this.posProtocolVersionRRC_ = (PosProtocolVersion3GPP)value;
        //}
        //public PosProtocolVersion3GPP setPosProtocolVersionRRCToNewInstance()
        //{
        //    posProtocolVersionRRC_ = new PosProtocolVersion3GPP();
        //    return posProtocolVersionRRC_;
        //}

        //private PosProtocolVersion3GPP2 posProtocolVersionTIA801_;
        //public PosProtocolVersion3GPP2 getPosProtocolVersionTIA801()
        //{
        //    return posProtocolVersionTIA801_;
        //}
        ///**
        // * @throws ClassCastException if value is not a PosProtocolVersion3GPP2
        // */
        //public void setPosProtocolVersionTIA801(Asn1Object value)
        //{
        //    this.posProtocolVersionTIA801_ = (PosProtocolVersion3GPP2)value;
        //}
        //public PosProtocolVersion3GPP2 setPosProtocolVersionTIA801ToNewInstance()
        //{
        //    posProtocolVersionTIA801_ = new PosProtocolVersion3GPP2();
        //    return posProtocolVersionTIA801_;
        //}

        private PosProtocolVersion3GPP posProtocolVersionLPP_;
        public PosProtocolVersion3GPP getPosProtocolVersionLPP()
        {
            return posProtocolVersionLPP_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocolVersion3GPP
         */
        public void setPosProtocolVersionLPP(Asn1Object value)
        {
            this.posProtocolVersionLPP_ = (PosProtocolVersion3GPP)value;
        }
        public PosProtocolVersion3GPP setPosProtocolVersionLPPToNewInstance()
        {
            posProtocolVersionLPP_ = new PosProtocolVersion3GPP();
            return posProtocolVersionLPP_;
        }


        /**
         * 
         */
        public class lppType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_lppType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public lppType() : base()
            {
            }

            override

      public Asn1Tag getTag()
            {
                return TAG_lppType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_lppType != null)
                {
                    //return ImmutableList.of(TAG_lppType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new lppType from encoded stream.
             */
            public static lppType fromPerUnaligned(byte[] encodedBytes)
            {
                lppType result = new lppType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new lppType from encoded stream.
             */
            public static lppType fromPerAligned(byte[] encodedBytes)
            {
                lppType result = new lppType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "lppType = " + getValue() + ";\n";
            }
        }













        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}