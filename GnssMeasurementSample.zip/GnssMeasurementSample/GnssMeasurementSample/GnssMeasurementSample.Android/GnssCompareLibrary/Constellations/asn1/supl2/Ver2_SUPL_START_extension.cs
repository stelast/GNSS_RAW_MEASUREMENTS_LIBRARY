﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Ver2_SUPL_START_extension : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Ver2_SUPL_START_extension
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Ver2_SUPL_START_extension() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_Ver2_SUPL_START_extension;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Ver2_SUPL_START_extension != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_Ver2_SUPL_START_extension);
                return builder.ToImmutable();
            }
            else
            {
                return Asn1Integer.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Ver2_SUPL_START_extension from encoded stream.
         */
        public static Ver2_SUPL_START_extension fromPerUnaligned(byte[] encodedBytes)
        {
            Ver2_SUPL_START_extension result = new Ver2_SUPL_START_extension();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Ver2_SUPL_START_extension from encoded stream.
         */
        public static Ver2_SUPL_START_extension fromPerAligned(byte[] encodedBytes)
        {
            Ver2_SUPL_START_extension result = new Ver2_SUPL_START_extension();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override bool isExtensible()
        {
            return true;
        }

        //private MultipleLocationIds multipleLocationIds_;
        //public MultipleLocationIds getMultipleLocationIds()
        //{
        //    return multipleLocationIds_;
        //}
        ///**
        // * @throws ClassCastException if value is not a MultipleLocationIds
        // */
        //public void setMultipleLocationIds(Asn1Object value)
        //{
        //    this.multipleLocationIds_ = (MultipleLocationIds)value;
        //}
        //public MultipleLocationIds setMultipleLocationIdsToNewInstance()
        //{
        //    multipleLocationIds_ = new MultipleLocationIds();
        //    return multipleLocationIds_;
        //}

        //private ThirdParty thirdParty_;
        //public ThirdParty getThirdParty()
        //{
        //    return thirdParty_;
        //}
        ///**
        // * @throws ClassCastException if value is not a ThirdParty
        // */
        //public void setThirdParty(Asn1Object value)
        //{
        //    this.thirdParty_ = (ThirdParty)value;
        //}
        //public ThirdParty setThirdPartyToNewInstance()
        //{
        //    thirdParty_ = new ThirdParty();
        //    return thirdParty_;
        //}

        //private ApplicationID applicationID_;
        //public ApplicationID getApplicationID()
        //{
        //    return applicationID_;
        //}
        ///**
        // * @throws ClassCastException if value is not a ApplicationID
        // */
        //public void setApplicationID(Asn1Object value)
        //{
        //    this.applicationID_ = (ApplicationID)value;
        //}
        //public ApplicationID setApplicationIDToNewInstance()
        //{
        //    applicationID_ = new ApplicationID();
        //    return applicationID_;
        //}

        private Position position_;
        public Position getPosition()
        {
            return position_;
        }
        /**
         * @throws ClassCastException if value is not a Position
         */
        public void setPosition(Asn1Object value)
        {
            this.position_ = (Position)value;
        }
        public Position setPositionToNewInstance()
        {
            position_ = new Position();
            return position_;
        }


        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }



    }
}