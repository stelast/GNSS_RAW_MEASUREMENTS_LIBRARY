﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class GanssRequestedGenericAssistanceDataList : Asn1SequenceOf<GanssReqGenericData>
    {

        private static readonly Asn1Tag TAG_GanssRequestedGenericAssistanceDataList = Asn1Tag.fromClassAndNumber(-1, -1);

        public GanssRequestedGenericAssistanceDataList() : base()
        {
            setMinSize(1);
            setMaxSize(16);
        }

        override public Asn1Tag getTag()
        {
            return TAG_GanssRequestedGenericAssistanceDataList;
        }

        override
        public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_GanssRequestedGenericAssistanceDataList != null)
            {
                //return ImmutableList.of(TAG_GanssRequestedGenericAssistanceDataList);
                return Asn1SequenceOf<GanssRequestedGenericAssistanceDataList>.getPossibleFirstTags();
            }
            else
            {
                return Asn1SequenceOf<GanssRequestedGenericAssistanceDataList>.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new GanssRequestedGenericAssistanceDataList from encoded stream.
         */
        public static GanssRequestedGenericAssistanceDataList fromPerUnaligned(byte[] encodedBytes)
        {
            GanssRequestedGenericAssistanceDataList result = new GanssRequestedGenericAssistanceDataList();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new GanssRequestedGenericAssistanceDataList from encoded stream.
         */
        public static GanssRequestedGenericAssistanceDataList fromPerAligned(byte[] encodedBytes)
        {
            GanssRequestedGenericAssistanceDataList result = new GanssRequestedGenericAssistanceDataList();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        override public GanssReqGenericData createAndAddValue()
        {
            GanssReqGenericData value = new GanssReqGenericData();
            add(value);
            return value;
        }



        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("GanssRequestedGenericAssistanceDataList = [\n");
            String internalIndent = indent + "  ";
            //for (GanssReqGenericData value : getValues())
            //{
            //    builder.Append(internalIndent)
            //        .Append(value.toIndentedString(internalIndent));
            //}
            builder.Append(indent).Append("];\n");
            return builder.ToString();
        }
         

        public override void decodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}