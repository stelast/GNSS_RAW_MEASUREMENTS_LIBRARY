﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Horvel : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_Horvel = Asn1Tag.fromClassAndNumber(-1, -1);

        public Horvel() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_Horvel;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Horvel != null)
            {
                //return ImmutableList.of(TAG_Horvel);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Horvel from encoded stream.
         */
        public static Horvel fromPerUnaligned(byte[] encodedBytes)
        {
            Horvel result = new Horvel();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Horvel from encoded stream.
         */
        public static Horvel fromPerAligned(byte[] encodedBytes)
        {
            Horvel result = new Horvel();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private Horvel.bearingType bearing_;
        public Horvel.bearingType getBearing()
        {
            return bearing_;
        }
        /**
         * @throws ClassCastException if value is not a Horvel.bearingType
         */
        public void setBearing(Asn1Object value)
        {
            this.bearing_ = (Horvel.bearingType)value;
        }
        public Horvel.bearingType setBearingToNewInstance()
        {
            bearing_ = new Horvel.bearingType();
            return bearing_;
        }

        private Horvel.horspeedType horspeed_;
        public Horvel.horspeedType getHorspeed()
        {
            return horspeed_;
        }
        /**
         * @throws ClassCastException if value is not a Horvel.horspeedType
         */
        public void setHorspeed(Asn1Object value)
        {
            this.horspeed_ = (Horvel.horspeedType)value;
        }
        public Horvel.horspeedType setHorspeedToNewInstance()
        {
            horspeed_ = new Horvel.horspeedType();
            return horspeed_;
        }

        /**
         * 
         */
        public class bearingType : Asn1BitString
        { 

            private static readonly Asn1Tag TAG_bearingType = Asn1Tag.fromClassAndNumber(-1, -1);

            public bearingType() : base()
            {
                setMinSize(9);
                setMaxSize(9);

            }

        override  public Asn1Tag getTag()
        {
            return TAG_bearingType;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_bearingType != null)
            {
                //return ImmutableList.of(TAG_bearingType);
                    return Asn1BitString.getPossibleFirstTags();
                }
            else
            {
                return Asn1BitString.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new bearingType from encoded stream.
         */
        public static bearingType fromPerUnaligned(byte[] encodedBytes)
        {
            bearingType result = new bearingType();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new bearingType from encoded stream.
         */
        public static bearingType fromPerAligned(byte[] encodedBytes)
        {
            bearingType result = new bearingType();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            return "bearingType = " + getValue() + ";\n";
        }
    }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class horspeedType : Asn1BitString
        {
            //

            // defined bit positions, if any


            // setters


            // clearers



            private static readonly Asn1Tag TAG_horspeedType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public horspeedType() : base()
            {
                setMinSize(16);
                setMaxSize(16);

            }

            override public Asn1Tag getTag()
            {
                return TAG_horspeedType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horspeedType != null)
                {
                    //return ImmutableList.of(TAG_horspeedType);
                    return Asn1BitString.getPossibleFirstTags();
                }
                else
                {
                    return Asn1BitString.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerUnaligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horspeedType from encoded stream.
             */
            public static horspeedType fromPerAligned(byte[] encodedBytes)
            {
                horspeedType result = new horspeedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horspeedType = " + getValue() + ";\n";
            }
        }





        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}