﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SETCapabilities : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_SETCapabilities = Asn1Tag.fromClassAndNumber(-1, -1);
         
        override public Asn1Tag getTag()
        {
            return TAG_SETCapabilities;
        }
         
        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_SETCapabilities != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_SETCapabilities);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new SETCapabilities from encoded stream.
         */
        public static SETCapabilities fromPerUnaligned(byte[] encodedBytes)
        {
            SETCapabilities result = new SETCapabilities();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new SETCapabilities from encoded stream.
         */
        public static SETCapabilities fromPerAligned(byte[] encodedBytes)
        {
            SETCapabilities result = new SETCapabilities();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        private PrefMethod prefMethod_;
        public PrefMethod getPrefMethod()
        {
            return prefMethod_;
        }
        /**
         * @throws ClassCastException if value is not a PrefMethod
         */
        public void setPrefMethod(Asn1Object value)
        {
            this.prefMethod_ = (PrefMethod)value;
        }
        public PrefMethod setPrefMethodToNewInstance()
        {
            prefMethod_ = new PrefMethod();
            return prefMethod_;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private PosTechnology posTechnology_;
        public PosTechnology getPosTechnology()
        {
            return posTechnology_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology
         */
        public void setPosTechnology(Asn1Object value)
        {
            this.posTechnology_ = (PosTechnology)value;
        }
        public PosTechnology setPosTechnologyToNewInstance()
        {
            posTechnology_ = new PosTechnology();
            return posTechnology_;
        }

        //private PrefMethod prefMethod_;
        //public PrefMethod getPrefMethod()
        //{
        //    return prefMethod_;
        //}
        ///**
        // * @throws ClassCastException if value is not a PrefMethod
        // */
        //public void setPrefMethod(Asn1Object value)
        //{
        //    this.prefMethod_ = (PrefMethod)value;
        //}
        //public PrefMethod setPrefMethodToNewInstance()
        //{
        //    prefMethod_ = new PrefMethod();
        //    return prefMethod_;
        //}

        private PosProtocol posProtocol_;
        public PosProtocol getPosProtocol()
        {
            return posProtocol_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocol
         */
        public void setPosProtocol(Asn1Object value)
        {
            this.posProtocol_ = (PosProtocol)value;
        }
        public PosProtocol setPosProtocolToNewInstance()
        {
            posProtocol_ = new PosProtocol();
            return posProtocol_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this));
            //builder.Add(new M4(this));
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            SETCapabilities objeto;
            public M1(SETCapabilities objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getPosTechnology();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getPosTechnology() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setPosTechnologyToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "posTechnology : "
                    + this.objeto.getPosTechnology().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            SETCapabilities objeto;
            public M2(SETCapabilities objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getPrefMethod();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PrefMethod.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getPrefMethod() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setPrefMethodToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "prefMethod : " + this.objeto.getPrefMethod().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            SETCapabilities objeto;
            public M3(SETCapabilities objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getPosProtocol();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosProtocol.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getPosProtocol() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setPosProtocolToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "posProtocol : " + this.objeto.getPosProtocol().toIndentedString(indent);
            }
        }
        //public class M4 : SequenceComponent
        //{
        //    Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
        //    SETCapabilities objeto;
        //    public M4(SETCapabilities objeto)
        //    {
        //        this.objeto = objeto;
        //    }
        //    public Asn1Object getComponentValue()
        //    {
        //        return this.objeto.getExtensionVer2_SETCapabilities_extension();
        //    }

        //    public ImmutableList<Asn1Tag> getPossibleFirstTags()
        //    {
        //        throw new UnsupportedOperationException(
        //            "BER decoding not supported for extension elements");
        //    }

        //    public Asn1Tag getTag()
        //    {
        //        throw new UnsupportedOperationException(
        //            "BER is not supported for extension elements");
        //    }

        //    public bool hasDefaultValue()
        //    {
        //        return false;
        //    }

        //    public bool isExplicitlySet()
        //    {
        //        return this.objeto.getExtensionVer2_SETCapabilities_extension() != null;
        //    }

        //    public bool isImplicitTagging()
        //    {
        //        throw new UnsupportedOperationException(
        //            "BER is not supported for extension elements");
        //    }

        //    public bool isOptional()
        //    {
        //        return true;
        //    }

        //    public void setToNewInstance()
        //    {
        //        this.objeto.setExtensionVer2_SETCapabilities_extensionToNewInstance();
        //    }

        //    public string toIndentedString(string indent)
        //    {
        //        return "ver2_SETCapabilities_extension : " + this.objeto.getExtensionVer2_SETCapabilities_extension().toIndentedString(indent);
        //    }
        //}



        //private Ver2_SETCapabilities_extension extensionVer2_SETCapabilities_extension;
        //public Ver2_SETCapabilities_extension getExtensionVer2_SETCapabilities_extension()
        //{
        //    return extensionVer2_SETCapabilities_extension;
        //}
        ///**
        // * @throws ClassCastException if value is not a Ver2_SETCapabilities_extension
        // */
        //public void setExtensionVer2_SETCapabilities_extension(Asn1Object value)
        //{
        //    extensionVer2_SETCapabilities_extension = (Ver2_SETCapabilities_extension)value;
        //}
        //public void setExtensionVer2_SETCapabilities_extensionToNewInstance()
        //{
        //    extensionVer2_SETCapabilities_extension = new Ver2_SETCapabilities_extension();
        //}


    }
}