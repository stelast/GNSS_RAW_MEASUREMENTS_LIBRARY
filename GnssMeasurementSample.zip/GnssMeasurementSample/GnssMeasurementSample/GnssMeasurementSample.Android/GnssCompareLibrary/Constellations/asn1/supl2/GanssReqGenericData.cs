﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class GanssReqGenericData : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_GanssReqGenericData
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public GanssReqGenericData() : base()
        {
        }
        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_GanssReqGenericData != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_GanssReqGenericData);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new GanssReqGenericData from encoded stream.
         */
        public static GanssReqGenericData fromPerAligned(byte[] encodedBytes)
        {
            GanssReqGenericData result = new GanssReqGenericData();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }
        /**
         * Creates a new GanssReqGenericData from encoded stream.
         */
        public static GanssReqGenericData fromPerUnaligned(byte[] encodedBytes)
        {
            GanssReqGenericData result = new GanssReqGenericData();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        private GanssReqGenericData.ganssIdType ganssId_;
        public GanssReqGenericData.ganssIdType getGanssId()
        {
            return ganssId_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssIdType
         */
        public void setGanssId(Asn1Object value)
        {
            this.ganssId_ = (GanssReqGenericData.ganssIdType)value;
        }
        public GanssReqGenericData.ganssIdType setGanssIdToNewInstance()
        {
            ganssId_ = new GanssReqGenericData.ganssIdType();
            return ganssId_;
        }

        private GanssReqGenericData.ganssRealTimeIntegrityType ganssRealTimeIntegrity_;
        public GanssReqGenericData.ganssRealTimeIntegrityType getGanssRealTimeIntegrity()
        {
            return ganssRealTimeIntegrity_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssRealTimeIntegrityType
         */
        public void setGanssRealTimeIntegrity(Asn1Object value)
        {
            this.ganssRealTimeIntegrity_ = (GanssReqGenericData.ganssRealTimeIntegrityType)value;
        }
        public GanssReqGenericData.ganssRealTimeIntegrityType setGanssRealTimeIntegrityToNewInstance()
        {
            ganssRealTimeIntegrity_ = new GanssReqGenericData.ganssRealTimeIntegrityType();
            return ganssRealTimeIntegrity_;
        }

        private GanssReqGenericData.ganssAlmanacType ganssAlmanac_;
        public GanssReqGenericData.ganssAlmanacType getGanssAlmanac()
        {
            return ganssAlmanac_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssAlmanacType
         */
        public void setGanssAlmanac(Asn1Object value)
        {
            this.ganssAlmanac_ = (GanssReqGenericData.ganssAlmanacType)value;
        }
        public GanssReqGenericData.ganssAlmanacType setGanssAlmanacToNewInstance()
        {
            ganssAlmanac_ = new GanssReqGenericData.ganssAlmanacType();
            return ganssAlmanac_;
        }

        private GanssReqGenericData.ganssUTCModelType ganssUTCModel_;
        public GanssReqGenericData.ganssUTCModelType getGanssUTCModel()
        {
            return ganssUTCModel_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssUTCModelType
         */
        public void setGanssUTCModel(Asn1Object value)
        {
            this.ganssUTCModel_ = (GanssReqGenericData.ganssUTCModelType)value;
        }
        public GanssReqGenericData.ganssUTCModelType setGanssUTCModelToNewInstance()
        {
            ganssUTCModel_ = new GanssReqGenericData.ganssUTCModelType();
            return ganssUTCModel_;
        }


        private GanssReqGenericData.ganssReferenceMeasurementInfoType ganssReferenceMeasurementInfo_;
        public GanssReqGenericData.ganssReferenceMeasurementInfoType getGanssReferenceMeasurementInfo()
        {
            return ganssReferenceMeasurementInfo_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssReferenceMeasurementInfoType
         */
        public void setGanssReferenceMeasurementInfo(Asn1Object value)
        {
            this.ganssReferenceMeasurementInfo_ = (GanssReqGenericData.ganssReferenceMeasurementInfoType)value;
        }
        public GanssReqGenericData.ganssReferenceMeasurementInfoType setGanssReferenceMeasurementInfoToNewInstance()
        {
            ganssReferenceMeasurementInfo_ = new GanssReqGenericData.ganssReferenceMeasurementInfoType();
            return ganssReferenceMeasurementInfo_;
        }

        private GanssReqGenericData.ganssAuxiliaryInformationType ganssAuxiliaryInformation_;
        public GanssReqGenericData.ganssAuxiliaryInformationType getGanssAuxiliaryInformation()
        {
            return ganssAuxiliaryInformation_;
        }
        /**
         * @throws ClassCastException if value is not a GanssReqGenericData.ganssAuxiliaryInformationType
         */
        public void setGanssAuxiliaryInformation(Asn1Object value)
        {
            this.ganssAuxiliaryInformation_ = (GanssReqGenericData.ganssAuxiliaryInformationType)value;
        }
        public GanssReqGenericData.ganssAuxiliaryInformationType setGanssAuxiliaryInformationToNewInstance()
        {
            ganssAuxiliaryInformation_ = new GanssReqGenericData.ganssAuxiliaryInformationType();
            return ganssAuxiliaryInformation_;
        }


        private GanssNavigationModelData ganssNavigationModelData_;
        public GanssNavigationModelData getGanssNavigationModelData()
        {
            return ganssNavigationModelData_;
        }
        /**
         * @throws ClassCastException if value is not a GanssNavigationModelData
         */
        public void setGanssNavigationModelData(Asn1Object value)
        {
            this.ganssNavigationModelData_ = (GanssNavigationModelData)value;
        }
        public GanssNavigationModelData setGanssNavigationModelDataToNewInstance()
        {
            ganssNavigationModelData_ = new GanssNavigationModelData();
            return ganssNavigationModelData_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }


        /**
         * 
         */
        public class ganssIdType : Asn1Integer
        { 

            private static readonly Asn1Tag TAG_ganssIdType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssIdType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("15"));
            }

            override public Asn1Tag getTag()
            {
                return TAG_ganssIdType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            //public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            //{
            //    if (TAG_ganssIdType != null)
            //    {
            //        return ImmutableList.of(TAG_ganssIdType);
            //    }
            //    else
            //    {
            //        return Asn1Integer.getPossibleFirstTags();
            //    }
            //}

            /**
             * Creates a new ganssIdType from encoded stream.
             */
            public static ganssIdType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssIdType result = new ganssIdType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssIdType from encoded stream.
             */
            public static ganssIdType fromPerAligned(byte[] encodedBytes)
            {
                ganssIdType result = new ganssIdType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssIdType = " + getInteger() + ";\n";
            }
        }

        /**
         * 
         */
        public class ganssRealTimeIntegrityType : Asn1Boolean
        {
            private static readonly Asn1Tag TAG_ganssRealTimeIntegrityType = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssRealTimeIntegrityType() : base()
            {
            }

            override public Asn1Tag getTag()
            {
                return TAG_ganssRealTimeIntegrityType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssRealTimeIntegrityType != null)
                {
                    return Asn1Boolean.getPossibleFirstTags();
                    //return ImmutableList.of(TAG_ganssRealTimeIntegrityType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssRealTimeIntegrityType from encoded stream.
             */
            public static ganssRealTimeIntegrityType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssRealTimeIntegrityType result = new ganssRealTimeIntegrityType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssRealTimeIntegrityType from encoded stream.
             */
            public static ganssRealTimeIntegrityType fromPerAligned(byte[] encodedBytes)
            {
                ganssRealTimeIntegrityType result = new ganssRealTimeIntegrityType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            // public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return super.encodePerUnaligned();
            //}

            // public Iterable<BitStream> encodePerAligned()
            //{
            //    return super.encodePerAligned();
            //}

            public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssRealTimeIntegrityType = " + getValue() + ";\n";
            }
        }

        /**
         * 
         */
        public class ganssAlmanacType : Asn1Boolean
        {
      //

            private static readonly Asn1Tag TAG_ganssAlmanacType  = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssAlmanacType() : base()
            {
            } 
        
            public Asn1Tag getTag()
            {
                return TAG_ganssAlmanacType;
            }

        
            public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssAlmanacType != null)
                {
                    return Asn1Boolean.getPossibleFirstTags();
                    //return ImmutableList.of(TAG_ganssAlmanacType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssAlmanacType from encoded stream.
             */
            public static ganssAlmanacType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssAlmanacType result = new ganssAlmanacType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssAlmanacType from encoded stream.
             */
            public static ganssAlmanacType fromPerAligned(byte[] encodedBytes)
            {
                ganssAlmanacType result = new ganssAlmanacType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            // public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return super.encodePerUnaligned();
            //}

            // public Iterable<BitStream> encodePerAligned()
            //{
            //    return super.encodePerAligned();
            //}

            public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

             public void decodePerAligned(BitStreamReader reader)
            {
                    base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssAlmanacType = " + getValue() + ";\n";
            }
        }

        /**
         * 
         */
        public class ganssUTCModelType : Asn1Boolean
        { 
              
            private static readonly Asn1Tag TAG_ganssUTCModelType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssUTCModelType() : base()
            { 
            } 
        
            public Asn1Tag getTag()
            {
                return TAG_ganssUTCModelType;
            }

        
            public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssUTCModelType != null)
                {
                    return Asn1Boolean.getPossibleFirstTags();
                    //return ImmutableList.of(TAG_ganssUTCModelType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

        /**
         * Creates a new ganssUTCModelType from encoded stream.
         */
        public static ganssUTCModelType fromPerUnaligned(byte[] encodedBytes)
        {
            ganssUTCModelType result = new ganssUTCModelType();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new ganssUTCModelType from encoded stream.
         */
        public static ganssUTCModelType fromPerAligned(byte[] encodedBytes)
        {
            ganssUTCModelType result = new ganssUTCModelType();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        // public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return super.encodePerUnaligned();
        //}

        // public Iterable<BitStream> encodePerAligned()
        //{
        //    return super.encodePerAligned();
        //}

         public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

         public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

         public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            return "ganssUTCModelType = " + getValue() + ";\n";
        }
    }

    /**
     * 
     */
    public class ganssAuxiliaryInformationType : Asn1Boolean
    {
          //

          private static readonly Asn1Tag TAG_ganssAuxiliaryInformationType = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssAuxiliaryInformationType() : base()
            { 
            } 
    
            public Asn1Tag getTag()
            {
                return TAG_ganssAuxiliaryInformationType;
            }
    
            public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssAuxiliaryInformationType != null)
                {
                        //return ImmutableList.of(TAG_ganssAuxiliaryInformationType);
                        return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssAuxiliaryInformationType from encoded stream.
             */
            public static ganssAuxiliaryInformationType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssAuxiliaryInformationType result = new ganssAuxiliaryInformationType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssAuxiliaryInformationType from encoded stream.
             */
            public static ganssAuxiliaryInformationType fromPerAligned(byte[] encodedBytes)
            {
                ganssAuxiliaryInformationType result = new ganssAuxiliaryInformationType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            // public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return super.encodePerUnaligned();
            //}

            // public Iterable<BitStream> encodePerAligned()
            //{
            //    return super.encodePerAligned();
            //}

             public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

             public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

             public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssAuxiliaryInformationType = " + getValue() + ";\n";
            }
        }


        /**
         * 
         */
        public  class ganssReferenceMeasurementInfoType : Asn1Boolean
        {
              //

              private static readonly Asn1Tag TAG_ganssReferenceMeasurementInfoType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssReferenceMeasurementInfoType() : base()
            { 
            }

            override
            public Asn1Tag getTag()
            {
                return TAG_ganssReferenceMeasurementInfoType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssReferenceMeasurementInfoType != null)
                    {
                        return Asn1Boolean.getPossibleFirstTags();
                        //return ImmutableList.of(TAG_ganssReferenceMeasurementInfoType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssReferenceMeasurementInfoType from encoded stream.
             */
            public static ganssReferenceMeasurementInfoType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssReferenceMeasurementInfoType result = new ganssReferenceMeasurementInfoType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssReferenceMeasurementInfoType from encoded stream.
             */
            public static ganssReferenceMeasurementInfoType fromPerAligned(byte[] encodedBytes)
            {
                ganssReferenceMeasurementInfoType result = new ganssReferenceMeasurementInfoType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return super.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return super.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                    base.decodePerAligned(reader);
            }

             public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssReferenceMeasurementInfoType = " + getValue() + ";\n";
            }
        }

         









    }
}