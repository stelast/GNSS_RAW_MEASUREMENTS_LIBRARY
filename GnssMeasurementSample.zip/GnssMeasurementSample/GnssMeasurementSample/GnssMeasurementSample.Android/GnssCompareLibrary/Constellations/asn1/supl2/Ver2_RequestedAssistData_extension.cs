﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Ver2_RequestedAssistData_extension : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Ver2_RequestedAssistData_extension = Asn1Tag.fromClassAndNumber(-1, -1);

        public Ver2_RequestedAssistData_extension() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_Ver2_RequestedAssistData_extension;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Ver2_RequestedAssistData_extension != null)
            {
                //return ImmutableList.of(TAG_Ver2_RequestedAssistData_extension);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Ver2_RequestedAssistData_extension from encoded stream.
         */
        public static Ver2_RequestedAssistData_extension fromPerUnaligned(byte[] encodedBytes)
        {
            Ver2_RequestedAssistData_extension result = new Ver2_RequestedAssistData_extension();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Ver2_RequestedAssistData_extension from encoded stream.
         */
        public static Ver2_RequestedAssistData_extension fromPerAligned(byte[] encodedBytes)
        {
            Ver2_RequestedAssistData_extension result = new Ver2_RequestedAssistData_extension();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private GanssRequestedCommonAssistanceDataList ganssRequestedCommonAssistanceDataList_;
        public GanssRequestedCommonAssistanceDataList getGanssRequestedCommonAssistanceDataList()
        {
            return ganssRequestedCommonAssistanceDataList_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList
         */
        public void setGanssRequestedCommonAssistanceDataList(Asn1Object value)
        {
            this.ganssRequestedCommonAssistanceDataList_ = (GanssRequestedCommonAssistanceDataList)value;
        }
        public GanssRequestedCommonAssistanceDataList setGanssRequestedCommonAssistanceDataListToNewInstance()
        {
            ganssRequestedCommonAssistanceDataList_ = new GanssRequestedCommonAssistanceDataList();
            return ganssRequestedCommonAssistanceDataList_;
        }

        private GanssRequestedGenericAssistanceDataList ganssRequestedGenericAssistanceDataList_;
        public GanssRequestedGenericAssistanceDataList getGanssRequestedGenericAssistanceDataList()
        {
            return ganssRequestedGenericAssistanceDataList_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedGenericAssistanceDataList
         */
        public void setGanssRequestedGenericAssistanceDataList(Asn1Object value)
        {
            this.ganssRequestedGenericAssistanceDataList_ = (GanssRequestedGenericAssistanceDataList)value;
        }
        public GanssRequestedGenericAssistanceDataList setGanssRequestedGenericAssistanceDataListToNewInstance()
        {
            ganssRequestedGenericAssistanceDataList_ = new GanssRequestedGenericAssistanceDataList();
            return ganssRequestedGenericAssistanceDataList_;
        }

        //private ExtendedEphemeris extendedEphemeris_;
        //public ExtendedEphemeris getExtendedEphemeris()
        //{
        //    return extendedEphemeris_;
        //}
        ///**
        // * @throws ClassCastException if value is not a ExtendedEphemeris
        // */
        //public void setExtendedEphemeris(Asn1Object value)
        //{
        //    this.extendedEphemeris_ = (ExtendedEphemeris)value;
        //}
        //public ExtendedEphemeris setExtendedEphemerisToNewInstance()
        //{
        //    extendedEphemeris_ = new ExtendedEphemeris();
        //    return extendedEphemeris_;
        //}

        //private ExtendedEphCheck extendedEphemerisCheck_;
        //public ExtendedEphCheck getExtendedEphemerisCheck()
        //{
        //    return extendedEphemerisCheck_;
        //}
        ///**
        // * @throws ClassCastException if value is not a ExtendedEphCheck
        // */
        //public void setExtendedEphemerisCheck(Asn1Object value)
        //{
        //    this.extendedEphemerisCheck_ = (ExtendedEphCheck)value;
        //}
        //public ExtendedEphCheck setExtendedEphemerisCheckToNewInstance()
        //{
        //    extendedEphemerisCheck_ = new ExtendedEphCheck();
        //    return extendedEphemerisCheck_;
        //}



        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}