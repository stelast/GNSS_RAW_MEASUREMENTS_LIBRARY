﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class QoP : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_QoP = Asn1Tag.fromClassAndNumber(-1, -1);

        public QoP() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_QoP;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_QoP != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_QoP);
                return builder.ToImmutable();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new QoP from encoded stream.
         */
        public static QoP fromPerUnaligned(byte[] encodedBytes)
        {
            QoP result = new QoP();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new QoP from encoded stream.
         */
        public static QoP fromPerAligned(byte[] encodedBytes)
        {
            QoP result = new QoP();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this));
            builder.Add(new M4(this));
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            QoP objeto;
            public M1(QoP objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getHoracc();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return QoP.horaccType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getHoracc() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return true;
            }

            public void setToNewInstance()
            {
                this.objeto.setHoraccToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getHoracc().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            QoP objeto;
            public M2(QoP objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getVeracc();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return QoP.veraccType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getVeracc() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return true;
            }

            public void setToNewInstance()
            {
                this.objeto.setVeraccToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getVeracc().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            QoP objeto;
            public M3(QoP objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getMaxLocAge();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return QoP.maxLocAgeType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getMaxLocAge() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setMaxLocAgeToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getMaxLocAge().toIndentedString(indent);
            }
        }
        public class M4 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
            QoP objeto;
            public M4(QoP objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getDelay();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return QoP.delayType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getDelay() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setDelayToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "length : " + this.objeto.getDelay().toIndentedString(indent);
            }
        }


        protected override bool isExtensible()
        {
            return true;
        }


        private QoP.horaccType horacc_;
        public QoP.horaccType getHoracc()
        {
            return horacc_;
        }
        /**
         * @throws ClassCastException if value is not a QoP.horaccType
         */
        public void setHoracc(Asn1Object value)
        {
            this.horacc_ = (QoP.horaccType)value;
        }
        public QoP.horaccType setHoraccToNewInstance()
        {
            horacc_ = new QoP.horaccType();
            return horacc_;
        }

        private QoP.veraccType veracc_;
        public QoP.veraccType getVeracc()
        {
            return veracc_;
        }
        /**
         * @throws ClassCastException if value is not a QoP.veraccType
         */
        public void setVeracc(Asn1Object value)
        {
            this.veracc_ = (QoP.veraccType)value;
        }
        public QoP.veraccType setVeraccToNewInstance()
        {
            veracc_ = new QoP.veraccType();
            return veracc_;
        }

        private QoP.maxLocAgeType maxLocAge_;
        public QoP.maxLocAgeType getMaxLocAge()
        {
            return maxLocAge_;
        }
        /**
         * @throws ClassCastException if value is not a QoP.maxLocAgeType
         */
        public void setMaxLocAge(Asn1Object value)
        {
            this.maxLocAge_ = (QoP.maxLocAgeType)value;
        }
        public QoP.maxLocAgeType setMaxLocAgeToNewInstance()
        {
            maxLocAge_ = new QoP.maxLocAgeType();
            return maxLocAge_;
        }

        private QoP.delayType delay_;
        public QoP.delayType getDelay()
        {
            return delay_;
        }
        /**
         * @throws ClassCastException if value is not a QoP.delayType
         */
        public void setDelay(Asn1Object value)
        {
            this.delay_ = (QoP.delayType)value;
        }
        public QoP.delayType setDelayToNewInstance()
        {
            delay_ = new QoP.delayType();
            return delay_;
        }


        /**
         * 
         */
        public class horaccType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_horaccType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public horaccType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("127"));

            }

            override
            
  public Asn1Tag getTag()
            {
                return TAG_horaccType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_horaccType != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_horaccType);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new horaccType from encoded stream.
             */
            public static horaccType fromPerUnaligned(byte[] encodedBytes)
            {
                horaccType result = new horaccType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new horaccType from encoded stream.
             */
            public static horaccType fromPerAligned(byte[] encodedBytes)
            {
                horaccType result = new horaccType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "horaccType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class veraccType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_veraccType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public veraccType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("127"));

            }

            override
            
      public Asn1Tag getTag()
            {
                return TAG_veraccType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_veraccType != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_veraccType);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new veraccType from encoded stream.
             */
            public static veraccType fromPerUnaligned(byte[] encodedBytes)
            {
                veraccType result = new veraccType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new veraccType from encoded stream.
             */
            public static veraccType fromPerAligned(byte[] encodedBytes)
            {
                veraccType result = new veraccType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "veraccType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class maxLocAgeType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_maxLocAgeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public maxLocAgeType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("65535"));

            }

            override
            
          public Asn1Tag getTag()
            {
                return TAG_maxLocAgeType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_maxLocAgeType != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_maxLocAgeType);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new maxLocAgeType from encoded stream.
             */
            public static maxLocAgeType fromPerUnaligned(byte[] encodedBytes)
            {
                maxLocAgeType result = new maxLocAgeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new maxLocAgeType from encoded stream.
             */
            public static maxLocAgeType fromPerAligned(byte[] encodedBytes)
            {
                maxLocAgeType result = new maxLocAgeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "maxLocAgeType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class delayType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_delayType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public delayType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("7"));

            }

            override
            
          public Asn1Tag getTag()
            {
                return TAG_delayType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_delayType != null)
                {
                    var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                    builder.Add(TAG_delayType);
                    return builder.ToImmutable();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new delayType from encoded stream.
             */
            public static delayType fromPerUnaligned(byte[] encodedBytes)
            {
                delayType result = new delayType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new delayType from encoded stream.
             */
            public static delayType fromPerAligned(byte[] encodedBytes)
            {
                delayType result = new delayType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            override public IEnumerable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public IEnumerable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "delayType = " + getInteger() + ";\n";
            }
        }





        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }




    }
}