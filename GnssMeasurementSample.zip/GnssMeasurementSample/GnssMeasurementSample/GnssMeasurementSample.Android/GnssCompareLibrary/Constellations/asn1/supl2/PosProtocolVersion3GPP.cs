﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PosProtocolVersion3GPP : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_PosProtocolVersion3GPP
      = Asn1Tag.fromClassAndNumber(-1, -1);

  public PosProtocolVersion3GPP() : base()
        { 
        }

        override 
  public Asn1Tag getTag()
        {
            return TAG_PosProtocolVersion3GPP;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_PosProtocolVersion3GPP != null)
            {
                //return ImmutableList.of(TAG_PosProtocolVersion3GPP);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new PosProtocolVersion3GPP from encoded stream.
         */
        public static PosProtocolVersion3GPP fromPerUnaligned(byte[] encodedBytes)
        {
            PosProtocolVersion3GPP result = new PosProtocolVersion3GPP();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new PosProtocolVersion3GPP from encoded stream.
         */
        public static PosProtocolVersion3GPP fromPerAligned(byte[] encodedBytes)
        {
            PosProtocolVersion3GPP result = new PosProtocolVersion3GPP();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        private PosProtocolVersion3GPP.majorVersionFieldType majorVersionField_;
        public PosProtocolVersion3GPP.majorVersionFieldType getMajorVersionField()
        {
            return majorVersionField_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocolVersion3GPP.majorVersionFieldType
         */
        public void setMajorVersionField(Asn1Object value)
        {
            this.majorVersionField_ = (PosProtocolVersion3GPP.majorVersionFieldType)value;
        }
        public PosProtocolVersion3GPP.majorVersionFieldType setMajorVersionFieldToNewInstance()
        {
            majorVersionField_ = new PosProtocolVersion3GPP.majorVersionFieldType();
            return majorVersionField_;
        }

        private PosProtocolVersion3GPP.technicalVersionFieldType technicalVersionField_;
        public PosProtocolVersion3GPP.technicalVersionFieldType getTechnicalVersionField()
        {
            return technicalVersionField_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocolVersion3GPP.technicalVersionFieldType
         */
        public void setTechnicalVersionField(Asn1Object value)
        {
            this.technicalVersionField_ = (PosProtocolVersion3GPP.technicalVersionFieldType)value;
        }
        public PosProtocolVersion3GPP.technicalVersionFieldType setTechnicalVersionFieldToNewInstance()
        {
            technicalVersionField_ = new PosProtocolVersion3GPP.technicalVersionFieldType();
            return technicalVersionField_;
        }

        private PosProtocolVersion3GPP.editorialVersionFieldType editorialVersionField_;
        public PosProtocolVersion3GPP.editorialVersionFieldType getEditorialVersionField()
        {
            return editorialVersionField_;
        }
        /**
         * @throws ClassCastException if value is not a PosProtocolVersion3GPP.editorialVersionFieldType
         */
        public void setEditorialVersionField(Asn1Object value)
        {
            this.editorialVersionField_ = (PosProtocolVersion3GPP.editorialVersionFieldType)value;
        }
        public PosProtocolVersion3GPP.editorialVersionFieldType setEditorialVersionFieldToNewInstance()
        {
            editorialVersionField_ = new PosProtocolVersion3GPP.editorialVersionFieldType();
            return editorialVersionField_;
        }


        /**
         * 
         */
        public class majorVersionFieldType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_majorVersionFieldType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public majorVersionFieldType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_majorVersionFieldType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_majorVersionFieldType != null)
                {
                    //return ImmutableList.of(TAG_majorVersionFieldType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new majorVersionFieldType from encoded stream.
             */
            public static majorVersionFieldType fromPerUnaligned(byte[] encodedBytes)
            {
                majorVersionFieldType result = new majorVersionFieldType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new majorVersionFieldType from encoded stream.
             */
            public static majorVersionFieldType fromPerAligned(byte[] encodedBytes)
            {
                majorVersionFieldType result = new majorVersionFieldType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "majorVersionFieldType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class technicalVersionFieldType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_technicalVersionFieldType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public technicalVersionFieldType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_technicalVersionFieldType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_technicalVersionFieldType != null)
                {
                    //return ImmutableList.of(TAG_technicalVersionFieldType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new technicalVersionFieldType from encoded stream.
             */
            public static technicalVersionFieldType fromPerUnaligned(byte[] encodedBytes)
            {
                technicalVersionFieldType result = new technicalVersionFieldType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new technicalVersionFieldType from encoded stream.
             */
            public static technicalVersionFieldType fromPerAligned(byte[] encodedBytes)
            {
                technicalVersionFieldType result = new technicalVersionFieldType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "technicalVersionFieldType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class editorialVersionFieldType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_editorialVersionFieldType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public editorialVersionFieldType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_editorialVersionFieldType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_editorialVersionFieldType != null)
                {
                    //return ImmutableList.of(TAG_editorialVersionFieldType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new editorialVersionFieldType from encoded stream.
             */
            public static editorialVersionFieldType fromPerUnaligned(byte[] encodedBytes)
            {
                editorialVersionFieldType result = new editorialVersionFieldType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new editorialVersionFieldType from encoded stream.
             */
            public static editorialVersionFieldType fromPerAligned(byte[] encodedBytes)
            {
                editorialVersionFieldType result = new editorialVersionFieldType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "editorialVersionFieldType = " + getInteger() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}