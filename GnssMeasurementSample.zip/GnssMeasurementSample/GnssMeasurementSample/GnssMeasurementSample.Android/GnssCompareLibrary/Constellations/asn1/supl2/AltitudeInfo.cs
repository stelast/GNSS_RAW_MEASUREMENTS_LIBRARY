﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class AltitudeInfo : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_AltitudeInfo = Asn1Tag.fromClassAndNumber(-1, -1);

        public AltitudeInfo() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_AltitudeInfo;
        }

        override  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_AltitudeInfo != null)
            {
                //return ImmutableList.of(TAG_AltitudeInfo);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new AltitudeInfo from encoded stream.
         */
        public static AltitudeInfo fromPerUnaligned(byte[] encodedBytes)
        {
            AltitudeInfo result = new AltitudeInfo();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new AltitudeInfo from encoded stream.
         */
        public static AltitudeInfo fromPerAligned(byte[] encodedBytes)
        {
            AltitudeInfo result = new AltitudeInfo();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        //private AltitudeInfo.altitudeDirectionType altitudeDirection_;
        //public AltitudeInfo.altitudeDirectionType getAltitudeDirection()
        //{
        //    return altitudeDirection_;
        //}
        ///**
        // * @throws ClassCastException if value is not a AltitudeInfo.altitudeDirectionType
        // */
        //public void setAltitudeDirection(Asn1Object value)
        //{
        //    this.altitudeDirection_ = (AltitudeInfo.altitudeDirectionType)value;
        //}
        //public AltitudeInfo.altitudeDirectionType setAltitudeDirectionToNewInstance()
        //{
        //    altitudeDirection_ = new AltitudeInfo.altitudeDirectionType();
        //    return altitudeDirection_;
        //}

        private AltitudeInfo.altitudeType altitude_;
        public AltitudeInfo.altitudeType getAltitude()
        {
            return altitude_;
        }
        /**
         * @throws ClassCastException if value is not a AltitudeInfo.altitudeType
         */
        public void setAltitude(Asn1Object value)
        {
            this.altitude_ = (AltitudeInfo.altitudeType)value;
        }
        public AltitudeInfo.altitudeType setAltitudeToNewInstance()
        {
            altitude_ = new AltitudeInfo.altitudeType();
            return altitude_;
        }

        private AltitudeInfo.altUncertaintyType altUncertainty_;
        public AltitudeInfo.altUncertaintyType getAltUncertainty()
        {
            return altUncertainty_;
        }
        /**
         * @throws ClassCastException if value is not a AltitudeInfo.altUncertaintyType
         */
        public void setAltUncertainty(Asn1Object value)
        {
            this.altUncertainty_ = (AltitudeInfo.altUncertaintyType)value;
        }
        public AltitudeInfo.altUncertaintyType setAltUncertaintyToNewInstance()
        {
            altUncertainty_ = new AltitudeInfo.altUncertaintyType();
            return altUncertainty_;
        }










    // Copyright 2008 Google Inc. All Rights Reserved.
    /*
     * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
     */


    //

    /**
     * 
     */
    public class altitudeType : Asn1Integer
    {
        //

        private static readonly Asn1Tag TAG_altitudeType
            = Asn1Tag.fromClassAndNumber(-1, -1);

        public altitudeType() : base()
        { 
            setValueRange(new BigInteger("0"), new BigInteger("32767"));

        }

        override

          public Asn1Tag getTag()
        {
            return TAG_altitudeType;
        }

        override
          public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_altitudeType != null)
            {
                //return ImmutableList.of(TAG_altitudeType);
                return Asn1Integer.getPossibleFirstTags();
            }
            else
            {
                return Asn1Integer.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new altitudeType from encoded stream.
         */
        public static altitudeType fromPerUnaligned(byte[] encodedBytes)
        {
            altitudeType result = new altitudeType();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new altitudeType from encoded stream.
         */
        public static altitudeType fromPerAligned(byte[] encodedBytes)
        {
            altitudeType result = new altitudeType();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            return "altitudeType = " + getInteger() + ";\n";
        }
    }


    // Copyright 2008 Google Inc. All Rights Reserved.
    /*
     * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
     */


    //

    /**
     * 
     */
    public class altUncertaintyType : Asn1Integer
    {
        //

        private static readonly Asn1Tag TAG_altUncertaintyType
            = Asn1Tag.fromClassAndNumber(-1, -1);

        public altUncertaintyType() : base()
        {
            setValueRange(new BigInteger("0"), new BigInteger("127"));

        }

        override

          public Asn1Tag getTag()
        {
            return TAG_altUncertaintyType;
        }

        override
          public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_altUncertaintyType != null)
            {
                //return ImmutableList.of(TAG_altUncertaintyType);
                return Asn1Integer.getPossibleFirstTags();
            }
            else
            {
                return Asn1Integer.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new altUncertaintyType from encoded stream.
         */
        public static altUncertaintyType fromPerUnaligned(byte[] encodedBytes)
        {
            altUncertaintyType result = new altUncertaintyType();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new altUncertaintyType from encoded stream.
         */
        public static altUncertaintyType fromPerAligned(byte[] encodedBytes)
        {
            altUncertaintyType result = new altUncertaintyType();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            return "altUncertaintyType = " + getInteger() + ";\n";
        }
    }





    //  override public Iterable<BitStream> encodePerUnaligned()
    //{
    //    return base.encodePerUnaligned();
    //}

    //override public Iterable<BitStream> encodePerAligned()
    //{
    //    return base.encodePerAligned();
    //}

    override public void decodePerUnaligned(BitStreamReader reader)
    {
        base.decodePerUnaligned(reader);
    }

    override public void decodePerAligned(BitStreamReader reader)
    {
        base.decodePerAligned(reader);
    }

    public String toString()
    {
        return toIndentedString("");
    }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}