﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class GanssRequestedCommonAssistanceDataList : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_GanssRequestedCommonAssistanceDataList = Asn1Tag.fromClassAndNumber(-1, -1);

        public GanssRequestedCommonAssistanceDataList() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_GanssRequestedCommonAssistanceDataList;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_GanssRequestedCommonAssistanceDataList != null)
            {
                //return ImmutableList.of(TAG_GanssRequestedCommonAssistanceDataList);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new GanssRequestedCommonAssistanceDataList from encoded stream.
         */
        public static GanssRequestedCommonAssistanceDataList fromPerUnaligned(byte[] encodedBytes)
        {
            GanssRequestedCommonAssistanceDataList result = new GanssRequestedCommonAssistanceDataList();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new GanssRequestedCommonAssistanceDataList from encoded stream.
         */
        public static GanssRequestedCommonAssistanceDataList fromPerAligned(byte[] encodedBytes)
        {
            GanssRequestedCommonAssistanceDataList result = new GanssRequestedCommonAssistanceDataList();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }


        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        private GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType ganssReferenceTime_;
        public GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType getGanssReferenceTime()
        {
            return ganssReferenceTime_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType
         */
        public void setGanssReferenceTime(Asn1Object value)
        {
            this.ganssReferenceTime_ = (GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType)value;
        }
        public GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType setGanssReferenceTimeToNewInstance()
        {
            ganssReferenceTime_ = new GanssRequestedCommonAssistanceDataList.ganssReferenceTimeType();
            return ganssReferenceTime_;
        }

        private GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType ganssIonosphericModel_;
        public GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType getGanssIonosphericModel()
        {
            return ganssIonosphericModel_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType
         */
        public void setGanssIonosphericModel(Asn1Object value)
        {
            this.ganssIonosphericModel_ = (GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType)value;
        }
        public GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType setGanssIonosphericModelToNewInstance()
        {
            ganssIonosphericModel_ = new GanssRequestedCommonAssistanceDataList.ganssIonosphericModelType();
            return ganssIonosphericModel_;
        }

        private GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type ganssAdditionalIonosphericModelForDataID00_;
        public GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type getGanssAdditionalIonosphericModelForDataID00()
        {
            return ganssAdditionalIonosphericModelForDataID00_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type
         */
        public void setGanssAdditionalIonosphericModelForDataID00(Asn1Object value)
        {
            this.ganssAdditionalIonosphericModelForDataID00_ = (GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type)value;
        }
        public GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type setGanssAdditionalIonosphericModelForDataID00ToNewInstance()
        {
            ganssAdditionalIonosphericModelForDataID00_ = new GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID00Type();
            return ganssAdditionalIonosphericModelForDataID00_;
        }

        private GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type ganssAdditionalIonosphericModelForDataID11_;
        public GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type getGanssAdditionalIonosphericModelForDataID11()
        {
            return ganssAdditionalIonosphericModelForDataID11_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type
         */
        public void setGanssAdditionalIonosphericModelForDataID11(Asn1Object value)
        {
            this.ganssAdditionalIonosphericModelForDataID11_ = (GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type)value;
        }
        public GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type setGanssAdditionalIonosphericModelForDataID11ToNewInstance()
        {
            ganssAdditionalIonosphericModelForDataID11_ = new GanssRequestedCommonAssistanceDataList.ganssAdditionalIonosphericModelForDataID11Type();
            return ganssAdditionalIonosphericModelForDataID11_;
        }

        private GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType ganssEarthOrientationParameters_;
        public GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType getGanssEarthOrientationParameters()
        {
            return ganssEarthOrientationParameters_;
        }
        /**
         * @throws ClassCastException if value is not a GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType
         */
        public void setGanssEarthOrientationParameters(Asn1Object value)
        {
            this.ganssEarthOrientationParameters_ = (GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType)value;
        }
        public GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType setGanssEarthOrientationParametersToNewInstance()
        {
            ganssEarthOrientationParameters_ = new GanssRequestedCommonAssistanceDataList.ganssEarthOrientationParametersType();
            return ganssEarthOrientationParameters_;
        }

        /**
         * 
         */
        public class ganssReferenceTimeType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ganssReferenceTimeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssReferenceTimeType() : base()
            {
            }

            override

      public Asn1Tag getTag()
            {
                return TAG_ganssReferenceTimeType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssReferenceTimeType != null)
                {
                    //return ImmutableList.of(TAG_ganssReferenceTimeType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssReferenceTimeType from encoded stream.
             */
            public static ganssReferenceTimeType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssReferenceTimeType result = new ganssReferenceTimeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssReferenceTimeType from encoded stream.
             */
            public static ganssReferenceTimeType fromPerAligned(byte[] encodedBytes)
            {
                ganssReferenceTimeType result = new ganssReferenceTimeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssReferenceTimeType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ganssIonosphericModelType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ganssIonosphericModelType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssIonosphericModelType() : base()
            {
            }

            override

          public Asn1Tag getTag()
            {
                return TAG_ganssIonosphericModelType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssIonosphericModelType != null)
                {
                    //return ImmutableList.of(TAG_ganssIonosphericModelType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssIonosphericModelType from encoded stream.
             */
            public static ganssIonosphericModelType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssIonosphericModelType result = new ganssIonosphericModelType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssIonosphericModelType from encoded stream.
             */
            public static ganssIonosphericModelType fromPerAligned(byte[] encodedBytes)
            {
                ganssIonosphericModelType result = new ganssIonosphericModelType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssIonosphericModelType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ganssAdditionalIonosphericModelForDataID00Type : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ganssAdditionalIonosphericModelForDataID00Type
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssAdditionalIonosphericModelForDataID00Type() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_ganssAdditionalIonosphericModelForDataID00Type;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssAdditionalIonosphericModelForDataID00Type != null)
                {
                    //return ImmutableList.of(TAG_ganssAdditionalIonosphericModelForDataID00Type);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssAdditionalIonosphericModelForDataID00Type from encoded stream.
             */
            public static ganssAdditionalIonosphericModelForDataID00Type fromPerUnaligned(byte[] encodedBytes)
            {
                ganssAdditionalIonosphericModelForDataID00Type result = new ganssAdditionalIonosphericModelForDataID00Type();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssAdditionalIonosphericModelForDataID00Type from encoded stream.
             */
            public static ganssAdditionalIonosphericModelForDataID00Type fromPerAligned(byte[] encodedBytes)
            {
                ganssAdditionalIonosphericModelForDataID00Type result = new ganssAdditionalIonosphericModelForDataID00Type();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssAdditionalIonosphericModelForDataID00Type = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ganssAdditionalIonosphericModelForDataID11Type : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ganssAdditionalIonosphericModelForDataID11Type
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssAdditionalIonosphericModelForDataID11Type() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_ganssAdditionalIonosphericModelForDataID11Type;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssAdditionalIonosphericModelForDataID11Type != null)
                {
                    //return ImmutableList.of(TAG_ganssAdditionalIonosphericModelForDataID11Type);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssAdditionalIonosphericModelForDataID11Type from encoded stream.
             */
            public static ganssAdditionalIonosphericModelForDataID11Type fromPerUnaligned(byte[] encodedBytes)
            {
                ganssAdditionalIonosphericModelForDataID11Type result = new ganssAdditionalIonosphericModelForDataID11Type();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssAdditionalIonosphericModelForDataID11Type from encoded stream.
             */
            public static ganssAdditionalIonosphericModelForDataID11Type fromPerAligned(byte[] encodedBytes)
            {
                ganssAdditionalIonosphericModelForDataID11Type result = new ganssAdditionalIonosphericModelForDataID11Type();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssAdditionalIonosphericModelForDataID11Type = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class ganssEarthOrientationParametersType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_ganssEarthOrientationParametersType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssEarthOrientationParametersType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_ganssEarthOrientationParametersType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssEarthOrientationParametersType != null)
                {
                    //return ImmutableList.of(TAG_ganssEarthOrientationParametersType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssEarthOrientationParametersType from encoded stream.
             */
            public static ganssEarthOrientationParametersType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssEarthOrientationParametersType result = new ganssEarthOrientationParametersType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssEarthOrientationParametersType from encoded stream.
             */
            public static ganssEarthOrientationParametersType fromPerAligned(byte[] encodedBytes)
            {
                ganssEarthOrientationParametersType result = new ganssEarthOrientationParametersType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssEarthOrientationParametersType = " + getValue() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}