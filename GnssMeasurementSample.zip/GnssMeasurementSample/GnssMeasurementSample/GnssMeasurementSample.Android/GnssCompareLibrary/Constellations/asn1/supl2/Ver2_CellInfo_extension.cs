﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Ver2_CellInfo_extension : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Ver2_CellInfo_extension = Asn1Tag.fromClassAndNumber(-1, -1);

        private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;
          
        public Ver2_CellInfo_extension() : base()
        { 
        }
        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        public class Select : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Select(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }
            public static List<int> values()
            {
                return new List<int>() { 19,20,21,22,23 };
            }

            public static Select Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.HrpdCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 19), true, choose);
                    case ChoiceComponent.SelectEnum.UmbCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 20), true, choose);
                    case ChoiceComponent.SelectEnum.LteCell:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 21), true, choose);
                    case ChoiceComponent.SelectEnum.WlanAP:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 22), true, choose);
                    case ChoiceComponent.SelectEnum.WimaxBS:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 23), true, choose);
                    default:
                        return null;
                }
            }

            public int ordinal()
            {
                throw new Exception();
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }
            virtual public List<Asn1Tag> getPossibleFirstTags()
            {
                return new List<Asn1Tag>();
            }

            virtual public String elementIndentedString(Asn1Object element, String indent)
            {
                return "Select " + " : " + element.toIndentedString(indent);
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.HrpdCell:
                        return new HrpdCellInformation();
                    case ChoiceComponent.SelectEnum.UmbCell:
                        return new UmbCellInformation();
                    case ChoiceComponent.SelectEnum.LteCell:
                        return new LteCellInformation();
                    case ChoiceComponent.SelectEnum.WlanAP:
                        return new WlanAPInformation();
                    case ChoiceComponent.SelectEnum.WimaxBS:
                        return new WimaxBSInformation(); 
                    default:
                        throw new SystemException("Select template error");
                }
            }

            ChoiceComponent.SelectEnum ChoiceComponent.getTypeEnum()
            {
                return tipo;
            }
        }

        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Extend(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }
            public static List<int> values()
            {
                return new List<int>() {  };
            }

            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    default:
                        return null;
                }
            }

            public int ordinal()
            {
                throw new Exception();
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }
            virtual public List<Asn1Tag> getPossibleFirstTags()
            {
                return new List<Asn1Tag>();
            }

            virtual public String elementIndentedString(Asn1Object element, String indent)
            {
                return "Select " + " : " + element.toIndentedString(indent);
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    default:
                        throw new SystemException("Select template error");
                }
            }

            ChoiceComponent.SelectEnum ChoiceComponent.getTypeEnum()
            {
                return tipo;
            }
        }
        /**
         * @throws {@code Exception} if {@code !isWlanAP}.
         */
        public WlanAPInformation getWlanAP()
        {
            if (!isWlanAP())
            {
                throw new Exception("Ver2_CellInfo_extension value not a WlanAP");
            }
            return (WlanAPInformation)element;
        }

        override

        public Asn1Tag getTag()
        {
            return TAG_Ver2_CellInfo_extension;
        }

        override
        public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Ver2_CellInfo_extension != null)
            {
                var builder = ImmutableList.CreateBuilder<Asn1Tag>();
                builder.Add(TAG_Ver2_CellInfo_extension);
                return builder.ToImmutable();
            }
            else
            {
                return tagToSelection.Keys.ToImmutableList();
            }
        }

        /**
         * Creates a new Ver2_CellInfo_extension from encoded stream.
         */
        public static Ver2_CellInfo_extension fromPerUnaligned(byte[] encodedBytes)
        {
            Ver2_CellInfo_extension result = new Ver2_CellInfo_extension();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Ver2_CellInfo_extension from encoded stream.
         */
        public static Ver2_CellInfo_extension fromPerAligned(byte[] encodedBytes)
        {
            Ver2_CellInfo_extension result = new Ver2_CellInfo_extension();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        protected bool hasExtensionValue()
        {
            return extension;
        }

        protected int getSelectionOrdinal()
        {
            return selection.ordinal();
        }
         
        protected ChoiceComponent getSelectedComponent()
        {
            return selection;
        }

        protected int getOptionCount()
        {
            if (hasExtensionValue())
            {
                return Extend.values().Count();
            }
            return Select.values().Count();
        }

        protected Asn1Object createAndSetValue(bool isExtensionValue,
                                               int ordinal)
        {
            extension = isExtensionValue;
            if (isExtensionValue)
            { 
                //selection = null;
            }
            else
            {
                switch (ordinal)
                {
                    case 19:
                        selection = Select.Create(ChoiceComponent.SelectEnum.HrpdCell);
                        break;
                    case 20:
                        selection = Select.Create(ChoiceComponent.SelectEnum.UmbCell);
                        break;
                    case 21:
                        selection = Select.Create(ChoiceComponent.SelectEnum.LteCell);
                        break;
                    case 22:
                        selection = Select.Create(ChoiceComponent.SelectEnum.WlanAP);
                        break;
                    case 23:
                        selection = Select.Create(ChoiceComponent.SelectEnum.WimaxBS);
                        break;
                }
            }
            element = selection.createElement();
            return element;
        }

        protected ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            Select select = tagToSelection[tag];
            if (select == null)
            {
                throw new Exception("Unknown selection tag: " + tag);
            }
            element = select.createElement();
            selection = select;
            extension = false;
            return select;
        }
         
        public void setWlanAP(WlanAPInformation selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.WlanAP);
            //selection = Select.$WlanAP;
            extension = false;
            element = selected;
        }

        public WlanAPInformation setWlanAPToNewInstance()
        {
            WlanAPInformation element = new WlanAPInformation();
            setWlanAP(element);
            return element;
        }

        public bool isWlanAP()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.WlanAP == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$WlanAP == selection;
        }


        public bool isHrpdCell()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.HrpdCell == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$HrpdCell == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isHrpdCell}.
         */ 
        public HrpdCellInformation getHrpdCell()
        {
            if (!isHrpdCell())
            {
                throw new Exception("Ver2_CellInfo_extension value not a HrpdCell");
            }
            return (HrpdCellInformation)element;
        }

        public void setHrpdCell(HrpdCellInformation selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.HrpdCell);
            extension = false;
            element = selected;
        }

        public HrpdCellInformation setHrpdCellToNewInstance()
        {
            HrpdCellInformation element = new HrpdCellInformation();
            setHrpdCell(element);
            return element;
        }



        public bool isUmbCell()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.UmbCell == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$UmbCell == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isUmbCell}.
         */ 
        public UmbCellInformation getUmbCell()
        {
            if (!isUmbCell())
            {
                throw new Exception("Ver2_CellInfo_extension value not a UmbCell");
            }
            return (UmbCellInformation)element;
        }

        public void setUmbCell(UmbCellInformation selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.UmbCell);
            extension = false;
            element = selected;
        }

        public UmbCellInformation setUmbCellToNewInstance()
        {
            UmbCellInformation element = new UmbCellInformation();
            setUmbCell(element);
            return element;
        }



        public bool isLteCell()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.LteCell == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$LteCell == selection;
        }

        /**
         * @throws {@code Exception} if {@code !isLteCell}.
         */ 
        public LteCellInformation getLteCell()
        {
            if (!isLteCell())
            {
                throw new Exception("Ver2_CellInfo_extension value not a LteCell");
            }
            return (LteCellInformation)element;
        }

        public void setLteCell(LteCellInformation selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.LteCell);
            extension = false;
            element = selected;
        }

        public LteCellInformation setLteCellToNewInstance()
        {
            LteCellInformation element = new LteCellInformation();
            setLteCell(element);
            return element;
        }

        override public IEnumerable<BitStream> encodePerUnaligned()
        {
            return base.encodePerUnaligned();
        }

        override public IEnumerable<BitStream> encodePerAligned()
        {
            return base.encodePerAligned();
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        //private String elementIndentedString(String indent)
        //{
        //    if (element == null)
        //    {
        //        return "null;\n";
        //    }
        //    if (extension)
        //    {
        //        return Extend.values()[selection.ordinal()]
        //            .elementIndentedString(element, indent + "  ");
        //    }
        //    else
        //    {
        //        return Select.values()[selection.ordinal()]
        //            .elementIndentedString(element, indent + "  ");
        //    }
        //}

        public String toIndentedString(String indent)
        {
            return "Ver2_CellInfo_extension = " + /*elementIndentedString(indent) +*/ indent + ";\n";
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }
    }
}