﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Version : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_Version
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public Version() : base()
        {
        }

        override

  public Asn1Tag getTag()
        {
            return TAG_Version;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_Version != null)
            {
                //return ImmutableList.of(TAG_Version);
                return Asn1Sequence.getPossibleFirstTags();
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new Version from encoded stream.
         */
        public static Version fromPerUnaligned(byte[] encodedBytes)
        {
            Version result = new Version();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new Version from encoded stream.
         */
        public static Version fromPerAligned(byte[] encodedBytes)
        {
            Version result = new Version();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        private Version.majType maj_;
        public Version.majType getMaj()
        {
            return maj_;
        }
        /**
         * @throws ClassCastException if value is not a Version.majType
         */
        public void setMaj(Asn1Object value)
        {
            this.maj_ = (Version.majType)value;
        }
        public Version.majType setMajToNewInstance()
        {
            maj_ = new Version.majType();
            return maj_;
        }

        private Version.minType min_;
        public Version.minType getMin()
        {
            return min_;
        }
        /**
         * @throws ClassCastException if value is not a Version.minType
         */
        public void setMin(Asn1Object value)
        {
            this.min_ = (Version.minType)value;
        }
        public Version.minType setMinToNewInstance()
        {
            min_ = new Version.minType();
            return min_;
        }

        private Version.servindType servind_;
        public Version.servindType getServind()
        {
            return servind_;
        }
        /**
         * @throws ClassCastException if value is not a Version.servindType
         */
        public void setServind(Asn1Object value)
        {
            this.servind_ = (Version.servindType)value;
        }
        public Version.servindType setServindToNewInstance()
        {
            servind_ = new Version.servindType();
            return servind_;
        }
        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return false;
        }

        /**
         * 
         */
        public class majType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_majType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public majType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

      public Asn1Tag getTag()
            {
                return TAG_majType;
            }

            override
      public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_majType != null)
                {
                    //return ImmutableList.of(TAG_majType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new majType from encoded stream.
             */
            public static majType fromPerUnaligned(byte[] encodedBytes)
            {
                majType result = new majType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new majType from encoded stream.
             */
            public static majType fromPerAligned(byte[] encodedBytes)
            {
                majType result = new majType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "majType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class minType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_minType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public minType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

          public Asn1Tag getTag()
            {
                return TAG_minType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_minType != null)
                {
                    //return ImmutableList.of(TAG_minType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new minType from encoded stream.
             */
            public static minType fromPerUnaligned(byte[] encodedBytes)
            {
                minType result = new minType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new minType from encoded stream.
             */
            public static minType fromPerAligned(byte[] encodedBytes)
            {
                minType result = new minType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "minType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class servindType : Asn1Integer
        {
            //

            private static readonly Asn1Tag TAG_servindType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public servindType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("255"));

            }

            override

              public Asn1Tag getTag()
            {
                return TAG_servindType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_servindType != null)
                {
                    //return ImmutableList.of(TAG_servindType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new servindType from encoded stream.
             */
            public static servindType fromPerUnaligned(byte[] encodedBytes)
            {
                servindType result = new servindType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new servindType from encoded stream.
             */
            public static servindType fromPerAligned(byte[] encodedBytes)
            {
                servindType result = new servindType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "servindType = " + getInteger() + ";\n";
            }
        }





        //  override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            Version objeto;
            public M1(Version objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getMaj();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return Version.majType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getMaj() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setMajToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "maj : " + this.objeto.getMaj().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            Version objeto;
            public M2(Version objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getMin();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return Version.minType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getMin() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setMinToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "min : " + this.objeto.getMin().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            Version objeto;
            public M3(Version objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getServind();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return Version.servindType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getServind() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setServindToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "servind : " + this.objeto.getServind().toIndentedString(indent);
            }
        }
    }
}