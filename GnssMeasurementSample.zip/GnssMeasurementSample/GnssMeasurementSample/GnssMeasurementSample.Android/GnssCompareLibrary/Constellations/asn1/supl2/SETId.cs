﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Nio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SETId : Asn1Choice
    {
        private static readonly Asn1Tag TAG_SETId = Asn1Tag.fromClassAndNumber(-1, -1);
        private static readonly Dictionary<Asn1Tag, Select> tagToSelection = new Dictionary<Asn1Tag, Select>();

        private bool extension;
        private ChoiceComponent selection;
        private Asn1Object element;
        /**
         * @throws {@code IllegalStateException} if {@code !isIPAddress}.
         */
        public IPAddress getIPAddress()
        {
            if (!isIPAddress())
            {
                throw new SystemException("SETId value not a IPAddress");
            }
            return (IPAddress)element;
        }

        public void setIPAddress(IPAddress selected)
        {
            selection = Select.Create(ChoiceComponent.SelectEnum.IPAddress);
            //selection = Select.$IPAddress;
            extension = false;
            element = selected;
        }

        public IPAddress setIPAddressToNewInstance()
        {
            IPAddress element = new IPAddress();
            setIPAddress(element);
            return element;
        }

        public bool isIPAddress()
        {
            return !hasExtensionValue() && selection != null && ChoiceComponent.SelectEnum.IPAddress == selection.getTypeEnum();
            //return !hasExtensionValue() && Select.$IPAddress == selection;
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            throw new NotImplementedException();
        }

        public override int getBerValueLength()
        {
            throw new NotImplementedException();
        }

        public override Asn1Tag getDefaultTag()
        {
            throw new NotImplementedException();
        }

        public override Asn1Object getValue()
        {
            return element;
        }

        protected override Asn1Object createAndSetValue(bool isExtensionValue, int ordinal)
        {
            extension = isExtensionValue;
            if (isExtensionValue)
            {
                switch (ordinal)
                {
                    case 24:
                        selection = Extend.Create(ChoiceComponent.SelectEnum.undefined); 
                        break;
                }
            }
            else
            {
                switch (ordinal)
                {
                    case 31:
                        selection = Select.Create(ChoiceComponent.SelectEnum.IPAddress); 
                        break;
                }
            }
            element = selection.createElement();
            return element;
        }

        protected override ChoiceComponent createAndSetValue(Asn1Tag tag)
        {
            Select select = tagToSelection[tag];
            if (select == null)
            {
                throw new ArgumentException("Unknown selection tag: " + tag);
            }
            element = select.createElement();
            selection = select;
            extension = false;
            return select;
        }

        protected override int getOptionCount()
        {
            if (hasExtensionValue())
            {
                return Extend.values().Count();
            }
            return Select.values().Count();
        }

        protected override ChoiceComponent getSelectedComponent()
        {
            return selection;
        }

        protected override int getSelectionOrdinal()
        {
            return selection.ordinal();
        }

        protected override bool hasExtensionValue()
        {
            return extension;
        }

        protected override bool isExtensible()
        {
            return true;
        }


        public class Select : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Select(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 31 };
            }

            public static Select Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.IPAddress:
                        return new Select(Asn1Tag.fromClassAndNumber(2, 31), true, choose); 
                    default:
                        return null;
                }
            }

            public int ordinal()
            {
                return 31;
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool isImplicitTagging()
            {
                return isImplicitTaggin;
            }
            virtual public List<Asn1Tag> getPossibleFirstTags()
            {
                return new List<Asn1Tag>();
            }

            virtual public String elementIndentedString(Asn1Object element, String indent)
            {
                return "Select " + " : " + element.toIndentedString(indent);
            }

            public Asn1Object createElement()
            {
                switch (tipo)
                {
                    case ChoiceComponent.SelectEnum.IPAddress:
                        return new Horvel(); 
                    default:
                        throw new SystemException("Select template error");
                }
            }

            ChoiceComponent.SelectEnum ChoiceComponent.getTypeEnum()
            {
                return tipo;
            }
        }
        public class Extend : ChoiceComponent
        {
            readonly Asn1Tag tag;
            readonly bool isImplicitTaggin;

            ChoiceComponent.SelectEnum tipo;

            public Extend(Asn1Tag tag, bool isImplicitTaggin, ChoiceComponent.SelectEnum tipo)
            {
                this.tag = tag;
                this.isImplicitTaggin = isImplicitTaggin;
                this.tipo = tipo;
            }

            public static List<int> values()
            {
                return new List<int>() { 24 };
            }

            public static Extend Create(ChoiceComponent.SelectEnum choose)
            {
                switch (choose)
                {
                    case ChoiceComponent.SelectEnum.undefined:
                        return new Extend(Asn1Tag.fromClassAndNumber(2, 24), true, choose);
                    default:
                        return null;
                }
            }

            public Asn1Object createElement()
            {
                throw new NotImplementedException();
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public ChoiceComponent.SelectEnum getTypeEnum()
            {
                return tipo;
            }

            public bool isImplicitTagging()
            {
                return this.isImplicitTaggin;
            }

            public int ordinal()
            {
                return 24; ;
            }
        }


    }
}