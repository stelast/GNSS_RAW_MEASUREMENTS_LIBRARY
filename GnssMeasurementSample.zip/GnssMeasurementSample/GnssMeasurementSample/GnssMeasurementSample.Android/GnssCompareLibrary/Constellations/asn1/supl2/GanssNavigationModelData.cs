﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Math;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class GanssNavigationModelData : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_GanssNavigationModelData = Asn1Tag.fromClassAndNumber(-1, -1);

        public GanssNavigationModelData() : base()
        { 
        }

        override public Asn1Tag getTag()
        {
            return TAG_GanssNavigationModelData;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_GanssNavigationModelData != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_GanssNavigationModelData);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new GanssNavigationModelData from encoded stream.
         */
        public static GanssNavigationModelData fromPerUnaligned(byte[] encodedBytes)
        {
            GanssNavigationModelData result = new GanssNavigationModelData();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new GanssNavigationModelData from encoded stream.
         */
        public static GanssNavigationModelData fromPerAligned(byte[] encodedBytes)
        {
            GanssNavigationModelData result = new GanssNavigationModelData();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }



        override protected bool isExtensible()
        {
            return true;
        }

        override public bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }


        private GanssNavigationModelData.ganssWeekType ganssWeek_;
        public GanssNavigationModelData.ganssWeekType getGanssWeek()
        {
            return ganssWeek_;
        }
        /**
         * @throws ClassCastException if value is not a GanssNavigationModelData.ganssWeekType
         */
        public void setGanssWeek(Asn1Object value)
        {
            this.ganssWeek_ = (GanssNavigationModelData.ganssWeekType)value;
        }
        public GanssNavigationModelData.ganssWeekType setGanssWeekToNewInstance()
        {
            ganssWeek_ = new GanssNavigationModelData.ganssWeekType();
            return ganssWeek_;
        }

        private GanssNavigationModelData.ganssToeType ganssToe_;
        public GanssNavigationModelData.ganssToeType getGanssToe()
        {
            return ganssToe_;
        }
        /**
         * @throws ClassCastException if value is not a GanssNavigationModelData.ganssToeType
         */
        public void setGanssToe(Asn1Object value)
        {
            this.ganssToe_ = (GanssNavigationModelData.ganssToeType)value;
        }
        public GanssNavigationModelData.ganssToeType setGanssToeToNewInstance()
        {
            ganssToe_ = new GanssNavigationModelData.ganssToeType();
            return ganssToe_;
        }

        private GanssNavigationModelData.t_toeLimitType t_toeLimit_;
        public GanssNavigationModelData.t_toeLimitType getT_toeLimit()
        {
            return t_toeLimit_;
        }
        /**
         * @throws ClassCastException if value is not a GanssNavigationModelData.t_toeLimitType
         */
        public void setT_toeLimit(Asn1Object value)
        {
            this.t_toeLimit_ = (GanssNavigationModelData.t_toeLimitType)value;
        }
        public GanssNavigationModelData.t_toeLimitType setT_toeLimitToNewInstance()
        {
            t_toeLimit_ = new GanssNavigationModelData.t_toeLimitType();
            return t_toeLimit_;
        }

        private SatellitesListRelatedDataList satellitesListRelatedDataList_;
        public SatellitesListRelatedDataList getSatellitesListRelatedDataList()
        {
            return satellitesListRelatedDataList_;
        }
        /**
         * @throws ClassCastException if value is not a SatellitesListRelatedDataList
         */
        public void setSatellitesListRelatedDataList(Asn1Object value)
        {
            this.satellitesListRelatedDataList_ = (SatellitesListRelatedDataList)value;
        }
        public SatellitesListRelatedDataList setSatellitesListRelatedDataListToNewInstance()
        {
            satellitesListRelatedDataList_ = new SatellitesListRelatedDataList();
            return satellitesListRelatedDataList_;
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }

        /**
         * 
         */
        public class ganssWeekType : Asn1Integer
        { 

            private static readonly Asn1Tag TAG_ganssWeekType = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssWeekType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("4095")); 
            }

            override  public Asn1Tag getTag()
            {
                return TAG_ganssWeekType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssWeekType != null)
                    {
                        return Asn1Integer.getPossibleFirstTags();
                        //return ImmutableList.of(TAG_ganssWeekType);
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssWeekType from encoded stream.
             */
            public static ganssWeekType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssWeekType result = new ganssWeekType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssWeekType from encoded stream.
             */
            public static ganssWeekType fromPerAligned(byte[] encodedBytes)
            {
                ganssWeekType result = new ganssWeekType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssWeekType = " + getInteger() + ";\n";
            }
        }

        /**
         * 
         */
        public  class ganssToeType : Asn1Integer
        { 

            private static readonly Asn1Tag TAG_ganssToeType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public ganssToeType() : base()
            {
                setValueRange(new BigInteger("0"), new BigInteger("167"));

            }

            override public Asn1Tag getTag()
            {
                return TAG_ganssToeType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_ganssToeType != null)
                {
                    //return ImmutableList.of(TAG_ganssToeType);
                    return Asn1Integer.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new ganssToeType from encoded stream.
             */
            public static ganssToeType fromPerUnaligned(byte[] encodedBytes)
            {
                ganssToeType result = new ganssToeType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new ganssToeType from encoded stream.
             */
            public static ganssToeType fromPerAligned(byte[] encodedBytes)
            {
                ganssToeType result = new ganssToeType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "ganssToeType = " + getInteger() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class t_toeLimitType : Asn1Integer
        {
          //

          private static readonly Asn1Tag TAG_t_toeLimitType
              = Asn1Tag.fromClassAndNumber(-1, -1);

            public t_toeLimitType() : base()
            { 
                setValueRange(new BigInteger("0"), new BigInteger("15"));

            }

            override public Asn1Tag getTag()
            {
                return TAG_t_toeLimitType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_t_toeLimitType != null)
                    {
                        return Asn1Integer.getPossibleFirstTags();
                        //return ImmutableList.of(TAG_t_toeLimitType);
                }
                else
                {
                    return Asn1Integer.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new t_toeLimitType from encoded stream.
             */
            public static t_toeLimitType fromPerUnaligned(byte[] encodedBytes)
            {
                t_toeLimitType result = new t_toeLimitType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new t_toeLimitType from encoded stream.
             */
            public static t_toeLimitType fromPerAligned(byte[] encodedBytes)
            {
                t_toeLimitType result = new t_toeLimitType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "t_toeLimitType = " + getInteger() + ";\n";
            }
        }

  
  




    }
}