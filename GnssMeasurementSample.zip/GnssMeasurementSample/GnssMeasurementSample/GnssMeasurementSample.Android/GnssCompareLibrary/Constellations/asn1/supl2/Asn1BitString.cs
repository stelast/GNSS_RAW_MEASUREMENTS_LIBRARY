﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Lang;
using Java.Nio;
using Java.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class Asn1BitString : Asn1Object
    {
        //private static readonly List<Asn1Tag> possibleFirstTags =
        //      ImmutableList.of(Asn1Tag.BIT_STRING);

        private int minimumSize = 0;
        private int maximumSize = 0; // null == unbounded.
        private BitSet value;

        //public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        //{
        //    return possibleFirstTags;
        //}

        protected void setMinSize(int min)
        {
            minimumSize = min;
        }

        protected void setMaxSize(int max)
        {
            maximumSize = max;
        }

        public BitSet getValue()
        {
            return value;
        }

        /** Sets the value to a new {@link BitSet} if value is null. */
        protected void ensureValuePopulated()
        {
            if (null == value)
            {
                value = new BitSet();
            }
        }

        public void setValue(BitSet value)
        {
            this.value = value;
        }

        public override Asn1Tag getDefaultTag()
        {
            return Asn1Tag.BIT_STRING;
        }

        public override int getBerValueLength()
        {
            Preconditions.CheckNotNull(value, "No value set.");
            // the +1 is for the extra leading octet indicating the number of unused bits in last octet
            return (value.Length() + 7) / 8 + 1;
        } 

        private void validateValue()
        {
            Preconditions.CheckNotNull(value, "No value set.");
            Preconditions.CheckState(
                maximumSize == null || value.Length() <= maximumSize, "Too large %s");
        }

        public override void encodeBerValue(ByteBuffer buf)
        {
            validateValue();

            int bitsToEncode = Java.Lang.Math.Max(minimumSize, value.Length());
            BitStream bitStream = new BitStream();
            for (int i = 0; i < bitsToEncode; i++)
            {
                bitStream.appendBit(value.Get(i));
            }

            buf.Put((sbyte)((8 - (value.Length() % 8)) % 8));
            buf.Put(bitStream.getPaddedBytes());
        }

        public override void decodeBerValue(ByteBuffer buf)
        {
            int unusedBits = buf.Get() & 0xFF;
            byte[] valueBytes = getRemaining(buf);
            int numBits = valueBytes.Length * 8 - unusedBits;
            value = new BitSet(numBits);
            BitStreamReader reader = new BitStreamReader(valueBytes);
            for (int i = 0; i < numBits; i++)
            {
                value.Set(i, reader.readBit());
            }
        }
         
        /**
         * Returns remaining bytes in the {@link ByteBuffer} in a newly allocated byte array of exactly
         * the right size. The ByteBuffer will be empty upon return.
         */
        static byte[] getRemaining(ByteBuffer buf)
        {
            byte[] bytes = new byte[buf.Remaining()];
            buf.Get(bytes);
            return bytes;
        }

        //private Iterable<BitStream> encodePerImpl(bool aligned)
        //{
        //    validateValue();
        //    if (maximumSize == null)
        //    {
        //        throw new Exception("unconstrained unimplemented");
        //    }

        //    if (minimumSize == maximumSize)
        //    {
        //        if (maximumSize == 0)
        //        {
        //            return ImmutableList.of();
        //        }
        //        if (maximumSize < PerAlignedUtils.SIXTYFOUR_K)
        //        {
        //            BitStream result = new BitStream();
        //            for (int i = 0; i < maximumSize; i++)
        //            {
        //                result.appendBit(value.get(i));
        //            }
        //            if (aligned && maximumSize > 16)
        //            {
        //                result.setBeginByteAligned();
        //            }
        //            return ImmutableList.of(result);
        //        }
        //        // Fall through to the general case.
        //    }

        //    if (maximumSize >= PerAlignedUtils.SIXTYFOUR_K)
        //    {
        //        throw new Exception("large set unimplemented");
        //    }

        //    int bitsToEncode = Math.max(minimumSize, value.length());
        //    BitStream count = null;
        //    if (aligned)
        //    {
        //        count = PerAlignedUtils.encodeSmallConstrainedWholeNumber(
        //            bitsToEncode, minimumSize, maximumSize);
        //    }
        //    else
        //    {
        //        count = PerUnalignedUtils.encodeConstrainedWholeNumber(
        //            bitsToEncode, minimumSize, maximumSize);
        //    }
        //    BitStream result = new BitStream();
        //    if (aligned)
        //    {
        //        result.setBeginByteAligned();
        //    }
        //    for (int i = 0; i < bitsToEncode; i++)
        //    {
        //        result.appendBit(value.get(i));
        //    }
        //    return ImmutableList.of(count, result);
        //}

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return encodePerImpl(false);
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return encodePerImpl(true);
        //}

        private void decodePerImpl(BitStreamReader reader, bool aligned)
        {
            value = new BitSet();
            if (maximumSize == null)
            {
                throw new System.Exception("unconstrained unimplemented");
            }

            if (minimumSize == maximumSize)
            {
                if (maximumSize == 0)
                {
                    return;
                }
                if (maximumSize < PerAlignedUtils.SIXTYFOUR_K)
                {
                    if (aligned && maximumSize > 16)
                    {
                        reader.spoolToByteBoundary();
                    }
                    for (int i = 0; i < maximumSize; i++)
                    {
                        value.Set(i, reader.readBit());
                    }
                    return;
                }
                // Fall through to the general case.
            }

            if (maximumSize >= PerAlignedUtils.SIXTYFOUR_K)
            {
                throw new System.Exception("large set unimplemented");
            }

            int length = 0;
            if (aligned)
            {
                length = PerAlignedUtils.decodeSmallConstrainedWholeNumber(
                    reader, minimumSize, maximumSize);
                reader.spoolToByteBoundary();
            }
            else
            {
                length = PerUnalignedUtils.decodeConstrainedWholeNumber(
                    reader, minimumSize, maximumSize);
            }
            for (int i = 0; i < length; i++)
            {
                value.Set(i, reader.readBit());
            }
        }

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            decodePerImpl(reader, false);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            decodePerImpl(reader, true);
        }

        public override IEnumerable<BitStream> encodePerAligned()
        {
            throw new NotImplementedException();
        }

        public override IEnumerable<BitStream> encodePerUnaligned()
        {
            throw new NotImplementedException();
        }
    }
}