﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using System; 
using System.Linq;
using System.Text;
using System.Collections.Generic;
using System.Collections.Immutable;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class PosTechnology : Asn1Sequence
    {

        private static readonly Asn1Tag TAG_PosTechnology
      = Asn1Tag.fromClassAndNumber(-1, -1);

        public PosTechnology() : base()
        {
        }

        override public Asn1Tag getTag()
        {
            return TAG_PosTechnology;
        }

        override public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_PosTechnology != null)
            {
                return Asn1Sequence.getPossibleFirstTags();
                //return ImmutableList.of(TAG_PosTechnology);
            }
            else
            {
                return Asn1Sequence.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new PosTechnology from encoded stream.
         */
        public static PosTechnology fromPerUnaligned(byte[] encodedBytes)
        {
            PosTechnology result = new PosTechnology();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new PosTechnology from encoded stream.
         */
        public static PosTechnology fromPerAligned(byte[] encodedBytes)
        {
            PosTechnology result = new PosTechnology();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }

        private PosTechnology.agpsSETassistedType agpsSETassisted_;
        public PosTechnology.agpsSETassistedType getAgpsSETassisted()
        {
            return agpsSETassisted_;
        }

        /**
        * @throws ClassCastException if value is not a PosTechnology.agpsSETassistedType
        */
        public void setAgpsSETassisted(Asn1Object value)
        {
            this.agpsSETassisted_ = (PosTechnology.agpsSETassistedType)value;
        }
        public PosTechnology.agpsSETassistedType setAgpsSETassistedToNewInstance()
        {
            agpsSETassisted_ = new PosTechnology.agpsSETassistedType();
            return agpsSETassisted_;
        }

        private PosTechnology.agpsSETBasedType agpsSETBased_;
        public PosTechnology.agpsSETBasedType getAgpsSETBased()
        {
            return agpsSETBased_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.agpsSETBasedType
         */
        public void setAgpsSETBased(Asn1Object value)
        {
            this.agpsSETBased_ = (PosTechnology.agpsSETBasedType)value;
        }
        public PosTechnology.agpsSETBasedType setAgpsSETBasedToNewInstance()
        {
            agpsSETBased_ = new PosTechnology.agpsSETBasedType();
            return agpsSETBased_;
        }

        private PosTechnology.autonomousGPSType autonomousGPS_;
        public PosTechnology.autonomousGPSType getAutonomousGPS()
        {
            return autonomousGPS_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.autonomousGPSType
         */
        public void setAutonomousGPS(Asn1Object value)
        {
            this.autonomousGPS_ = (PosTechnology.autonomousGPSType)value;
        }
        public PosTechnology.autonomousGPSType setAutonomousGPSToNewInstance()
        {
            autonomousGPS_ = new PosTechnology.autonomousGPSType();
            return autonomousGPS_;
        }

        private PosTechnology.aFLTType aFLT_;
        public PosTechnology.aFLTType getAFLT()
        {
            return aFLT_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.aFLTType
         */
        public void setAFLT(Asn1Object value)
        {
            this.aFLT_ = (PosTechnology.aFLTType)value;
        }
        public PosTechnology.aFLTType setAFLTToNewInstance()
        {
            aFLT_ = new PosTechnology.aFLTType();
            return aFLT_;
        }

        private PosTechnology.eCIDType eCID_;
        public PosTechnology.eCIDType getECID()
        {
            return eCID_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.eCIDType
         */
        public void setECID(Asn1Object value)
        {
            this.eCID_ = (PosTechnology.eCIDType)value;
        }
        public PosTechnology.eCIDType setECIDToNewInstance()
        {
            eCID_ = new PosTechnology.eCIDType();
            return eCID_;
        }

        private PosTechnology.eOTDType eOTD_;
        public PosTechnology.eOTDType getEOTD()
        {
            return eOTD_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.eOTDType
         */
        public void setEOTD(Asn1Object value)
        {
            this.eOTD_ = (PosTechnology.eOTDType)value;
        }
        public PosTechnology.eOTDType setEOTDToNewInstance()
        {
            eOTD_ = new PosTechnology.eOTDType();
            return eOTD_;
        }

        private PosTechnology.oTDOAType oTDOA_;
        public PosTechnology.oTDOAType getOTDOA()
        {
            return oTDOA_;
        }
        /**
         * @throws ClassCastException if value is not a PosTechnology.oTDOAType
         */
        public void setOTDOA(Asn1Object value)
        {
            this.oTDOA_ = (PosTechnology.oTDOAType)value;
        }
        public PosTechnology.oTDOAType setOTDOAToNewInstance()
        {
            oTDOA_ = new PosTechnology.oTDOAType();
            return oTDOA_;
        }



        private Ver2_PosTechnology_extension extensionVer2_PosTechnology_extension;
        public Ver2_PosTechnology_extension getExtensionVer2_PosTechnology_extension()
        {
            return extensionVer2_PosTechnology_extension;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_PosTechnology_extension
         */
        public void setExtensionVer2_PosTechnology_extension(Asn1Object value)
        {
            extensionVer2_PosTechnology_extension = (Ver2_PosTechnology_extension)value;
        }
        public void setExtensionVer2_PosTechnology_extensionToNewInstance()
        {
            extensionVer2_PosTechnology_extension = new Ver2_PosTechnology_extension();
        }

        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            builder.Add(new M3(this));
            builder.Add(new M4(this));
            builder.Add(new M5(this));
            builder.Add(new M6(this));
            builder.Add(new M7(this));
            builder.Add(new M8(this));
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            return builder.ToImmutable();
        }


        /**
         * 
         */
        public class agpsSETassistedType : Asn1Boolean
        {
  
            private static readonly Asn1Tag TAG_agpsSETassistedType
                  = Asn1Tag.fromClassAndNumber(-1, -1);

            public agpsSETassistedType() : base()
            { 
            }

            override public Asn1Tag getTag()
            {
                return TAG_agpsSETassistedType;
            }

            override public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_agpsSETassistedType != null)
                {
                    return Asn1Boolean.getPossibleFirstTags();
                    //return ImmutableList.of(TAG_agpsSETassistedType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new agpsSETassistedType from encoded stream.
             */
            public static agpsSETassistedType fromPerUnaligned(byte[] encodedBytes)
            {
                agpsSETassistedType result = new agpsSETassistedType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new agpsSETassistedType from encoded stream.
             */
            public static agpsSETassistedType fromPerAligned(byte[] encodedBytes)
            {
                agpsSETassistedType result = new agpsSETassistedType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }
            /*
            override public Iterable<BitStream> encodePerUnaligned()
            {
                return base.encodePerUnaligned();
            }

            override public Iterable<BitStream> encodePerAligned()
            {
                return base.encodePerAligned();
            }*/

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public string toString()
            {
                return toIndentedString("");
            }

            public string toIndentedString(string indent)
            {
                return "agpsSETassistedType = " + getValue() + ";\n";
            }
        }







        /**
         * 
         */
        public class agpsSETBasedType : Asn1Boolean
        {
  //

        private static readonly Asn1Tag TAG_agpsSETBasedType = Asn1Tag.fromClassAndNumber(-1, -1);

        public agpsSETBasedType() : base()
        {
        }

        override
        
  public Asn1Tag getTag()
        {
            return TAG_agpsSETBasedType;
        }

        override
  public bool isTagImplicit()
        {
            return true;
        }

        public static ImmutableList<Asn1Tag> getPossibleFirstTags()
        {
            if (TAG_agpsSETBasedType != null)
            {
                //return ImmutableList.of(TAG_agpsSETBasedType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
            else
            {
                return Asn1Boolean.getPossibleFirstTags();
            }
        }

        /**
         * Creates a new agpsSETBasedType from encoded stream.
         */
        public static agpsSETBasedType fromPerUnaligned(byte[] encodedBytes)
        {
            agpsSETBasedType result = new agpsSETBasedType();
            result.decodePerUnaligned(new BitStreamReader(encodedBytes));
            return result;
        }

        /**
         * Creates a new agpsSETBasedType from encoded stream.
         */
        public static agpsSETBasedType fromPerAligned(byte[] encodedBytes)
        {
            agpsSETBasedType result = new agpsSETBasedType();
            result.decodePerAligned(new BitStreamReader(encodedBytes));
            return result;
        }

        //override public Iterable<BitStream> encodePerUnaligned()
        //{
        //    return base.encodePerUnaligned();
        //}

        //override public Iterable<BitStream> encodePerAligned()
        //{
        //    return base.encodePerAligned();
        //}

        override public void decodePerUnaligned(BitStreamReader reader)
        {
            base.decodePerUnaligned(reader);
        }

        override public void decodePerAligned(BitStreamReader reader)
        {
            base.decodePerAligned(reader);
        }

        public String toString()
        {
            return toIndentedString("");
        }

        public String toIndentedString(String indent)
        {
            return "agpsSETBasedType = " + getValue() + ";\n";
        }
    }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class autonomousGPSType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_autonomousGPSType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public autonomousGPSType() : base()
            {
            }

            override

          public Asn1Tag getTag()
            {
                return TAG_autonomousGPSType;
            }

            override
          public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_autonomousGPSType != null)
                {
                    //return ImmutableList.of(TAG_autonomousGPSType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new autonomousGPSType from encoded stream.
             */
            public static autonomousGPSType fromPerUnaligned(byte[] encodedBytes)
            {
                autonomousGPSType result = new autonomousGPSType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new autonomousGPSType from encoded stream.
             */
            public static autonomousGPSType fromPerAligned(byte[] encodedBytes)
            {
                autonomousGPSType result = new autonomousGPSType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "autonomousGPSType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class aFLTType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_aFLTType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public aFLTType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_aFLTType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_aFLTType != null)
                {
                    //return ImmutableList.of(TAG_aFLTType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new aFLTType from encoded stream.
             */
            public static aFLTType fromPerUnaligned(byte[] encodedBytes)
            {
                aFLTType result = new aFLTType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new aFLTType from encoded stream.
             */
            public static aFLTType fromPerAligned(byte[] encodedBytes)
            {
                aFLTType result = new aFLTType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "aFLTType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class eCIDType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_eCIDType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public eCIDType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_eCIDType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_eCIDType != null)
                {
                    //return ImmutableList.of(TAG_eCIDType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new eCIDType from encoded stream.
             */
            public static eCIDType fromPerUnaligned(byte[] encodedBytes)
            {
                eCIDType result = new eCIDType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new eCIDType from encoded stream.
             */
            public static eCIDType fromPerAligned(byte[] encodedBytes)
            {
                eCIDType result = new eCIDType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "eCIDType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class eOTDType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_eOTDType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public eOTDType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_eOTDType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_eOTDType != null)
                {
                    return Asn1Boolean.getPossibleFirstTags();
                    //return ImmutableList.of(TAG_eOTDType);
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new eOTDType from encoded stream.
             */
            public static eOTDType fromPerUnaligned(byte[] encodedBytes)
            {
                eOTDType result = new eOTDType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new eOTDType from encoded stream.
             */
            public static eOTDType fromPerAligned(byte[] encodedBytes)
            {
                eOTDType result = new eOTDType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "eOTDType = " + getValue() + ";\n";
            }
        }


        // Copyright 2008 Google Inc. All Rights Reserved.
        /*
         * This class is AUTOMATICALLY GENERATED. Do NOT EDIT.
         */


        //

        /**
         * 
         */
        public class oTDOAType : Asn1Boolean
        {
            //

            private static readonly Asn1Tag TAG_oTDOAType
                = Asn1Tag.fromClassAndNumber(-1, -1);

            public oTDOAType() : base()
            {
            }

            override

              public Asn1Tag getTag()
            {
                return TAG_oTDOAType;
            }

            override
              public bool isTagImplicit()
            {
                return true;
            }

            public static ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (TAG_oTDOAType != null)
                {
                    //return ImmutableList.of(TAG_oTDOAType);
                    return Asn1Boolean.getPossibleFirstTags();
                }
                else
                {
                    return Asn1Boolean.getPossibleFirstTags();
                }
            }

            /**
             * Creates a new oTDOAType from encoded stream.
             */
            public static oTDOAType fromPerUnaligned(byte[] encodedBytes)
            {
                oTDOAType result = new oTDOAType();
                result.decodePerUnaligned(new BitStreamReader(encodedBytes));
                return result;
            }

            /**
             * Creates a new oTDOAType from encoded stream.
             */
            public static oTDOAType fromPerAligned(byte[] encodedBytes)
            {
                oTDOAType result = new oTDOAType();
                result.decodePerAligned(new BitStreamReader(encodedBytes));
                return result;
            }

            //override public Iterable<BitStream> encodePerUnaligned()
            //{
            //    return base.encodePerUnaligned();
            //}

            //override public Iterable<BitStream> encodePerAligned()
            //{
            //    return base.encodePerAligned();
            //}

            override public void decodePerUnaligned(BitStreamReader reader)
            {
                base.decodePerUnaligned(reader);
            }

            override public void decodePerAligned(BitStreamReader reader)
            {
                base.decodePerAligned(reader);
            }

            public String toString()
            {
                return toIndentedString("");
            }

            public String toIndentedString(String indent)
            {
                return "oTDOAType = " + getValue() + ";\n";
            }
        }


        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            PosTechnology objeto;
            public M1(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getAgpsSETassisted();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return ULP_PDU.lengthType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getAgpsSETassisted() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setAgpsSETassistedToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "agpsSETassisted : " + this.objeto.getAgpsSETassisted().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            PosTechnology objeto;
            public M2(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getAgpsSETBased();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.agpsSETBasedType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getAgpsSETBased() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setAgpsSETBasedToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "agpsSETBased : "
                    + this.objeto.getAgpsSETBased().toIndentedString(indent); 
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            PosTechnology objeto;
            public M3(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getAutonomousGPS();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.autonomousGPSType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getAutonomousGPS() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setAutonomousGPSToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "agpsSETBased : " + this.objeto.getAutonomousGPS().toIndentedString(indent);
            }
        }
        public class M4 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
            PosTechnology objeto;
            public M4(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getAFLT();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.aFLTType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getAFLT() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setAFLTToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "autonomousGPS : " + this.objeto.getAFLT().toIndentedString(indent);
            }
        }


        public class M5 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            PosTechnology objeto;
            public M5(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getECID();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return ULP_PDU.lengthType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getECID() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setECIDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "aFLT : " + this.objeto.getECID().toIndentedString(indent);
            }
        }

        public class M6 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            PosTechnology objeto;
            public M6(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getECID();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.eCIDType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getECID() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setECIDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "eCID : " + this.objeto.getECID().toIndentedString(indent);
            }
        }
        public class M7 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            PosTechnology objeto;
            public M7(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getEOTD();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.eOTDType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getEOTD() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setEOTDToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "eOTD : " + this.objeto.getEOTD().toIndentedString(indent);
            }
        }
        public class M8 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
            PosTechnology objeto;
            public M8(PosTechnology objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getOTDOA();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return PosTechnology.oTDOAType.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getOTDOA() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setOTDOAToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "oTDOA : " + this.objeto.getOTDOA().toIndentedString(indent);
            }
        }
















    }
}