﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using Java.Lang;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2
{
    public class SUPLSTART : Asn1Sequence
    {
        private static readonly Asn1Tag TAG_SUPLINIT = Asn1Tag.fromClassAndNumber(-1, -1);

        public SUPLSTART() : base()
        {
        }
        public override bool containsExtensionValues()
        {
            foreach (SequenceComponent extensionComponent in getExtensionComponents())
            {
                if (extensionComponent.isExplicitlySet()) return true;
            }
            return false;
        }

        protected override bool isExtensible()
        {
            return true;
        }
        private SETCapabilities sETCapabilities_;
        public SETCapabilities getSETCapabilities()
        {
            return sETCapabilities_;
        }
        /**
         * @throws ClassCastException if value is not a SETCapabilities
         */
        public void setSETCapabilities(Asn1Object value)
        {
            this.sETCapabilities_ = (SETCapabilities)value;
        }
        public SETCapabilities setSETCapabilitiesToNewInstance()
        {
            sETCapabilities_ = new SETCapabilities();
            return sETCapabilities_;
        }

        private LocationId locationId_;
        public LocationId getLocationId()
        {
            return locationId_;
        }
        /**
         * @throws ClassCastException if value is not a LocationId
         */
        public void setLocationId(Asn1Object value)
        {
            this.locationId_ = (LocationId)value;
        }
        public LocationId setLocationIdToNewInstance()
        {
            locationId_ = new LocationId();
            return locationId_;
        }

        private QoP qoP_;
        public QoP getQoP()
        {
            return qoP_;
        }
        /**
         * @throws ClassCastException if value is not a QoP
         */
        public void setQoP(Asn1Object value)
        {
            this.qoP_ = (QoP)value;
        }
        public QoP setQoPToNewInstance()
        {
            qoP_ = new QoP();
            return qoP_;
        }

        private Ver2_SUPL_START_extension extensionVer2_SUPL_START_extension;
        public Ver2_SUPL_START_extension getExtensionVer2_SUPL_START_extension()
        {
            return extensionVer2_SUPL_START_extension;
        }
        /**
         * @throws ClassCastException if value is not a Ver2_SUPL_START_extension
         */
        public void setExtensionVer2_SUPL_START_extension(Asn1Object value)
        {
            extensionVer2_SUPL_START_extension = (Ver2_SUPL_START_extension)value;
        }
        public void setExtensionVer2_SUPL_START_extensionToNewInstance()
        {
            extensionVer2_SUPL_START_extension = new Ver2_SUPL_START_extension();
        }


        protected override IEnumerable<SequenceComponent> getComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M1(this));
            builder.Add(new M2(this));
            //builder.Add(new M3(this)); 
            return builder.ToImmutable();
        }

        protected override IEnumerable<SequenceComponent> getExtensionComponents()
        {
            ImmutableList<SequenceComponent>.Builder builder = ImmutableList.CreateBuilder<SequenceComponent>();
            builder.Add(new M4(this));
            return builder.ToImmutable();
        }
        public class M1 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 0);
            SUPLSTART objeto;
            public M1(SUPLSTART objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getSETCapabilities();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return SETCapabilities.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getSETCapabilities() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setSETCapabilitiesToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "sETCapabilities : " + this.objeto.getSETCapabilities().toIndentedString(indent);
            }
        }

        public class M2 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 1);
            SUPLSTART objeto;
            public M2(SUPLSTART objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getLocationId();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return LocationId.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getLocationId() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setLocationIdToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "locationId : " + this.objeto.getLocationId().toIndentedString(indent);
            }
        }
        public class M3 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 2);
            SUPLSTART objeto;
            public M3(SUPLSTART objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getQoP();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                if (tag == null)
                {
                    return QoP.getPossibleFirstTags();
                }
                else
                {
                    ImmutableList<Asn1Tag>.Builder listBuilder = ImmutableList.CreateBuilder<Asn1Tag>();
                    listBuilder.Add(tag);
                    return listBuilder.ToImmutable();
                }
            }

            public Asn1Tag getTag()
            {
                return tag;
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getQoP() != null;
            }

            public bool isImplicitTagging()
            {
                return true;
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setQoPToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "qoP : " + this.objeto.getQoP().toIndentedString(indent);
            }
        }
        public class M4 : SequenceComponent
        {
            Asn1Tag tag = Asn1Tag.fromClassAndNumber(2, 3);
            SUPLSTART objeto;
            public M4(SUPLSTART objeto)
            {
                this.objeto = objeto;
            }
            public Asn1Object getComponentValue()
            {
                return this.objeto.getExtensionVer2_SUPL_START_extension();
            }

            public ImmutableList<Asn1Tag> getPossibleFirstTags()
            {
                throw new UnsupportedOperationException(
                    "BER decoding not supported for extension elements");
            }

            public Asn1Tag getTag()
            {
                throw new UnsupportedOperationException(
                    "BER is not supported for extension elements");
            }

            public bool hasDefaultValue()
            {
                return false;
            }

            public bool isExplicitlySet()
            {
                return this.objeto.getExtensionVer2_SUPL_START_extension() != null;
            }

            public bool isImplicitTagging()
            {
                throw new UnsupportedOperationException(
                    "BER is not supported for extension elements");
            }

            public bool isOptional()
            {
                return false;
            }

            public void setToNewInstance()
            {
                this.objeto.setExtensionVer2_SUPL_START_extensionToNewInstance();
            }

            public string toIndentedString(string indent)
            {
                return "ver2_SUPL_START_extension : " + this.objeto.getExtensionVer2_SUPL_START_extension().toIndentedString(indent);
            }
        }



    }
}