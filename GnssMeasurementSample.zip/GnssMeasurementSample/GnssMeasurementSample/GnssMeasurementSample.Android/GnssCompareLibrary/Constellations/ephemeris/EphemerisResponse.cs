﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris
{
    public class EphemerisResponse
    {
        /* A list of ephemeris for GNSS satellites */
        public readonly List<GnssEphemeris> ephList;

        /* The parameters of the ionospheric model */
        //public readonly IonosphericModelProto ionoProto;

        /* Constructor */
        public EphemerisResponse(List<GnssEphemeris> ephList/*, IonosphericModelProto ionoProto*/)
        {
            this.ephList = ephList;
            //this.ionoProto = ionoProto;
        }
    }
}