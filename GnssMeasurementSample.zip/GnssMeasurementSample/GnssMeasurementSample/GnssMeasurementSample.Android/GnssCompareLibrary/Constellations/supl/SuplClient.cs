﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using Java.Net;
using Java.Util.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public abstract class SuplClient
    {
        private static readonly Logger logger = Logger.GetLogger("SuplClient");

        protected readonly SuplConnectionRequest request;

        public SuplClient(SuplConnectionRequest request)
        {
            this.request = request;
        }

        /**
         * Applies the SUPL protocol call flow to obtain the assistance data and store the result in
         * {@link EphemerisResponse}.
         *
         * <p>A null will be returned if Supl communication fails or if parsing the received message
         * fails.
         */
        public EphemerisResponse generateSuplResult(long latE7, long lngE7)
        {
            try
            {
                SUPLPOS message = sendSuplRequest(latE7, lngE7);
                return message != null ? suplPosToEphResponse(message) : null;
            }
            catch (Exception e)
            {
                //e.printStackTrace();
                return null;
            }
        }

        protected abstract SuplMessagesGenerator getSuplMessagesGenerator();

        protected abstract void validateAssistanceData(SUPLPOS var1);

        protected abstract EphemerisResponse suplPosToEphResponse(SUPLPOS var1);

        public SUPLPOS sendSuplRequest(long latE7, long lngE7)
        {
            try
            {
                SuplTcpConnection tcpClient = new SuplTcpConnection(this.request);
                SuplMessagesGenerator messagesGenerator = this.getSuplMessagesGenerator();
                ULP_PDU suplStartMessage = messagesGenerator.newSuplStartMessage((InetAddress)null);
                tcpClient.sendSuplRequest(messagesGenerator.encodeUlp(suplStartMessage));

                this.logMessage("SUPL START sent to server", suplStartMessage);
                byte[] response = tcpClient.getSuplResponse();
                Preconditions.CheckNotNull(response, "SUPL Response null");
                ULP_PDU suplResponseMessage = ULP_PDU.fromPerUnaligned(response);
                Preconditions.CheckState(suplResponseMessage.getMessage().isMsSUPLRESPONSE());

                this.logMessage("SUPL RESPONSE received from server", suplResponseMessage);
                SessionID sessionId = suplResponseMessage.getSessionID();
                ULP_PDU suplPosInitMessage = messagesGenerator.newSuplPosInitMessage(sessionId, latE7, lngE7);
                tcpClient.sendSuplRequest(messagesGenerator.encodeUlp(suplPosInitMessage));

                this.logMessage("SUPL POS INIT sent to server", suplPosInitMessage);
                response = tcpClient.getSuplResponse();
                Preconditions.CheckNotNull(response, "SUPL POS null");
                ULP_PDU suplPosMessage = ULP_PDU.fromPerUnaligned(response);
                Preconditions.CheckState(suplPosMessage.getMessage().isMsSUPLPOS());

                this.logMessage("SUPL POS received from server", suplPosMessage);
                SUPLPOS suplPos = suplPosMessage.getMessage().getMsSUPLPOS();
                this.validateAssistanceData(suplPos);
                ULP_PDU posAckMessage = messagesGenerator.newSuplPosAckMessage(sessionId);
                tcpClient.sendSuplRequest(messagesGenerator.encodeUlp(posAckMessage));

                this.logMessage("SUPL POS ACK sent to server", posAckMessage);
                response = tcpClient.getSuplResponse();
                Preconditions.CheckNotNull(response, "SUPL END null");
                ULP_PDU suplEndMessage = ULP_PDU.fromPerUnaligned(response);
                if (!suplEndMessage.getMessage().isMsSUPLEND())
                {
                    logger.Info("Unexpected message...Ignored.\n" + suplEndMessage);
                }
                else
                {
                    this.logMessage("SUPL END received from server", suplEndMessage);
                }

                logger.Info("SUPL Script finished successfully!");
                tcpClient.closeSocket();
                return suplPos;
            }
            catch (Exception var16)
            {
                logger.Warning("SUPL Script failed.");
                //var16.printStackTrace();
                return null;
            }
        }

        private void logMessage(String log, ULP_PDU message)
        {
            if (request.isMessageLoggingEnabled())
            {
                logger.Info(log + "Message: \n" + message);
            }
            else if (request.isLoggingEnabled())
            {
                logger.Info(log);
            }
        }

    }
}