﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplController
    {
        private readonly SuplClient client;
        //Google.Protobuf.Collections.Lists
        public SuplController(SuplConnectionRequest request)
        {
            this.client = new SuplLppClient(request);
        }


        ///**
        // * Applies the SUPL protocol call flow to obtain the assistance data and store the result in
        // * {@link EphemerisResponse}.
        // */
        public EphemerisResponse generateEphResponse(long latE7, long lngE7)
        {
            return client.generateSuplResult(latE7, lngE7);
        }

        ///** Sends a new SUPL request for the provided lat/lng pair. */
        public void sendSuplRequest(long latE7, long lngE7)
        {
            client.sendSuplRequest(latE7, lngE7);
        }
    }
}