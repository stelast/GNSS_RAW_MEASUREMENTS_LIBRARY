﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static Android.Resource;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplConstants
    {

        /** A container for constants defined in the Userplane Location Protocol (ULP) v2.1 protocol */
        static class UlpConstants
        {
            // Scale factors used for conversion from latitude and longitude in SUPL protocol format
            // to decimal format
            static readonly double POSITION_ESTIMATE_LAT_SCALE_FACTOR = 90.0 / 8388608.0;
            static readonly double POSITION_ESTIMATE_LNG_SCALE_FACTOR = 180.0 / 8388608.0;

            // Supl GANSS IDs for GAL GLO constellations
            static readonly int ULP_GANSS_ID_GAL = 0;
            static readonly int ULP_GANSS_ID_GLO = 4;
        }

        /** A container for constants defined in the LPP v14.4.0 protocol (3GPP TS 36.355) */
        static class LppConstants
        {
            static readonly int LPP_GLO_IOD_SCALE_FACTOR = 15;
        }

        /** A container for Google SUPL server related constants */
        public static class SuplServerConstants
        {
            public static readonly List<int> SSL_PORTS = new List<int> { 7275, 7279};
            public static readonly List<int> NON_SSL_PORTS = new List<int> { 7276, 7280 };
            //static readonly ImmutableSet<Integer> SSL_PORTS =
            //    ImmutableSet.of(7275 /* SSL_PROD_PORT */, 7279 /* SSL_DEV_PORT */);
            //static readonly ImmutableSet<Integer> NON_SSL_PORTS =
            //    ImmutableSet.of(7276 /* NON_SSL_PROD_PORT */, 7280 /* NON_SSL_DEV_PORT */);
        }

        /** A container for constants that are commonly used by all GNSS constellations */
        static class GnssConstants
        {
            /** The number of meters in one kilometer */
            public static readonly int METERS_PER_KM = 1000;
        }

        /**
         * A container for all scale factors used in GNSS binary navigation message decoding, and SUPL
         * message decoding
         */
        static class ScaleFactors
        {
            // Details of the following constants can be found in hte IS-GPS-200F which can be found at:
            // http://www.navcen.uscg.gov/pdf/is-gps-200f.pdf.
            public static readonly double GPS_NAV_TGD = Math.Pow(2, -31);
            public static readonly double GPS_NAV_TOC = Math.Pow(2, 4);
            public static readonly double GPS_NAV_AF2 = Math.Pow(2, -55);
            public static readonly double GPS_NAV_AF1 = Math.Pow(2, -43);
            public static readonly double GPS_NAV_AF0 = Math.Pow(2, -31);
            public static readonly double GPS_NAV_CRS = Math.Pow(2, -5);
            public static readonly double GPS_NAV_DELTA_N = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double GPS_NAV_M0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GPS_NAV_CUC = Math.Pow(2, -29);
            public static readonly double GPS_NAV_E = Math.Pow(2, -33);
            public static readonly double GPS_NAV_CUS = Math.Pow(2, -29);
            public static readonly double GPS_NAV_A_POWER_HALF = Math.Pow(2, -19);
            public static readonly double GPS_NAV_TOE = Math.Pow(2, 4);
            public static readonly double GPS_NAV_CIC = Math.Pow(2, -29);
            public static readonly double GPS_NAV_OMEGA0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GPS_NAV_CIS = Math.Pow(2, -29);
            public static readonly double GPS_NAV_I0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GPS_NAV_CRC = Math.Pow(2, -5);
            public static readonly double GPS_NAV_W = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GPS_NAV_OMEGA_A_DOT = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double GPS_NAV_I_DOT = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double IONO_ALFA_0 = Math.Pow(2, -30);
            public static readonly double IONO_ALFA_1 = Math.Pow(2, -27);
            public static readonly double IONO_ALFA_2 = Math.Pow(2, -24);
            public static readonly double IONO_ALFA_3 = Math.Pow(2, -24);
            public static readonly double IONO_BETA_0 = Math.Pow(2, 11);
            public static readonly double IONO_BETA_1 = Math.Pow(2, 14);
            public static readonly double IONO_BETA_2 = Math.Pow(2, 16);
            public static readonly double IONO_BETA_3 = Math.Pow(2, 16);

            // Details of the following constants can be found in the GLONASS_ICD_5_1_EN protocol:
            // http://gauss.gge.unb.ca/GLONASS.ICD.pdf.
            public static readonly double GLO_CLK_TAU = Math.Pow(2, -30);
            public static readonly double GLO_CLK_GAMMA = Math.Pow(2, -40);
            public static readonly double GLO_ORB_POS_KM = Math.Pow(2, -11);
            public static readonly double GLO_ORB_VEL_KMPS = Math.Pow(2, -20);
            public static readonly double GLO_ORB_ACCELERATION_KMPS2 = Math.Pow(2, -30);
            // Details of the following constants can be found in the Galileo ICD issue 1.3, 2016:
            // https://www.gsc-europa.eu/system/files/galileo_documents/Galileo-OS-SIS-ICD.pdf
            public static readonly double GAL_NAV_TOE = 60;
            public static readonly double GAL_NAV_W = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GAL_NAV_DELTA_N = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double GAL_NAV_M0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GAL_NAV_OMEGA_DOT = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double GAL_NAV_E = Math.Pow(2, -33);
            public static readonly double GAL_NAV_I_DOT = Java.Lang.Math.Scalb(Math.PI, -43);
            public static readonly double GAL_NAV_SQRT_A = Math.Pow(2, -19);
            public static readonly double GAL_NAV_I0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GAL_NAV_OMEGA0 = Java.Lang.Math.Scalb(Math.PI, -31);
            public static readonly double GAL_NAV_CRS = Math.Pow(2, -5);
            public static readonly double GAL_NAV_CIS = Math.Pow(2, -29);
            public static readonly double GAL_NAV_CUS = Math.Pow(2, -29);
            public static readonly double GAL_NAV_CRC = Math.Pow(2, -5);
            public static readonly double GAL_NAV_CIC = Math.Pow(2, -29);
            public static readonly double GAL_NAV_CUC = Math.Pow(2, -29);
            public static readonly double GAL_CLK_AF0 = Math.Pow(2, -34);
            public static readonly double GAL_CLK_AF1 = Math.Pow(2, -46);
            public static readonly double GAL_CLK_AF2 = Math.Pow(2, -59);
            public static readonly double GAL_CLK_TGD = Math.Pow(2, -32);
            public static readonly double GAL_CLK_TOC = 60;
        }
    }
}