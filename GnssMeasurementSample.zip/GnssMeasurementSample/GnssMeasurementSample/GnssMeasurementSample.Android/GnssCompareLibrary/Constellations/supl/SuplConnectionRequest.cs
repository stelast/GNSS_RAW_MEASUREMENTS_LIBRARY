﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplConnectionRequest
    {
        public string serverHost;
        public int serverPort;
        public bool sslEnabled;
        public bool logginEnabled;
        public bool messageLoggingENabled;

        public SuplConnectionRequest()
        {
        }
        public SuplConnectionRequest(string serverHost, int serverPort, bool sslEnabled, bool logginEnabled, bool messageLoggingENabled)
        {
            this.serverHost = serverHost;
            this.serverPort = serverPort;
            this.sslEnabled = sslEnabled;
            this.logginEnabled = logginEnabled;
            this.messageLoggingENabled = messageLoggingENabled;
        }

        public string getServerHost() {
            return this.serverHost;
        }

        public int getServerPort()
        {
            return this.serverPort;
        }

        public bool isSslEnabled()
        {
            return this.sslEnabled;
        }

        public bool isLoggingEnabled()
        {
            return this.logginEnabled;
        }

        public bool isMessageLoggingEnabled()
        {
            return this.messageLoggingENabled;
        }

        public static SuplConnectionRequest.Builder builder()
        {
            return (new Builder()).setMessageLoggingEnabled(false).setLoggingEnabled(false).setSslEnabled(false);
        }

        public class Builder
        {
            string serverHost;
            int serverPort;
            bool sslEnabled;
            bool logginEnabled;
            bool messageLoggingENabled;

            public Builder()
            {
            }

            public SuplConnectionRequest.Builder setServerHost(string var1)
            {
                this.serverHost = var1;
                return this;
            }

            public SuplConnectionRequest.Builder setServerPort(int var1)
            {
                this.serverPort = var1;
                return this;
            }

            public SuplConnectionRequest.Builder setSslEnabled(bool var1)
            {
                this.sslEnabled = var1;
                return this;
            }

            public SuplConnectionRequest.Builder setLoggingEnabled(bool var1)
            {
                this.logginEnabled = var1;
                return this;
            }

            public SuplConnectionRequest.Builder setMessageLoggingEnabled(bool var1)
            {
                this.messageLoggingENabled = var1;
                return this;
            }

            public SuplConnectionRequest build()
            {
                return new SuplConnectionRequest(serverHost, serverPort, sslEnabled, logginEnabled, messageLoggingENabled);
            }
        }
    }
}