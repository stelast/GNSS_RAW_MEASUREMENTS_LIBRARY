﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplTester
    {

        private static readonly String serverHost = "supl.google.com";

        private static readonly int serverPort = 7275;

        private static readonly bool sslEnabled = true;

        private static readonly bool messageLoggingEnabled = true;

        private static readonly bool loggingEnabled = true;

        private static readonly long latE7 = 374220030;

        private static readonly long lngE7 = -1220841890;
        /*
        public static void main(String[] args) throws Exception
        {
            SuplTester tester = new SuplTester();
            tester.runStepByStepTcpClientTest();
        }*/

        /** Step by step test of the supl client */
        private void runStepByStepTcpClientTest()
        {
            SuplConnectionRequest request =
                SuplConnectionRequest.builder()
                    .setServerHost(serverHost)
                    .setServerPort(serverPort)
                    .setSslEnabled(sslEnabled)
                    .setMessageLoggingEnabled(messageLoggingEnabled)
                    .setLoggingEnabled(loggingEnabled)
                    .build();
            SuplController suplController = new SuplController(request);
            // Try to call methods to access SUPL server and see if they report any exception
            suplController.sendSuplRequest(latE7, lngE7);
            EphemerisResponse ephResponse = suplController.generateEphResponse(latE7, lngE7);
        }
    }
}