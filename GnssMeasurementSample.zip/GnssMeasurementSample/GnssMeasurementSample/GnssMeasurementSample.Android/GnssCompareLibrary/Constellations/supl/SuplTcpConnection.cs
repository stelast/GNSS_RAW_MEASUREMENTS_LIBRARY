﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Util;
using Android.Views;
using Android.Widget;
using Java.IO;
using Java.Net;
using Java.Nio;
using Java.Util.Concurrent;
using Java.Util.Logging;
using Javax.Net.Ssl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplTcpConnection
    {

        private static readonly Logger logger = Logger.GetLogger("SuplTcpConnection");
        private static readonly int READ_TIMEOUT_MILLIS = (int)TimeUnit.Seconds.ToMillis(10);
        private static readonly short HEADER_SIZE = 2;
        /** BUFFER_SIZE data size that is enough to hold SUPL responses */
        private static readonly int RESPONSE_BUFFER_SIZE = 16384;

        private readonly ByteBuffer messageLengthReadBuffer =
        ByteBuffer.Allocate(2).Order(ByteOrder.BigEndian);

        private Socket socket;
        private BufferedInputStream bufferedInputStream;

        public SuplTcpConnection(SuplConnectionRequest request) /*throws UnknownHostException, IOException*/ {
            socket = createSocket(request);
            socket.SoTimeout = READ_TIMEOUT_MILLIS;
            socket.ReceiveBufferSize = RESPONSE_BUFFER_SIZE;
            bufferedInputStream = new BufferedInputStream(socket.InputStream);

            Log.Debug("SuplTcpConnection","Connection established to " + socket.OutputStream);
            //System.out.println("Connection established to " + socket.getOutputStream());
        }

        /** Sends a byte array of SUPL data to the server */
        public void sendSuplRequest(byte[] data) /*throws IOException*/
        {
            socket.OutputStream.Write(data);
        }

        /**
         * Reads SUPL server response and returns it as a byte array.
         *
         * <p>Upon the SUPL protocol, the size of the payload is stored in the first two bytes of the
         * response, hence these two bytes are read first followed by reading a payload of that size. Null
         * is returned if the size of the payload is not readable.
         */
        public byte[] getSuplResponse() /*throws IOException*/
        {
            byte[]  buffer = new byte[RESPONSE_BUFFER_SIZE];
            int sizeOfRead = bufferedInputStream.Read(buffer, 0, HEADER_SIZE);
            if (sizeOfRead == HEADER_SIZE) {
                  messageLengthReadBuffer.Clear();
                  messageLengthReadBuffer.Put(0, (sbyte)buffer[0]);
                  messageLengthReadBuffer.Put(1, (sbyte)buffer[1]);
                  int messageLength = messageLengthReadBuffer.Short;

                int bytesRead = sizeOfRead;
                  while (bytesRead<messageLength) {
                    sizeOfRead = bufferedInputStream.Read(buffer, bytesRead, messageLength - bytesRead);
                    Preconditions.CheckState(
                        sizeOfRead != -1,
                        "Expected length of the messagte in bytes = "
                            + messageLength
                            + " while total number of bytes received = "
                            + bytesRead);
                    bytesRead = bytesRead + sizeOfRead;
                  }
                //return Array.Copy(buffer, messageLength);
                //return (byte[])buffer.Clone();
                return buffer;
            } else
            {
                return null;
            }
          }

          /** Closes the TCP socket */
          public void closeSocket() /*throws IOException*/
        {
            socket.Close();
        }

        private static Socket createSocket(SuplConnectionRequest request) /*throws IOException*/
        {
            String host = request.getServerHost();
            int port = request.getServerPort();
            logger.Info("Connecting to " + host + " on port " + port);

            if (request.isSslEnabled()) {
                Preconditions.CheckState(
                    SuplConstants.SuplServerConstants.SSL_PORTS.Contains(port),
                    "An SSL connection is requested on a non SSL port, this should not happen.");
                SSLSocketFactory factory = (SSLSocketFactory)SSLSocketFactory.Default;
                SSLSocket sslSocket = (SSLSocket)factory.CreateSocket(host, port);
                sslSocket.StartHandshake();
                return sslSocket;
            } else {
                Preconditions.CheckState(
                    SuplConstants.SuplServerConstants.NON_SSL_PORTS.Contains(port),
                    "A NON-SSL connection is requested on an SSL port, this should not happen.");
                return new Socket(host, port);
            }
        }
    }
}