﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using Java.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplLppMessagesGenerator : SuplMessagesGenerator
    {
        public SuplLppMessagesGenerator() { }

        public override ULP_PDU newSuplPosAckMessage(SessionID sessionId)
        {
            throw new NotImplementedException();
        }
        public ULP_PDU newSuplStartMessage(int mcc, int mnc, int uc, InetAddress ipAddress)
        {
            ULP_PDU ulpPdu = base.newSuplStartMessage(mcc, mnc, uc, ipAddress);
            //this.requestLppCapability(ulpPdu.getMessage().getMsSUPLSTART());
            return ulpPdu;
        }
    }
}