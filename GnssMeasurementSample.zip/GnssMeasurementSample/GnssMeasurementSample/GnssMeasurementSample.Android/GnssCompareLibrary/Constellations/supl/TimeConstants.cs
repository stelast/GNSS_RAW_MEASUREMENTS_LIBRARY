﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class TimeConstants
    {
        public static readonly int DAYS_PER_WEEK = 7;
        public static readonly int SECONDS_PER_HOUR = 3600;
        public static readonly int HOURS_PER_DAY = 24;
        public static readonly int SECONDS_PER_DAY = HOURS_PER_DAY * SECONDS_PER_HOUR;
        public static readonly int MILLIS_PER_SECOND = 1000;
        public static readonly long MILLIS_PER_DAY = SECONDS_PER_DAY * MILLIS_PER_SECOND;

        public static readonly int MOSCOW_UTC_TIME_OFFSET_HOURS = 3;

        /**
         * The number of milliseconds from the GPS epoch to the UTC epoch
         *
         * <p>This is a normal delta, with no leap seconds considered.
         */
        public static readonly long GPS_UTC_EPOCHS_OFFSET_MILLIS = 315964800000L;

        /** The number of weeks from the Galileo epoch to the GPS epoch */
        public static readonly int GAL_GPS_EPOCHS_OFFSET_WEEKS = 1024;

        /**
         * All leap seconds occurred are listed here. Newly occurred leap second should be appended to
         * this list.
         */
        public static readonly ImmutableList<DateTime> LEAP_SECOND_LIST = ImmutableList.Create<DateTime>(
                new DateTime(1982, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1982, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1983, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1985, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1988, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1990, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1991, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1992, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1993, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1994, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1996, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1997, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(1999, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(2006, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(2009, 1, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(2012, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(2015, 7, 1, 0, 0, 0, DateTimeKind.Utc),
                new DateTime(2017, 1, 1, 0, 0, 0, DateTimeKind.Utc)
            ); 
    }
}