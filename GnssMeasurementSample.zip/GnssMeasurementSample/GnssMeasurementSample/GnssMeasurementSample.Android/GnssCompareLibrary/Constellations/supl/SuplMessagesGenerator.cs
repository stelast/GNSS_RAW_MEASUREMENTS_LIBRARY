﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V4.Util;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.mybase;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using Java.Math;
using Java.Net;
using Java.Nio;
using Java.Util;
using Java.Util.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Version = GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2.Version;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public abstract class SuplMessagesGenerator
    {
        private static readonly Logger logger = Logger.GetLogger("SuplMessagesGenerator");

        public SuplMessagesGenerator()
        {
        }

        public ULP_PDU newSuplStartMessage(int mcc, int mnc, int uc, InetAddress ipAddress)
        {
            UlpMessage message = this.newSuplStartMessage();
            LocationId locationId = message.getMsSUPLSTART().setLocationIdToNewInstance();
            CellInfo cellInfo = locationId.setCellInfoToNewInstance();
            //WcdmaCellInformation wcdmaCellInfo = cellInfo.setWcdmaCellToNewInstance();
            //wcdmaCellInfo.setRefMCCToNewInstance().setInteger(BigInteger.ValueOf((long)mcc));
            //wcdmaCellInfo.setRefMNCToNewInstance().setInteger(BigInteger.ValueOf((long)mnc));
            //wcdmaCellInfo.setRefUCToNewInstance().setInteger(BigInteger.ValueOf((long)uc));
            //locationId.setStatusToNewInstance().setValue(Value.current);
            return this.createUlpPdu(message, ipAddress);
        }

        protected ULP_PDU createUlpPdu(UlpMessage message, SessionID sessionId)
        { 
            return this.createUlpPdu(message, sessionId, (InetAddress)null);
        }

        protected ULP_PDU createUlpPdu(UlpMessage message, InetAddress ipAddress)
        { 
            return this.createUlpPdu(message, (SessionID)null, ipAddress);
        }

        protected ULP_PDU createUlpPdu(
            UlpMessage message, SessionID sessionId, InetAddress ipAddress)
        {
            ULP_PDU ulpPdu = new ULP_PDU();
            ulpPdu.setMessage(message);

            // Set the version of SUPL protocol
            // V2.1 or above is required for GLONASS assistance data
            Version version = ulpPdu.setVersionToNewInstance();
            version.setMajToNewInstance().setLong(2);
            version.setMinToNewInstance().setLong(1);
            version.setServindToNewInstance().setInteger(BigInteger.Zero);
            ulpPdu.setVersion(version);

            if (sessionId == null)
            {
                sessionId = ulpPdu.setSessionIDToNewInstance();

                SetSessionID setSessionId = sessionId.setSetSessionIDToNewInstance();
                setSessionId
                    .setSessionIdToNewInstance()
                    .setInteger(BigInteger.ValueOf(new Java.Util.Random().NextInt(65536)));
                if (ipAddress == null)
                {
                    try
                    {
                        ipAddress = InetAddress.LocalHost;
                    }
                    catch (UnknownHostException e)
                    {
                        throw new SystemException();
                    }
                }
                byte[] ipAsbytes = ipAddress.GetAddress();
                setSessionId
                    .setSetIdToNewInstance()
                    .setIPAddressToNewInstance()
                    .setIpv4AddressToNewInstance()
                    .setValue(ipAsbytes);
            }
            ulpPdu.setSessionID(sessionId);

            return ulpPdu;
        }


        private UlpMessage newSuplStartMessage()
        {
            UlpMessage message = new UlpMessage();
            SUPLSTART suplStart = message.setMsSUPLSTARTToNewInstance();
            SETCapabilities setCapabilities = suplStart.setSETCapabilitiesToNewInstance();
            PosTechnology posTechnology = setCapabilities.setPosTechnologyToNewInstance();
            posTechnology.setAgpsSETassistedToNewInstance().setValue(false);
            posTechnology.setAgpsSETBasedToNewInstance().setValue(true);
            posTechnology.setAutonomousGPSToNewInstance().setValue(true);
            posTechnology.setAFLTToNewInstance().setValue(false);
            posTechnology.setECIDToNewInstance().setValue(false);
            posTechnology.setEOTDToNewInstance().setValue(false);
            posTechnology.setOTDOAToNewInstance().setValue(false);

            setCapabilities.setPrefMethodToNewInstance().setValue(new PrefMethod.Value(PrefMethod.Value.ValueEnum.agpsSETBasedPreferred) /*PrefMethod.Value.agpsSETBasedPreferred*/);

            PosProtocol posProtocol = setCapabilities.setPosProtocolToNewInstance();
            posProtocol.setTia801ToNewInstance().setValue(false);
            posProtocol.setRrlpToNewInstance().setValue(true);
            posProtocol.setRrcToNewInstance().setValue(false);

            Ver2_PosProtocol_extension extension = new Ver2_PosProtocol_extension();
            posProtocol.setExtensionVer2_PosProtocol_extension(extension);
            extension.setLppToNewInstance().setValue(false);

            PosProtocolVersion3GPP lppVersion = extension.setPosProtocolVersionLPPToNewInstance();
            // The LPP version must be no less than 12, for the correctness of Galileo assistance data.
            lppVersion.setMajorVersionFieldToNewInstance().setLong(14);
            lppVersion.setTechnicalVersionFieldToNewInstance().setLong(1);
            lppVersion.setEditorialVersionFieldToNewInstance().setLong(0);

            PosProtocolVersion3GPP rrlpVersion = extension.setPosProtocolVersionRRLPToNewInstance();
            // The RRLP version must be no less than 12, for the correctness of Galileo assistance data.
            rrlpVersion.setMajorVersionFieldToNewInstance().setLong(14);
            rrlpVersion.setTechnicalVersionFieldToNewInstance().setLong(1);
            rrlpVersion.setEditorialVersionFieldToNewInstance().setLong(0);

            return message;
        }



        public ULP_PDU newSuplStartMessage(InetAddress ipAddress)/* throws Exception*/
        {
            UlpMessage message = this.newSuplStartMessage();
            LocationId locationId = message.getMsSUPLSTART().setLocationIdToNewInstance();
            CellInfo cellInfo = locationId.setCellInfoToNewInstance();
            cellInfo.setExtensionVer2_CellInfo_extensionToNewInstance();
            String macBinary = "111111111111111111111111111111111111111111111111";
            BitSet bits = new BitSet("111111111111111111111111111111111111111111111111".Count());

            for(int i = 0; i< "111111111111111111111111111111111111111111111111".Count(); ++i) {
                if ("111111111111111111111111111111111111111111111111"[i] == '1') {
                    bits.Set(i);
                }
            }

            cellInfo.getExtensionVer2_CellInfo_extension().setWlanAPToNewInstance().setApMACAddressToNewInstance().setValue(bits);
            locationId.setStatusToNewInstance().setValue(new Status.Value(Status.Value.ValueEnum.current));
            return this.createUlpPdu(message, ipAddress);
        }


        /** Encodes a ULP_PDU message into bytes and sets the length field. */
        public byte[] encodeUlp(ULP_PDU message)
        { 
            //logger.Info("Encoding ULP \n" + message);
            message.setLengthToNewInstance();
            message.getLength().setInteger(BigInteger.Zero);
            PacketBuilder messageBuilder = new PacketBuilder();
            messageBuilder.appendAll(message.encodePerUnaligned());
            byte[] result = messageBuilder.getPaddedBytes();
            ByteBuffer buffer = ByteBuffer.Wrap(result);
            buffer.Order(ByteOrder.BigEndian);
            buffer.PutShort((short)result.Count());

            byte[] arr = new byte[buffer.Remaining()];
            buffer.Get(arr);
            return arr;
        }

        /**
         * Generate a SUPL POS INIT message that can be send by the SUPL client to the server in the case
         * that device location is known via a latitude and a longitude.
         *
         * <p>SUPL POS INIT is the second message to be send from the client to the server after receiving
         * a SUPL RESPONSE containing a {@link SessionID} from the server. The {@link SessionID} received
         * from the server response should set in the SUPL POS INIT message.
         *
         * <p>Filling the fields of the ULP_PDU to a local location SUPL POS INIT packet are done
         * following the field contents from:
         * /depot/google3/java/com/google/location/lbs/supl/tools/local-location.supl
         */
        public ULP_PDU newSuplPosInitMessage(SessionID sessionId, long latE7, long lngE7)
        {
            UlpMessage message = newSuplPosInitMessage();
            SUPLPOSINIT suplPosInit = message.getMsSUPLPOSINIT();

            LocationId locationId = suplPosInit.setLocationIdToNewInstance();
            CellInfo cellInfo = locationId.setCellInfoToNewInstance();
            cellInfo.setExtensionVer2_CellInfo_extensionToNewInstance();
            // FF-FF-FF-FF-FF-FF
            String macBinary = "111111111111111111111111111111111111111111111111";
            BitSet bits = new BitSet(macBinary.Count());
            for (int i = 0; i < macBinary.Count(); ++i)
            {
                if (macBinary[i] == '1')
                {
                    bits.Set(i);
                }
            }
            cellInfo
                .getExtensionVer2_CellInfo_extension()
                .setWlanAPToNewInstance()
                .setApMACAddressToNewInstance()
                .setValue(bits);
            locationId.setStatusToNewInstance().setValue(new Status.Value(Status.Value.ValueEnum.current));

            Position pos = suplPosInit.setPositionToNewInstance();
            Position.timestampType utcTime = pos.setTimestampToNewInstance();
            Calendar currentTime = GregorianCalendar.GetInstance(Java.Util.TimeZone.GetTimeZone("UTC"));
            utcTime.setYear(currentTime.Get(CalendarField.Year));
            utcTime.setMonth(currentTime.Get(CalendarField.Month) + 1); // Calendar's MONTH starts from 0.
            utcTime.setDay(currentTime.Get(CalendarField.DayOfMonth));
            utcTime.setHour(currentTime.Get(CalendarField.HourOfDay));
            utcTime.setMinute(currentTime.Get(CalendarField.Minute));
            utcTime.setSecond(currentTime.Get(CalendarField.Second));

            PositionEstimate posEstimate = pos.setPositionEstimateToNewInstance();

            long latSuplFormat =
                (long)(Math.Abs(latE7) / (UlpConstants.POSITION_ESTIMATE_LAT_SCALE_FACTOR * 1E7));
            long lngSuplFormat = (long)(lngE7 / (UlpConstants.POSITION_ESTIMATE_LNG_SCALE_FACTOR * 1E7));
            posEstimate.setLatitudeToNewInstance().setInteger(BigInteger.ValueOf(latSuplFormat));
            posEstimate.setLongitudeToNewInstance().setInteger(BigInteger.ValueOf(lngSuplFormat));
            posEstimate
                .setLatitudeSignToNewInstance()
                .setValue(latE7 > 0 
                ? new PositionEstimate.latitudeSignType.Value(PositionEstimate.latitudeSignType.Value.ValueEnum.north) 
                : new PositionEstimate.latitudeSignType.Value(PositionEstimate.latitudeSignType.Value.ValueEnum.south));

            message.setMsSUPLPOSINIT(suplPosInit);

            return createUlpPdu(message, sessionId);
        }

        /**
         * Generates SUPL POS/Assistance Ack message to acknowledge assistance data delivery using
         * underlying positioning protocol.
         */
        public abstract ULP_PDU newSuplPosAckMessage(SessionID sessionId);


        private UlpMessage newSuplPosInitMessage()
        {
            UlpMessage message = new UlpMessage();
            SUPLPOSINIT suplPosInit = message.setMsSUPLPOSINITToNewInstance();
            SETCapabilities setCapabilities = suplPosInit.setSETCapabilitiesToNewInstance();
            PosTechnology posTechnology = setCapabilities.setPosTechnologyToNewInstance();
            posTechnology.setAgpsSETassistedToNewInstance().setValue(false);
            posTechnology.setAgpsSETBasedToNewInstance().setValue(true);
            posTechnology.setAutonomousGPSToNewInstance().setValue(true);
            posTechnology.setAFLTToNewInstance().setValue(false);
            posTechnology.setECIDToNewInstance().setValue(false);
            posTechnology.setEOTDToNewInstance().setValue(false);
            posTechnology.setOTDOAToNewInstance().setValue(false);

            setCapabilities.setPrefMethodToNewInstance().setValue(new PrefMethod.Value(PrefMethod.Value.ValueEnum.agpsSETBasedPreferred));

            PosProtocol posProtocol = setCapabilities.setPosProtocolToNewInstance();
            posProtocol.setTia801ToNewInstance().setValue(false);
            posProtocol.setRrlpToNewInstance().setValue(true);
            posProtocol.setRrcToNewInstance().setValue(false);

            RequestedAssistData reqAssistData = suplPosInit.setRequestedAssistDataToNewInstance();
            reqAssistData.setAlmanacRequestedToNewInstance().setValue(false);
            reqAssistData.setUtcModelRequestedToNewInstance().setValue(false);
            reqAssistData.setIonosphericModelRequestedToNewInstance().setValue(true);
            reqAssistData.setDgpsCorrectionsRequestedToNewInstance().setValue(false);
            reqAssistData.setReferenceLocationRequestedToNewInstance().setValue(true);
            reqAssistData.setReferenceTimeRequestedToNewInstance().setValue(true);
            reqAssistData.setAcquisitionAssistanceRequestedToNewInstance().setValue(true);
            reqAssistData.setRealTimeIntegrityRequestedToNewInstance().setValue(false);
            reqAssistData.setNavigationModelRequestedToNewInstance().setValue(true);
            NavigationModel navigationModelData = reqAssistData.setNavigationModelDataToNewInstance();
            navigationModelData.setGpsWeekToNewInstance().setInteger(BigInteger.Zero);
            navigationModelData.setGpsToeToNewInstance().setInteger(BigInteger.Zero);
            navigationModelData.setNSATToNewInstance().setInteger(BigInteger.Zero);
            navigationModelData.setToeLimitToNewInstance().setInteger(BigInteger.Zero);

            // Request GANSS assistance
            Ver2_RequestedAssistData_extension assistExtension = new Ver2_RequestedAssistData_extension();
            reqAssistData.setExtensionVer2_RequestedAssistData_extension(assistExtension);
            GanssRequestedGenericAssistanceDataList ganssRequestList =
                assistExtension.setGanssRequestedGenericAssistanceDataListToNewInstance();

            // Request GLONASS assistance
            GanssReqGenericData glonassRequest = new GanssReqGenericData();
            glonassRequest.setGanssIdToNewInstance().setLong(UlpConstants.ULP_GANSS_ID_GLO);
            glonassRequest.setGanssRealTimeIntegrityToNewInstance().setValue(false);
            glonassRequest.setGanssAlmanacToNewInstance().setValue(false);
            glonassRequest.setGanssUTCModelToNewInstance().setValue(false);
            glonassRequest.setGanssReferenceMeasurementInfoToNewInstance().setValue(false);
            glonassRequest.setGanssAuxiliaryInformationToNewInstance().setValue(true);
            GanssNavigationModelData navModel = glonassRequest.setGanssNavigationModelDataToNewInstance();
            navModel.setGanssToeToNewInstance().setInteger(BigInteger.Zero);
            navModel.setGanssWeekToNewInstance().setInteger(BigInteger.Zero);
            navModel.setT_toeLimitToNewInstance().setInteger(BigInteger.Zero);
            ganssRequestList.add(glonassRequest);

            // Request Galileo assistance
            GanssReqGenericData galileoRequest = new GanssReqGenericData();
            galileoRequest.setGanssIdToNewInstance().setLong(UlpConstants.ULP_GANSS_ID_GAL);
            galileoRequest.setGanssRealTimeIntegrityToNewInstance().setValue(false);
            galileoRequest.setGanssAlmanacToNewInstance().setValue(false);
            galileoRequest.setGanssUTCModelToNewInstance().setValue(false);
            galileoRequest.setGanssReferenceMeasurementInfoToNewInstance().setValue(false);
            galileoRequest.setGanssAuxiliaryInformationToNewInstance().setValue(true);
            navModel = galileoRequest.setGanssNavigationModelDataToNewInstance();
            navModel.setGanssToeToNewInstance().setInteger(BigInteger.Zero);
            navModel.setGanssWeekToNewInstance().setInteger(BigInteger.Zero);
            navModel.setT_toeLimitToNewInstance().setInteger(BigInteger.Zero);
            ganssRequestList.add(galileoRequest);

            return message;
        }
    }
}