﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.asn1.supl2;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl
{
    public class SuplLppClient : SuplClient
    {
        public SuplLppClient(SuplConnectionRequest request) : base(request)
        {
        }

        protected override SuplMessagesGenerator getSuplMessagesGenerator()
        {
            return new SuplLppMessagesGenerator();
        }

        protected override EphemerisResponse suplPosToEphResponse(SUPLPOS var1)
        {
            throw new NotImplementedException();
        }

        protected override void validateAssistanceData(SUPLPOS var1)
        {
            throw new NotImplementedException();
        }
 
    }
}