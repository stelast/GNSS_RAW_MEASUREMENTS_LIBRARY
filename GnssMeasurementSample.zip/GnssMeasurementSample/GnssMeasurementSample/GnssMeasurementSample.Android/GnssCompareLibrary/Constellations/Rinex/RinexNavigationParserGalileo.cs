﻿using Android.App;
using Android.Content;
using Android.Locations;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Corrections;
using Java.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.Rinex
{
    public class RinexNavigationParserGalileo : EphemerisSystemGalileo, NavigationProducer
    {

        private File fileNav;
        private FileInputStream streamNav;
        private InputStreamReader inStreamNav;
        private BufferedReader buffStreamNav;

        private FileOutputStream cacheOutputStream;
        private OutputStreamWriter cacheStreamWriter;

        public static string newline = System.Environment.NewLine;


		private readonly string TAG = "RinexNavigationParserGalileo";

        public BroadcastGGTO ggto;

        private List<EphGalileo> eph = new List<EphGalileo>(); /* GPS broadcast ephemerides */
        //private double[] iono = new double[8]; /* Ionosphere model parameters */
        private IonoGalileo iono = null; /* Ionosphere model parameters */
        //	private double A0; /* Delta-UTC parameters: A0 */
        //	private double A1; /* Delta-UTC parameters: A1 */
        //	private double T; /* Delta-UTC parameters: T */
        //	private double W; /* Delta-UTC parameters: W */
        //	private int leaps; /* Leap seconds */

        // RINEX Read constructors
        //public RinexNavigationParserGalileo(InputStream is2, File cache)
        //{
        //    this.inStreamNav = new InputStreamReader(is2);
        //    if (cache != null)
        //    {
        //        File path = cache.getParentFile();
        //        if (!path.Exists()) path.Mkdirs();
        //        try
        //        {
        //            cacheOutputStream = new FileOutputStream(cache);
        //            cacheStreamWriter = new OutputStreamWriter(cacheOutputStream);
        //        }
        //        catch (FileNotFoundException e)
        //        {
        //            //System.err.println("Exception writing " + cache);
        //            //e.printStackTrace();
        //        }
        //    }
        //}
		 
        // RINEX Read constructors
        public RinexNavigationParserGalileo(File fileNav)
        {
            this.fileNav = fileNav;
		}

		public RinexNavigationParserGalileo(EphemerisResponse ephResponse)
		{
			foreach (GnssEphemeris eph in ephResponse.ephList)
			{
				if (eph is GalEphemeris) {
				this.eph.Add(new EphGalileo((GalEphemeris)eph));
			}
		}
		//this.iono = new IonoGalileo(ephResponse.ionoProto2);
	}




	public void init()
        {
            open();
            int ver = parseHeaderNav();
            if (ver != 0)
            {

                if (ver == 2)
                {

                    //System.out.println("Ver. 2.x");
                    parseDataNavV2();

                }
                else if (ver == 212)
                {

                    //				System.out.println("Ver. 2.12");
                    parseDataNavV2();

                }
                else if (ver == 3)
                {

                    //				System.out.println("Ver. 3.01");
                    parseDataNavV3();

                }
                close();
            }
            else
            {
                close();
                throw new SystemException(fileNav.ToString() + " is invalid ");
            }
        }

        public void release(bool waitForThread, long timeoutMs)
        { 
        }

        /**
         *
         */
        public void open()
        {
            try
            {

                if (fileNav != null) streamNav = new FileInputStream(fileNav);
                //if (streamNav != null) inStreamNav = new Java.IO.InputStreamReader(streamNav);
                if (inStreamNav != null) buffStreamNav = new BufferedReader(inStreamNav);

            }
            catch (FileNotFoundException e1)
            {
                //e1.printStackTrace();
            }
        }

        public void close()
        {
            try
            {
                if (cacheStreamWriter != null)
                {
                    cacheStreamWriter.Flush();
                    cacheStreamWriter.Close();
                }
                if (cacheOutputStream != null)
                {
                    cacheOutputStream.Flush();
                    cacheOutputStream.Close();
                }
            }
            catch (FileNotFoundException e1)
            {
                //e1.printStackTrace();
            }
            catch (IOException e2)
            {
                //e2.printStackTrace();
            }
            try
            {

                if (buffStreamNav != null) buffStreamNav.Close();
                if (inStreamNav != null) inStreamNav.Close();
                if (streamNav != null) streamNav.Close();


            }
            catch (FileNotFoundException e1)
            {
                //e1.printStackTrace();
            }
            catch (IOException e2)
            {
                //e2.printStackTrace();
            }
        }



		/**
		 *
		 */
		public int parseHeaderNav()
		{


			ggto = new BroadcastGGTO();

			//Navigation.iono = new double[8];
			string sub;
			int ver = 0;

			try
			{

				while (buffStreamNav.Ready())
				{

					try
					{
						string line = buffStreamNav.ReadLine();
						if (cacheStreamWriter != null)
						{
							cacheStreamWriter.Write(line);
							cacheStreamWriter.Write(newline);
						}

						string typeField = line.Substring(60, line.Count());
						typeField = typeField.Trim();

						if (typeField.Equals("RINEX VERSION / TYPE"))
						{

							if (!line.Substring(20, 21).Equals("N"))
							{

								// Error if navigation file identifier was not found
								//System.err.println("Navigation file identifier is missing in file " + fileNav.tostring() + " header");
								return ver = 0;

							}
							else if (line.Substring(5, 7).Equals("3."))
							{

								//							System.out.println("Ver. 3.01");
								ver = 3;

							}
							else if (line.Substring(5, 9).Equals("2.12"))
							{

								//							System.out.println("Ver. 2.12");
								ver = 212;

							}
							else
							{

								//							System.out.println("Ver. 2.x");
								ver = 2;
							}

						}

						switch (ver)
						{
							/* RINEX ver. 2.x */
							case 2:

								if (typeField.Equals("IONOSPHERIC CORR"))
								{

									float[] a = new float[4];
									sub = line.Substring(3, 17).Replace('D', 'e');
									//Navigation.iono[0] = Double.Parse(sub.Trim());
									a[0] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(19, 29).Replace('D', 'e');
									//Navigation.iono[1] = Double.Parse(sub.Trim());
									a[1] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(30, 41).Replace('D', 'e');
									//Navigation.iono[2] = Double.Parse(sub.Trim());
									a[2] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(43, 53).Replace('D', 'e');
									//Navigation.iono[3] = Double.Parse(sub.Trim());
									a[3] = (float)Double.Parse(sub.Trim());

									if (iono == null) iono = new IonoGalileo();
									iono.setAlpha(a);

								}
								else if (typeField.Equals("ION BETA"))
								{

									float[] b = new float[4];

									sub = line.Substring(3, 14).Replace('D', 'e');
									//Navigation.iono[4] = Double.Parse(sub.Trim());
									//setIono(4, Double.Parse(sub.Trim()));
									b[0] = (float)Double.Parse(sub.Trim());


									sub = line.Substring(15, 26).Replace('D', 'e');
									//Navigation.iono[5] = Double.Parse(sub.Trim());
									//setIono(5, Double.Parse(sub.Trim()));
									b[1] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(27, 38).Replace('D', 'e');
									//Navigation.iono[6] = Double.Parse(sub.Trim());
									//setIono(6, Double.Parse(sub.Trim()));
									b[2] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(39, 50).Replace('D', 'e');
									//Navigation.iono[7] = Double.Parse(sub.Trim());
									//setIono(7, Double.Parse(sub.Trim()));
									b[3] = (float)Double.Parse(sub.Trim());

									if (iono == null) iono = new IonoGalileo();
									iono.setBeta(b);

								}
								else if (typeField.Equals("DELTA-UTC: A0,A1,T,W"))
								{

									if (iono == null) iono = new IonoGalileo();

									sub = line.Substring(3, 22).Replace('D', 'e');
									//setA0(Double.Parse(sub.Trim()));
									iono.setUtcA0(Double.Parse(sub.Trim()));

									sub = line.Substring(22, 41).Replace('D', 'e');
									//setA1(Double.Parse(sub.Trim()));
									iono.setUtcA1(Double.Parse(sub.Trim()));

									sub = line.Substring(41, 50).Replace('D', 'e');
									//setT(Int32.Parse(sub.Trim()));
									// TODO need check
									iono.setUtcWNT(Int32.Parse(sub.Trim()));

									sub = line.Substring(50, 59).Replace('D', 'e');
									//setW(Int32.Parse(sub.Trim()));
									// TODO need check
									iono.setUtcTOW(Int32.Parse(sub.Trim()));

								}
								else if (typeField.Equals("LEAP SECONDS"))
								{
									if (iono == null) iono = new IonoGalileo();
									sub = line.Substring(0, 6).Trim().Replace('D', 'e');
									//setLeaps(Int32.Parse(sub.Trim()));
									// TODO need check
									iono.setUtcLS(Int32.Parse(sub.Trim()));

								}
								else if (typeField.Equals("END OF HEADER"))
								{
									return ver;
								}
								break;


							/* RINEX ver. 2.12 */
							case 212:

								//							System.out.println("Ver. 2.12");

								string typeField2 = line.Substring(0, 4);
								typeField2 = typeField2.Trim();

								if (typeField2.Equals("GAL"))
								{

									float[] a = new float[4];
									sub = line.Substring(6, 17).Replace('D', 'e');
									//Navigation.iono[0] = Double.Parse(sub.Trim());
									a[0] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(18, 29).Replace('D', 'e');
									//Navigation.iono[1] = Double.Parse(sub.Trim());
									a[1] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(30, 41).Replace('D', 'e');
									//Navigation.iono[2] = Double.Parse(sub.Trim());
									a[2] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(42, 53).Replace('D', 'e');
									//Navigation.iono[3] = Double.Parse(sub.Trim());
									a[3] = (float)Double.Parse(sub.Trim());

									if (iono == null) iono = new IonoGalileo();
									iono.setAlpha(a);

								}
								else if (typeField2.Equals("GPGA"))
								{


									sub = line.Substring(5, 22).Replace('D', 'e');
									ggto.setGgtoA0G(Double.Parse(sub.Trim()));


									sub = line.Substring(22, 38).Replace('D', 'e');
									ggto.setGgtoA1G(Double.Parse(sub.Trim()));

									sub = line.Substring(38, 45).Replace('D', 'e');
									ggto.setGgtoT0G(Double.Parse(sub.Trim()));


									sub = line.Substring(45, 51).Replace('D', 'e');
									ggto.setGgtoWN0G(Double.Parse(sub.Trim()));


								}
								else if (typeField.Equals("END OF HEADER"))
								{
									return ver;
								}
								break;

							/* RINEX ver. 3.01 */
							case 3:

								string typeField3 = line.Substring(0, 4);
								typeField3 = typeField3.Trim();

								//						string typeField3 = line.Substring(60, line.Count());
								//						typeField3 = typeField3.Trim();

								//						System.out.println(typeField2);


								if (typeField3.Equals("GAL"))
								{

									//							System.out.println("GPSA");

									float[] a = new float[4];
									sub = line.Substring(6, 17).Replace('D', 'e');
									//Navigation.iono[0] = Double.Parse(sub.Trim());
									a[0] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(18, 29).Replace('D', 'e');
									//Navigation.iono[1] = Double.Parse(sub.Trim());
									a[1] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(30, 41).Replace('D', 'e');
									//Navigation.iono[2] = Double.Parse(sub.Trim());
									a[2] = (float)Double.Parse(sub.Trim());

									sub = line.Substring(42, 53).Replace('D', 'e');
									//Navigation.iono[3] = Double.Parse(sub.Trim());
									a[3] = (float)Double.Parse(sub.Trim());

									if (iono == null) iono = new IonoGalileo();
									iono.setAlpha(a);


								}
								else if (typeField3.Equals("GPGA"))
								{

									sub = line.Substring(5, 22).Replace('D', 'e');
									ggto.setGgtoA0G(Double.Parse(sub.Trim()));


									sub = line.Substring(22, 38).Replace('D', 'e');
									ggto.setGgtoA1G(Double.Parse(sub.Trim()));

									sub = line.Substring(38, 45).Replace('D', 'e');
									ggto.setGgtoT0G(Double.Parse(sub.Trim()));


									sub = line.Substring(45, 51).Replace('D', 'e');
									ggto.setGgtoWN0G(Double.Parse(sub.Trim()));

								}
								else if (typeField.Equals("END OF HEADER"))
								{
									//							System.out.println("END OF HEADER");

									return ver;
								}


								break;
						}  // End of Switch 

					}
					catch (Exception e)
					{
						// Skip over blank lines
					}
				}

				// Display an error if END OF HEADER was not reached
				//System.err.println("END OF HEADER was not found in file "
				//		+ fileNav.tostring());

			}
			catch (IOException e)
			{
				//e.printStackTrace();
			}
			return 0;
		}

		/**
		 * Read all navigation data
		 */
		public void parseDataNavV2()
		{
			try
			{

				// Resizable array
				//Navigation.eph = new ArrayList<EphGalileo>();

				//			int j = 0;

				EphGalileo eph = null;

				while (buffStreamNav.Ready())
				{

					string sub;
					char satType = 'E';

					eph = new EphGalileo();
					addEph(eph);
					eph.setSatType(satType);

					// read 8 lines
					for (int i = 0; i < 8; i++)
					{

						string line = buffStreamNav.ReadLine();
						if (cacheStreamWriter != null)
						{
							cacheStreamWriter.Write(line);
							cacheStreamWriter.Write(newline);
						}

						try
						{

							int len = line.Count();

							if (len != 0)
							{

								if (i == 0)
								{ // LINE 1

									//Navigation.eph.get(j).refTime = new Time();


									//Navigation.eph.Add(eph);
									//								addEph(eph);

									// Get satellite ID
									sub = line.Substring(1, 3).Trim();
									eph.setSatID(Int32.Parse(sub));

									// Get and format date and time string
									string dT = line.Substring(3, 23);
									dT = dT.Replace("  ", " 0").Trim();
									dT = dT + ".0";
									dT.Count();

									//dT = "20" + dT;
									//								System.out.println(dT);


									try
									{
										//Time timeEph = new Time(dT);
										// Convert string to UNIX standard time in
										// milliseconds
										//timeEph.msec = Time.datestringToTime(dT);
										Time toc = new Time(dT);
										eph.setRefTime(toc);
										eph.setToc(toc.getGpsWeekSec());

										// sets Iono reference time
										if (iono != null && iono.getRefTime() == null) iono.setRefTime(new Time(dT));

									}
									catch (Exception e)
									{
										//System.err.println("Time parsing failed");
									}

									sub = line.Substring(23, 42).Replace('D', 'e');
									eph.setAf0(Double.Parse(sub.Trim()));

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setAf1(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									eph.setAf2(Double.Parse(sub.Trim()));

								}
								else if (i == 1)
								{ // LINE 2

									sub = line.Substring(3, 23).Replace('D', 'e');
									double iode = Double.Parse(sub.Trim());
									// TODO check double -> int conversion ?
									eph.setIode((int)iode);

									sub = line.Substring(23, 42).Replace('D', 'e');
									eph.setCrs(Double.Parse(sub.Trim()));

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setDeltaN(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									eph.setM0(Double.Parse(sub.Trim()));

								}
								else if (i == 2)
								{ // LINE 3

									sub = line.Substring(3, 23).Replace('D', 'e');
									eph.setCuc(Double.Parse(sub.Trim()));

									sub = line.Substring(23, 42).Replace('D', 'e');
									eph.setE(Double.Parse(sub.Trim()));

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setCus(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									eph.setRootA(Double.Parse(sub.Trim()));

								}
								else if (i == 3)
								{ // LINE 4

									sub = line.Substring(3, 23).Replace('D', 'e');
									eph.setToe(Double.Parse(sub.Trim()));

									sub = line.Substring(23, 42).Replace('D', 'e');
									eph.setCic(Double.Parse(sub.Trim()));

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setOmega0(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									eph.setCis(Double.Parse(sub.Trim()));

								}
								else if (i == 4)
								{ // LINE 5

									sub = line.Substring(3, 23).Replace('D', 'e');
									eph.setI0(Double.Parse(sub.Trim()));

									sub = line.Substring(23, 42).Replace('D', 'e');
									eph.setCrc(Double.Parse(sub.Trim()));

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setOmega(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									eph.setOmegaDot(Double.Parse(sub.Trim()));

								}
								else if (i == 5)
								{ // LINE 6

									sub = line.Substring(3, 23).Replace('D', 'e');
									eph.setiDot(Double.Parse(sub.Trim()));

									sub = line.Substring(23, 42).Replace('D', 'e');
									double L2Code = Double.Parse(sub.Trim());
									eph.setL2Code((int)L2Code);

									sub = line.Substring(42, 61).Replace('D', 'e');
									double week = Double.Parse(sub.Trim());
									eph.setWeek((int)week);

									sub = line.Substring(61, len).Replace('D', 'e');
									double L2Flag = Double.Parse(sub.Trim());
									eph.setL2Flag((int)L2Flag);

								}
								else if (i == 6)
								{ // LINE 7

									sub = line.Substring(3, 23).Replace('D', 'e');
									double svAccur = Double.Parse(sub.Trim());
									eph.setSvAccur((int)svAccur);

									sub = line.Substring(23, 42).Replace('D', 'e');
									double svHealth = Double.Parse(sub.Trim());
									eph.setSvHealth((int)svHealth);

									sub = line.Substring(42, 61).Replace('D', 'e');
									eph.setTgd(Double.Parse(sub.Trim()));

									sub = line.Substring(61, len).Replace('D', 'e');
									double iodc = Double.Parse(sub.Trim());
									eph.setIodc((int)iodc);

								}
								else if (i == 7)
								{ // LINE 8

									sub = line.Substring(3, 23).Replace('D', 'e');
									eph.setTom(Double.Parse(sub.Trim()));

									if (len > 23)
									{
										sub = line.Substring(23, 42).Replace('D', 'e');
										eph.setFitInt((long)Double.Parse(sub.Trim()));

									}
									else
									{
										eph.setFitInt(0);
									}
								}
							}
							else
							{
								i--;
							}
						}
						catch (Exception e)
						{
							// Skip over blank lines
						}
					}

					// Increment array index
					//				j++;
					// Store the number of ephemerides
					//Navigation.n = j;
				}

			}
			catch (IOException e)
			{
				//e.printStackTrace();
			}
			catch (Exception e)
			{
				//e.printStackTrace();
			}
		}


		public void parseDataNavV3()
		{

			try
			{

				// Resizable array
				//Navigation.eph = new ArrayList<EphGalileo>();

				//			int j = 0;

				EphGalileo eph = null;

				while (buffStreamNav.Ready())
				{

					string sub;
					char satType;

					satType = (char)buffStreamNav.Read();
					if (cacheStreamWriter != null)
					{
						cacheStreamWriter.Write(satType);
					}
					//				System.out.println(s);

					if (satType != 'R' && satType != 'S')
					{  // other than GLONASS and SBAS data
					   //						System.out.println(satType);

						// read 8 lines
						for (int i = 0; i < 8; i++)
						{

							string line = buffStreamNav.ReadLine();
							if (cacheStreamWriter != null)
							{
								cacheStreamWriter.Write(line);
								cacheStreamWriter.Write(newline);
							}

							try
							{
								int len = line.Count();

								if (len != 0)
								{
									if (i == 0)
									{ // LINE 1

										//Navigation.eph.get(j).refTime = new Time();

										eph = new EphGalileo();
										//Navigation.eph.Add(eph);
										addEph(eph);

										eph.setSatType(satType);

										// Get satellite ID
										sub = line.Substring(0, 2).Trim();
										//										System.out.println(sub);
										eph.setSatID(Int32.Parse(sub));

										// Get and format date and time string
										string dT = line.Substring(3, 22);
										//								dT = dT.Replace("  ", " 0").Trim();
										dT = dT + ".0";
										//										System.out.println(dT);

										try
										{
											//Time timeEph = new Time(dT);
											// Convert string to UNIX standard time in
											// milliseconds
											//timeEph.msec = Time.datestringToTime(dT);
											Time toc = new Time(dT);
											eph.setRefTime(toc);
											eph.setToc(toc.getGpsWeekSec());

											// sets Iono reference time
											if (iono != null && iono.getRefTime() == null) iono.setRefTime(new Time(dT));

										}
										catch (Exception e)
										{
											//System.err.println("Time parsing failed");
										}

										sub = line.Substring(22, 41).Replace('D', 'e');
										eph.setAf0(Double.Parse(sub.Trim()));

										sub = line.Substring(41, 60).Replace('D', 'e');
										eph.setAf1(Double.Parse(sub.Trim()));

										sub = line.Substring(60, len).Replace('D', 'e');
										eph.setAf2(Double.Parse(sub.Trim()));

									}
									else if (i == 1)
									{ // LINE 2

										sub = line.Substring(4, 23).Replace('D', 'e');
										double iode = Double.Parse(sub.Trim());
										// TODO check double -> int conversion ?
										eph.setIode((int)iode);

										sub = line.Substring(23, 42).Replace('D', 'e');
										eph.setCrs(Double.Parse(sub.Trim()));

										sub = line.Substring(42, 61).Replace('D', 'e');
										eph.setDeltaN(Double.Parse(sub.Trim()));

										sub = line.Substring(61, len).Replace('D', 'e');
										eph.setM0(Double.Parse(sub.Trim()));

									}
									else if (i == 2)
									{ // LINE 3

										sub = line.Substring(4, 23).Replace('D', 'e');
										eph.setCuc(Double.Parse(sub.Trim()));

										sub = line.Substring(23, 42).Replace('D', 'e');
										eph.setE(Double.Parse(sub.Trim()));

										sub = line.Substring(42, 61).Replace('D', 'e');
										eph.setCus(Double.Parse(sub.Trim()));

										sub = line.Substring(61, len).Replace('D', 'e');
										eph.setRootA(Double.Parse(sub.Trim()));

									}
									else if (i == 3)
									{ // LINE 4

										sub = line.Substring(4, 23).Replace('D', 'e');
										eph.setToe(Double.Parse(sub.Trim()));

										sub = line.Substring(23, 42).Replace('D', 'e');
										eph.setCic(Double.Parse(sub.Trim()));

										sub = line.Substring(42, 61).Replace('D', 'e');
										eph.setOmega0(Double.Parse(sub.Trim()));

										sub = line.Substring(61, len).Replace('D', 'e');
										eph.setCis(Double.Parse(sub.Trim()));

									}
									else if (i == 4)
									{ // LINE 5

										sub = line.Substring(4, 23).Replace('D', 'e');
										eph.setI0(Double.Parse(sub.Trim()));

										sub = line.Substring(23, 42).Replace('D', 'e');
										eph.setCrc(Double.Parse(sub.Trim()));

										sub = line.Substring(42, 61).Replace('D', 'e');
										eph.setOmega(Double.Parse(sub.Trim()));

										sub = line.Substring(61, len).Replace('D', 'e');
										eph.setOmegaDot(Double.Parse(sub.Trim()));

									}
									else if (i == 5)
									{ // LINE 6

										sub = line.Substring(4, 23).Replace('D', 'e');
										eph.setiDot(Double.Parse(sub.Trim()));

										sub = line.Substring(23, 42).Replace('D', 'e');
										double L2Code = Double.Parse(sub.Trim());
										eph.setL2Code((int)L2Code);

										sub = line.Substring(42, 61).Replace('D', 'e');
										double week = Double.Parse(sub.Trim());
										eph.setWeek((int)week);

										sub = line.Substring(61, len).Replace('D', 'e');
										if (!sub.Trim().Equals(""))
										{
											double L2Flag = Double.Parse(sub.Trim());
											eph.setL2Flag((int)L2Flag);
										}
										else
										{
											eph.setL2Flag(0);
										}

									}
									else if (i == 6)
									{ // LINE 7

										sub = line.Substring(4, 23).Replace('D', 'e');
										double svAccur = Double.Parse(sub.Trim());
										eph.setSvAccur((int)svAccur);

										sub = line.Substring(23, 42).Replace('D', 'e');
										double svHealth = Double.Parse(sub.Trim());
										eph.setSvHealth((int)svHealth);

										sub = line.Substring(42, 61).Replace('D', 'e');
										eph.setTgd(Double.Parse(sub.Trim()));

										sub = line.Substring(61, len).Replace('D', 'e');
										double iodc = Double.Parse(sub.Trim());
										eph.setIodc((int)iodc);

									}
									else if (i == 7)
									{ // LINE 8

										sub = line.Substring(4, 23).Replace('D', 'e');
										eph.setTom(Double.Parse(sub.Trim()));

										if (line.Trim().Count() > 22)
										{
											sub = line.Substring(23, 42).Replace('D', 'e');
											//eph.setFitInt(Long.parseLong(sub.Trim()));

											//Added by Sebastian on 15.01.2018
											eph.setFitInt((long)Double.Parse(sub.Trim()));


										}
										else
										{
											eph.setFitInt(0);
										}
									}
								}
								else
								{
									i--;
								}


							}
							catch (Exception e)
							{
								// Skip over blank lines
							}



						}  // End of for
					}

				} // End of while

			}
			catch (IOException e)
			{
				//e.printStackTrace();
			}
			catch (Exception e)
			{
				//e.printStackTrace();
			}


		}

		private double gpsToUnixTime(Time toc, int tow)
		{
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * @param unixTime
		 * @param satID
		 * @return Reference ephemeris set for given time and satellite
		 */
		public EphGalileo findEph(long unixTime, int satID, char satType)
		{

			long dt = 0;
			long dtMin = 0;
			long dtMax = 0;
			long delta = 0;
			EphGalileo refEph = null;

			//long gpsTime = (new Time(unixTime)).getGpsTime();

			for (int i = 0; i < eph.Count(); i++)
			{
				// Find ephemeris sets for given satellite
				if (eph[i].getSatID() == satID && eph[i].getSatType() == satType)
				{
					// Consider BeiDou time (BDT) for BeiDou satellites (14 sec difference wrt GPS time)
					if (satType == 'C')
					{
						delta = 14000;
						unixTime = unixTime - delta;
					}
					// Compare current time and ephemeris reference time
					dt = Math.Abs(eph[i].getRefTime().getMsec() - unixTime /*getGpsTime() - gpsTime*/) / 1000;
					// If it's the first round, set the minimum time difference and
					// select the first ephemeris set candidate; if the current ephemeris set
					// is closer in time than the previous candidate, select new candidate
					if (refEph == null || dt < dtMin)
					{
						dtMin = dt;
						refEph = eph[i];
					}
				}
			}

			if (refEph == null)
				return null;

			if (refEph.getSvHealth() != 0)
			{
				return EphGalileo.UnhealthyEph;
			}

			//maximum allowed interval from ephemeris reference time
			long fitInterval = refEph.getFitInt();

			if (fitInterval != 0)
			{
				dtMax = fitInterval * 3600 / 2;
			}
			else
			{
				switch (refEph.getSatType())
				{
					case 'R': dtMax = 950; break;
					case 'J': dtMax = 3600; break;
					default: dtMax = 7200; break;
				}
			}
			if (dtMin > dtMax)
			{
				refEph = null;
			}

			return refEph;
		}

		public int getEphSize()
		{
			return eph.Count();
		}

		public void addEph(EphGalileo eph)
		{
			this.eph.Add(eph);
		}

		//	public void setIono(int i, double val){
		//		this.iono[i] = val;
		//	}
		public IonoGps getIono(long unixTime, Location initialLocation)
		{
			return null;
		}

		public IonoGalileo getIonoNeQuick(long unixTime, Location initialLocation)
		{
			return iono;
		}
		//	/**
		//	 * @return the a0
		//	 */
		//	public double getA0() {
		//		return A0;
		//	}
		//	/**
		//	 * @param a0 the a0 to set
		//	 */
		//	public void setA0(double a0) {
		//		A0 = a0;
		//	}
		//	/**
		//	 * @return the a1
		//	 */
		//	public double getA1() {
		//		return A1;
		//	}
		//	/**
		//	 * @param a1 the a1 to set
		//	 */
		//	public void setA1(double a1) {
		//		A1 = a1;
		//	}
		//	/**
		//	 * @return the t
		//	 */
		//	public double getT() {
		//		return T;
		//	}
		//	/**
		//	 * @param t the t to set
		//	 */
		//	public void setT(double t) {
		//		T = t;
		//	}
		//	/**
		//	 * @return the w
		//	 */
		//	public double getW() {
		//		return W;
		//	}
		//	/**
		//	 * @param w the w to set
		//	 */
		//	public void setW(double w) {
		//		W = w;
		//	}
		//	/**
		//	 * @return the leaps
		//	 */
		//	public int getLeaps() {
		//		return leaps;
		//	}
		//	/**
		//	 * @param leaps the leaps to set
		//	 */
		//	public void setLeaps(int leaps) {
		//		this.leaps = leaps;
		//	}

		public bool isTimestampInEpocsRange(long unixTime)
		{
			return eph.Count() > 0/* &&
				eph.get(0).getRefTime().getMsec() <= unixTime /*&&
		unixTime <= eph.get(eph.Count()-1).getRefTime().getMsec() missing interval +epochInterval*/;
		}


		/* (non-Javadoc)
		 * @see org.gogpsproject.NavigationProducer#getGpsSatPosition(long, int, double)
		 */

		public SatellitePosition getGpsSatPosition(Observations obs, int satID, char satType, double receiverClockError)
		{
			long unixTime = obs.getRefTime().getMsec();
			double range = obs.getSatByIDType(satID, satType).getPseudorange(0);

			if (range == 0)
				return null;

			EphGalileo eph = findEph(unixTime, satID, satType);
			if (eph.Equals(EphGalileo.UnhealthyEph))
				return SatellitePosition.UnhealthySat;

			if (eph != null)
			{

				//			char satType = eph.getSatType();

				//SatellitePosition sp = computePositionGalileo(obs, satID, satType, eph, receiverClockError);
				//			SatellitePosition sp = computePositionGps(unixTime, satType, satID, eph, range, receiverClockError);
				//if(receiverPosition!=null) earthRotationCorrection(receiverPosition, sp);
				//return sp;// new SatellitePosition(eph, unixTime, satID, range);
			}
			return null;
		}


		public SatellitePosition getGalileoSatPosition(long unixTime, double range, int satID, char satType, double receiverClockError)
		{
			//long unixTime = obs.getRefTime().getMsec();
			//double range = obs.getSatByIDType(satID, satType).getPseudorange(0);

			if (range == 0)
				return null;

			EphGalileo eph = findEph(unixTime, satID, satType);
			//if( eph.Equals( EphGalileo.UnhealthyEph ))
			//return SatellitePosition.UnhealthySat;

			if (eph == null)
			{
				Log.Error(TAG, "getGalileoSatPosition: Ephemeris failed to load...");
				return null;
			}

			//			char satType = eph.getSatType();

			SatellitePosition sp = computePositionGalileo(unixTime, range, satID, satType, eph, receiverClockError);
			//			SatellitePosition sp = computePositionGps(unixTime, satType, satID, eph, range, receiverClockError);
			//if(receiverPosition!=null) earthRotationCorrection(receiverPosition, sp);

			return sp;// new SatellitePosition(eph, unixTime, satID, range);

		}

		public SatellitePosition getGalileoSatVelocities(long unixTime, double range, int satID, char satType, double receiverClockError)
		{
			//long unixTime = obs.getRefTime().getMsec();
			//double range = obs.getSatByIDType(satID, satType).getPseudorange(0);

			if (range == 0)
				return null;

			EphGalileo eph = findEph(unixTime, satID, satType);
			if (eph.Equals(EphGalileo.UnhealthyEph))
				return SatellitePosition.UnhealthySat;

			if (eph != null)
			{

				SatellitePosition sv = computePositionSpeedGalileo(unixTime, range, satID, satType, eph, receiverClockError);


				return sv;
			}
			return null;
		}





		public string getFileName()
		{
			if (fileNav == null)
				return null;
			else
				return fileNav.Name;
		}

	}
}