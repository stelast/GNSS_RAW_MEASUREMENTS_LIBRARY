﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.Rinex
{
    public class GalEphemeris : KeplerianEphemeris
    {
        public readonly double sisaM;
        public readonly double tgdS;
        public readonly bool isINav;

        private GalEphemeris(Builder builder) : base(builder)
        {
            this.sisaM = builder.sisaM;
            this.tgdS = builder.tgdS;
            this.isINav = builder.isINav;
        }

        public static GalEphemeris.Builder newBuilder()
        {
            return new GalEphemeris.Builder();
        }

        public class Builder : KeplerianEphemeris.Builder
        {
            public double sisaM;
            public double tgdS;
            public bool isINav;

            public override GnssEphemeris.Builder getThis()
            {
                return this;
            }

            public Builder()
            {
            }

            public GnssEphemeris.Builder setSisaM(double sisaM)
            {
                this.sisaM = sisaM;
                return this.getThis();
            }

            public GnssEphemeris.Builder setTgdS(double tgdS)
            {
                this.tgdS = tgdS;
                return this.getThis();
            }

            public GnssEphemeris.Builder setIsINav(bool isINav)
            {
                this.isINav = isINav;
                return this.getThis();
            }

            public GalEphemeris build()
            {
                return new GalEphemeris(this);
            }

        }

    }

}