﻿using Android.App;
using Android.Content;
using Android.Locations;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.ephemeris;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.Rinex;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.supl;
using GnssMeasurementSample.Droid.GnssCompareLibrary.Corrections;
using Java.Lang;
using Java.Sql;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace GnssMeasurementSample.Droid.GnssCompareLibrary.Constellations.Rinex
{
    public class RinexNavigationGalileo : NavigationProducer
    {
        public readonly static string GARNER_NAVIGATION_AUTO = "ftp://garner.ucsd.edu/pub/nav/${yyyy}/${ddd}/auto${ddd}0.${yy}n.Z";
        public readonly static string IGN_MULTI_NAVIGATION_DAILY = "ftp://igs.ign.fr/pub/igs/data/campaign/mgex/daily/rinex3/${yyyy}/${ddd}/brdm${ddd}0.${yy}p.Z";
        public readonly static string GARNER_NAVIGATION_ZIM2 = "ftp://garner.ucsd.edu/pub/nav/${yyyy}/${ddd}/zim2${ddd}0.${yy}n.Z";
        public readonly static string IGN_NAVIGATION_HOURLY_ZIM2 = "ftp://igs.ensg.ign.fr/pub/igs/data/hourly/${yyyy}/${ddd}/zim2${ddd}${h}.${yy}n.Z";
        public readonly static string NASA_NAVIGATION_DAILY = "ftp://cddis.gsfc.nasa.gov/pub/gps/data/daily/${yyyy}/${ddd}/${yy}n/brdc${ddd}0.${yy}n.Z";
        public readonly static string NASA_NAVIGATION_HOURLY = "ftp://cddis.gsfc.nasa.gov/pub/gps/data/hourly/${yyyy}/${ddd}/hour${ddd}0.${yy}n.Z";
        public readonly static string GARNER_NAVIGATION_AUTO_HTTP = "http://garner.ucsd.edu/pub/rinex/${yyyy}/${ddd}/auto${ddd}0.${yy}n.Z"; // ex http://garner.ucsd.edu/pub/rinex/2016/034/auto0340.16n.Z
        public readonly static string BKG_GALILEO_RINEX = "ftp://igs.bkg.bund.de/EUREF/BRDC/${yyyy}/${ddd}/BRDC00WRD_R_${yyyy}${ddd}0000_01D_EN.rnx.gz";
        public readonly static string ESA_GALILEO_RINEX = "ftp://gssc.esa.int/gnss/data/daily/${yyyy}/${ddd}/ankr${ddd}0.${yy}l.Z";

        private readonly static string TAG = "RinexNavigationGalileo";


        /**
         * cache for negative answers
         */
        private Dictionary<string, Date> negativeChache = new Dictionary<string, Date>();

        /** Folder containing downloaded files */
        public string RNP_CACHE = "./rnp-cache";

        private bool waitForData = true;

        /**
         * Template string where to retrieve files on the net
         */
        private string urltemplate;
        private Dictionary<string, RinexNavigationParserGalileo> pool = new Dictionary<string, RinexNavigationParserGalileo>();


        /**
         * Instantiates a new RINEX navigation retriever and parser.
         *
         * @param urltemplate the template URL where to get the files on the net.
         */
        public RinexNavigationGalileo(string urltemplate)
        {
            this.urltemplate = urltemplate;

        }
        /* (non-Javadoc)
         * @see org.gogpsproject.NavigationProducer#getGpsSatPosition(long, int, double)
         */
        public SatellitePosition getGalileoSatPosition(long unixTime, double range, int satID, char satType, double receiverClockError, Location initialLocation)
        {

            RinexNavigationParserGalileo rnp = getRNPByTimestamp(unixTime, initialLocation);
            if (rnp != null)
            {
                if (rnp.isTimestampInEpocsRange(unixTime))
                {
                    return rnp.getGalileoSatPosition(unixTime, range, satID, satType, receiverClockError);
                }
                else
                {
                    return null;
                }
            }

            return null;
        }

        public SatellitePosition getGalileoSatVelocities(long unixTime, double range, int satID, char satType, double receiverClockError, Location initialLocation)
        {

            RinexNavigationParserGalileo rnp = getRNPByTimestamp(unixTime, initialLocation);
            if (rnp != null)
            {
                if (rnp.isTimestampInEpocsRange(unixTime))
                {

                    return rnp.getGalileoSatVelocities(unixTime, range, satID, satType, receiverClockError);

                }
                else
                {
                    return null;
                }
            }

            return null;
        }
        //private RinexNavigationParserGalileo SuplFileToRnpParserGal(File rnf)
        //{
        //    RinexNavigationParserGalileo rnp = null;

        //    return rnp;
        //}

        List<string> retrievingFromServer = new List<string>();

        protected RinexNavigationParserGalileo getRNPByTimestamp(long unixTime, Location initialLocation)
        {
            RinexNavigationParserGalileo rnp = null;
            long reqTime = unixTime;

            //       do {
            // found none, retrieve from urltemplate
            Time t = new Time(reqTime);
            //System.out.println("request: "+unixTime+" "+(new Date(t.getMsec()))+" week:"+t.getGpsWeek()+" "+t.getGpsWeekDay());

            //string url = t.formatTemplate(urltemplate);
            string url = "supl.google.com";

            if (pool.ContainsKey(url))
            {
                lock(this) {
                    rnp = pool[url];
                }
            }
            else
            {
                if (!retrievingFromServer.Contains(url))
                {
                        
                    retrievingFromServer.Add(url);
                     
                    try
                    {
                        rnp = getFromSUPL(url, initialLocation);
                        lock (this)
                        {
                            if (rnp != null)
                            {
                                pool[url] = rnp;
                            }
                            retrievingFromServer.Remove(url);
                        }
                    }
                    catch (IOException e)
                    {
                        Log.Error(TAG, "getRNPByTimestamp: " + e.Message);
                        //System.out.println(e.getClass().getName() + " url: " + url);
                    }

                    //    (new Thread(new Runnable() {
                    //    @Override
                    //    public void run()
                    //    {
                    //        RinexNavigationParserGalileo rnp = null;

                    //        try
                    //        {
                    //            try
                    //            {
                    //                rnp = getFromSUPL(url, initialLocation);
                    //            }
                    //            catch (IndexOutOfBoundsException e)
                    //            {
                    //                //                                try {
                    //                //                                    MainActivity.makeNotification("SUPL client exception...");
                    //                //                                } catch (Exception e1){
                    //                //                                    e1.printStackTrace();
                    //                //                                }
                    //                e.printStackTrace();
                    //            }
                    //            synchronized(RinexNavigationGalileo.this) {
                    //                if (rnp != null)
                    //                {
                    //                    pool.put(url, rnp);
                    //                }
                    //                retrievingFromServer.remove(url);
                    //            }
                    //        }
                    //        catch (IOException e)
                    //        {
                    //            Log.e(TAG, "Supl Client error:", e);
                    //        }
                    //    }
                    //})).start();
                }
                return null;
            }
            return rnp;
            //            try {
            //                if (pool.containsKey(url)) {
            //                    rnp = pool.get(url);
            //                } else {
            //                    rnp = getFromSUPL(url, initialLocation);
            //                    if (rnp != null) {
            //                        pool.put(url, rnp);
            //                    }
            //                }
            //                return rnp;
            //            } catch (IOException e) {
            //                System.out.println(e.getClass().getName() + " url: " + url);
            //                return null;
            //            }
            //
            //        } while (waitForData && rnp == null);
        }


        private RinexNavigationParserGalileo rnp;

        public BroadcastGGTO getRnpGgto()
        {
            return rnp.ggto;
        }

        public EphGalileo findEph(long unixTime, int satID, char satType, Location initialLocation)
        {
            long requestedTime = unixTime;
            EphGalileo eph = null;
            int maxBack = 12;
            while (eph == null && (maxBack--) > 0)
            {

                rnp = getRNPByTimestamp(requestedTime, initialLocation);

                if (rnp != null)
                {
                    if (rnp.isTimestampInEpocsRange(unixTime))
                    {
                        eph = rnp.findEph(unixTime, satID, satType);
                    }
                }
                if (eph == null)
                    requestedTime -= (1L * 3600L * 1000L);
            }

            return eph;
        }
        /* Convenience method for adding an rnp to memory cache*/
        public void put(long reqTime, RinexNavigationParserGalileo rnp)
        {
            Time t = new Time(reqTime);
            string url = t.formatTemplate(urltemplate);
            if (!pool.ContainsKey(url))
                pool[url] = rnp;
        }

        public SatellitePosition getGpsSatPosition(Observations obs, int satID, char satType, double receiverClockError)
        {
            return null;
        }

        //public IonoGps getIono(long unixTime, Location initialLocation)
        //{
        //    RinexNavigationParserGalileo rnp = getRNPByTimestamp(unixTime, initialLocation);
        //    if (rnp != null) return rnp.getIono(unixTime, initialLocation);
        //    return null;
        //}


        private RinexNavigationParserGalileo getFromSUPL(string url, Location initialLocation)
        {
            RinexNavigationParserGalileo rnp = null;

            string suplName = url;
            int serverPort = 7275;
            bool sslEnabled = true;
            bool messageLoggingEnabled = true;
            bool loggingEnabled = true;
            Java.IO.File rnf = new Java.IO.File(RNP_CACHE, suplName);

            //TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
            //Calendar c = Calendar.getInstance();
            DateTime saveUtcNow = DateTime.UtcNow;
            long unixTime = ((DateTimeOffset)saveUtcNow).ToUnixTimeMilliseconds(); 
            Time t = new Time(unixTime);

            //if (rnf.Exists()) {
            //    //System.out.println("Supl from cache file " + rnf);
            //    try {
            //        rnp = SuplFileToRnpParserGal(rnf);
            //        return rnp;
            //    } catch (SystemException e) {
            //        rnf.Delete();
            //    }
            //}

            //try
            //{
                Log.Warn(TAG, "getFromSUPL: Getting data using SUPL client...");
                SuplConnectionRequest request =
                        SuplConnectionRequest.builder()
                                .setServerHost(suplName)
                                .setServerPort(serverPort)
                                .setSslEnabled(sslEnabled)
                                .setMessageLoggingEnabled(messageLoggingEnabled)
                                .setLoggingEnabled(loggingEnabled)
                                .build();

                SuplController mSuplController = new SuplController(request);

                mSuplController.sendSuplRequest((long)(initialLocation.Latitude * 1e7), (long)(initialLocation.Longitude * 1e7));
                EphemerisResponse ephResponse = mSuplController.generateEphResponse((long)(initialLocation.Latitude * 1e7), (long)(initialLocation.Longitude * 1e7));

                if (ephResponse != null)
                {
                    rnp = new RinexNavigationParserGalileo(ephResponse);
                }

                Log.Warn(TAG, "getFromSUPL: Received data from SUPL server");

            //}
            //catch (/*NullPointerException |
            //      UnsupportedOperationException |
            //      IllegalArgumentException |
            //      IndexOutOfBoundsException e*/ Exception) {
            //    Log.Error(TAG, "Exception thrown getting msg from SUPL server");
            //}
            return rnp;
        }



        public IonoGalileo getIonoNeQuick(long unixTime, Location initialLocation)
        {
            RinexNavigationParserGalileo rnp = getRNPByTimestamp(unixTime, initialLocation);
            if (rnp != null) return rnp.getIonoNeQuick(unixTime, initialLocation);
            return null;
        }

        public void init()
        {
            throw new NotImplementedException();
        }

        public void release(bool waitForThread, long timeoutMs)
        {
            waitForData = false;
        }

        public IonoGps getIono(long unixTime, Location initialLocation)
        {
            RinexNavigationParserGalileo rnp = getRNPByTimestamp(unixTime, initialLocation);
            if (rnp != null) return rnp.getIono(unixTime, initialLocation);
            return null;
        }


    }
}